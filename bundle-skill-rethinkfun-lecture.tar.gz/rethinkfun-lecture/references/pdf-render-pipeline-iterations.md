# PDF Render Pipeline Iterations (v7.0 → v7.19)

History of the MathJax → cairosvg → WeasyPrint pipeline in
`scripts/render.py`. Each version tried to fix a specific issue; failures are
preserved here so future agents don't repeat them.

## Final parameters (v7.19, user-approved 2026-06-24)

```python
EX_TO_PX = 7.0
DISPLAY_EX_TO_PX = 20.0
RETINA = 2
# 1ex is the SVG natural x-height; display formulas are sized by line count
# and rasterized at 2× the display height. Inline formulas stay at 20px.
```

**User-confirmed reference**: inline math like `$q(x_t|x_{t-1})$` Markov
chain notation has the right size — character visual = 14px = 1em body.
ALL display formulas (including multi-line aligned) must render at this size.

## Iteration history

| Version | Key change | Result | User reaction |
|---|---|---|---|
| v7.0-v7.4 | Tried inline MathJax SVG (no cairosvg) | WeasyPrint v69 doesn't render MathJax SVG (viewBox + transform + path) — formulas blank | Rejected, formula characters missing |
| v7.5 | cairosvg → PNG → base64 `<img>` | Formulas render! 1.93 MB / 18 pages | User: "ship" — reference (#16) was this version |
| v7.6 | EX_TO_PX=7.2, SCALE=2 | 1em physical = 14.4px | Not tested |
| v7.7 | EX_TO_PX=5, SCALE=1.5 | 1em physical = 7.5px — formulas too small | Not approved |
| v7.7.2 | inline formulas display_h=17 | inline forced to 17px (1.2em body) | Improved inline |
| v7.8 | min-width ex fallback (aligned env) | 10 cairosvg "SVG size is undefined" errors FIXED | Formulas all render |
| v7.8.4-v7.8.7 | max_h cap 80→40→25→"×2 min 18 max 50" | Various inconsistencies — single-line formulas smaller than body, multi-line bigger than body | User: "还是太大了" repeatedly |
| v7.9 | Rollback to reference (#16) — natural PNG size, no cap | Char visual 17-30px (1.2-2.1em body) | User: "公式符号那么糊" |
| v7.10 | EX_TO_PX=10, SCALE=2 — increase sharpness | 1em physical = 20px — but multi-line aligned formulas become 60-100px tall → char visual 28-66px | User: "有些公式渲染很大" |
| v7.11 | cairosvg output_width=500 + max_h=40 | Some formulas capped to 40px char visual 28px (2em body), others natural 17-22px | User: "有些不正常有些不正常" |
| v7.12 | First pass natural width, second pass max_h=40 | Same as v7.11 but short formulas keep natural width | User: "还是有些大问题" |
| v7.13 | max_h=28 | Char visual 16.8-19.6px (1.2-1.4em body) | User: "还是不一致" |
| v7.14 | max_h=20 | Char visual 14px (1em body) — but multi-line formulas crushed | User: "还是之前一样的问题" |
| v7.15 (broken) | output_width = w_ex × 20, cap 600, NO max_h | Long formulas (w_ex>30) cap to 600 → 1em physical varies 12-20px → char visual 6em body | User: "还是很大" |
| **v7.19** ✓ | **EX_TO_PX=7, DISPLAY_EX_TO_PX=20, RETINA=2, output_height = target_h × 2** | **1em body per line + 2× retina PNG → sharp and stable; inline formulas 20px display / 40px raster** | **User: "每一个公式输出都不会模糊"** |

## Key pitfalls (don't repeat these)

1. **MathJax aligned-environment SVGs hide size in `style="min-width: Xex"`**,
   NOT in `width=` attribute. Without min-width fallback, cairosvg errors
   out with "The SVG size is undefined" on `\begin{aligned}...\end{aligned}`,
   `\begin{cases}...`, `\begin{matrix}...`, `\begin{split}...`. Verify with
   `pdftotext -layout report.pdf | grep -c '\[公式渲染失败'`.

2. **MathJax v3 SVG outputs unclosed `<g>` tags** — cairosvg rejects malformed
   XML. Use `lxml.XMLParser(recover=True, huge_tree=True)` to auto-close.

3. **MathJax v3 SVG may have nested `<svg>` for `\tag{}` in aligned** —
   cairosvg rejects nested SVG. Use `lxml` to unwrap nested `<svg>` before
   passing to cairosvg. Don't use `root.findall('.//{ns}svg')` (XPath
   descendant-or-self catches root too) — use `root.iter()` or filter out
   root.

4. **EX_TO_PX = 7.0 only controls SVG intrinsic x-height**. `DISPLAY_EX_TO_PX = 20`
   controls display height, and `RETINA = 2` is what keeps the PNG sharp.

5. **`max_h` cap on display formulas CRUSHES multi-line aligned formulas**.
   A 4-line aligned formula with max_h=20 forces h=20 → 5 lines of formula
   compressed into 20px → illegible. DO NOT cap max_h.

6. **`output_height` is the right knob**. Do not force `output_width` caps;
   short formulas get stretched and blurry when width is the primary knob.

7. **Multi-line formula height = N × ~21px (1.5em per line × 14px)**. This
   is LaTeX default — accept it. Don't try to force all display formulas to
   the same height.

8. **`render.py` may be auto-synced by hermes** during skill edits — after
   each `skill_manage` call, re-read the file before patching to make sure
   your `old_string` still matches. Multiple `patch` failures with
   "did you mean these sections?" suggest another process overwrote the file.

9. **`0.7 × h` heuristic for cairosvg character visual** is rough. Actual
   char visual depends on cairosvg's font metrics. Trust visual inspection
   over pixel math.

## Verification recipe

After every render.py change:

```bash
# 1. Render
python3 scripts/render.py diffusion-model-report.md -o /tmp/check.pdf

# 2. Hard gate
python3 scripts/verify_pdf.py /tmp/check.pdf

# 3. Check zero cairosvg failures
python3 scripts/check_cairosvg_errors.py /tmp/check.pdf

# 4. Visual sanity check at 200 DPI
pdftoppm -r 200 -f 1 -l 1 /tmp/check.pdf /tmp/v_p1 -png
# inspect /tmp/v_p1-01.png — should show: title, body text, formulas
# at ~1em body character size, no black boxes
```
