# v7.2.1 渲染管线深度坑 — WeasyPrint SVG 兼容性 + render.py 静默失败

> 这是 v7.2 (`render-verification-blind-spots.md`) **之后**的又一次教训。v7.2 解决了"脚本漏查 MathJax 错误"；**v7.2.1 解决"PDF 实际没渲染公式"**。两个坑叠加在一起时最危险：脚本说"成功"、时间戳看上去是新的，但 PDF 里是 0 张图。

## 事件链

2026-06-23 写 diffusion model 报告。先后两次告知用户"PDF 1.88 MB 渲染完成"——**两次都是上一次的旧 PDF**，新 PDF 因为 `sys.exit(1)` 从未生成。第三次才发现问题。

时间戳证据：
- `/home/yanyunfei/reports/diffusion-model-report.pdf` Jun 23 20:50（旧版，1.88 MB，0 张图）
- 之后 4 次 render 调用全部 `sys.exit(1)` 失败，无新 PDF
- 用户反馈"渲染离谱" → 排查发现 `pdfimages -list` 返空 → 发现 svg 在 WeasyPrint 里被丢

## 根因 1：WeasyPrint v69 不支持 MathJax 复杂 SVG

**症状**：
- HTML 里 574 个 `<mjx-container>` 含完整 `<svg>`（每个 600+ 字符，含 `viewBox` + 嵌套 `transform` + 大量 `<path data-c="...">`）
- WeasyPrint v69 SVG 渲染器只支持简单 SVG（**有 `viewBox` 但无嵌套 `transform`** 或反之——只支持一种）
- MathJax 输出**同时**有 `viewBox` + 嵌套 `transform` —— WeasyPrint 直接 drop 整个 svg
- 结果：`pdfimages -list report.pdf` 返 0 张图——**PDF 里公式完全消失，只剩周围文字**
- pdftotext 输出看到"网络预测任意时刻"+"空"+"混入的噪声"+"空"——公式位置全空

**诊断命令**（**任何发稿前必跑**）：

```bash
# 1. 看 PDF 是否真的嵌入图片
pdfimages -list path/to/report.pdf
# 输出 0 张图 = 渲染失败

# 2. 看 HTML 是否有完整 SVG
grep -c '<svg' path/to/report.html
# >0 但 pdfimages 返 0 = 渲染管线把 SVG 丢了
```

## 根因 2：cairosvg 拒绝 MathJax 的 `ex` 单位

**症状**：
- cairosvg 抛 `The SVG size is undefined`
- 根因：MathJax SVG 写 `width="0.817ex"`，cairosvg 不认 `ex` 单位

**修复**：把 `ex` 单位转成绝对像素（1ex = 8px × scale）

```python
def fix_svg_for_cairo(svg, ex_to_px=8, scale=3):
    s = re.sub(r'width="([\d.]+)ex"',
               lambda m: f'width="{int(float(m.group(1)) * ex_to_px * scale)}"', svg)
    s = re.sub(r'height="([\d.]+)ex"',
               lambda m: f'height="{int(float(m.group(1)) * ex_to_px * scale)}"', s)
    s = re.sub(r'style="vertical-align:\s*-?[\d.]+ex;"',
               'style="vertical-align: middle;"', s)
    return s
```

## 根因 3：cairosvg 处理大 SVG 时抛 `no element found`

**症状**：
- cairosvg 处理复杂公式（长 SVG，>500 字符，path 数量多）时报 `no element found: line 1, column 18747`
- 大约 11/574 个公式触发（diffusion 报告里）

**修复**：cairosvg 失败时**降级保留原 SVG**——WeasyPrint 对简单 SVG 仍能渲染（虽然复杂的不行）。**不要让 cairosvg 失败阻塞整个 PDF**。

```python
def mjx_to_img(svg):
    try:
        png_bytes = cairosvg.svg2png(bytestring=fixed.encode('utf-8'), scale=3)
        data_url = f"data:image/png;base64,{base64.b64encode(png_bytes).decode()}"
        return f'<img src="{data_url}" .../>'
    except Exception:
        # Historical note: old versions fell back to the original SVG here.
        # Current render.py returns an explicit fallback span and lets verify_pdf.py fail the ship gate.
        return svg
```

## 根因 4（最阴险）：`render.py` 在 verify fail 时 `sys.exit(1)` → 新 PDF 从未生成

**症状**：
- `render.py` 在 `main()` 第 391 行（v7.2 之前）有这段：
  ```python
  hard_errors = [i for i in issues if i.startswith("❌")]
  if hard_errors:
      sys.exit(1)  # ← 这个会阻止 PDF 写入！
  ```
- cairosvg 失败产生 11 个 ❌ → `sys.exit(1)` → 后续 `html_to_pdf()` 永不执行
- 但**已存在的 `report.pdf` 保留在原位**——`ls -la` 看到的是 1.88 MB 文件，时间戳是几小时前
- 自我感觉："PDF 渲染完成了啊？"——其实渲染了 **0 次**（自 sys.exit 之后）

**修复（v7.2.1 必须做，当前代码已做到）**：

```python
# 错误！不要这样：
if hard_errors:
    sys.exit(1)

# 正确（当前）：render.py 继续生成 HTML/PDF，但把 fallback 显式写进 HTML；
# verify_pdf.py 看到这些 fallback 就会失败，不允许发稿
```

**关键教训**：**任何在 `verify_*` 函数里 `sys.exit(1)` 都极度危险**——它让"我以为成功"和"实际成功"完全脱钩。verify 应该**只报告**问题，**绝不阻止后续步骤**。

## v7.2.1 完整渲染管线（修复后）

```
MD → extract math placeholders → MD→HTML → 
  for each placeholder:
    render_with_mathjax() → SVG
    try:
      cairosvg → PNG → base64 data URL → <img>
    except:
      emit explicit mathjax-error / math-inline-fallback / math-block-fallback span
HTML → WeasyPrint → PDF
verify_render()  # 只做前置报告；verify_pdf.py 才是 hard gate
```

## 修复前后对比

| 指标 | 修复前 | 修复后 |
|------|--------|--------|
| PDF 公式显示 | 0 / 574 | 1126 张 PNG（含 smask）|
| `pdfimages -list` 张数 | 0 | 1126 |
| PDF 大小 | 1.88 MB（空壳）| 3.56 MB（真含图）|
| cairosvg 错误处理 | `sys.exit(1)` 阻塞 | fallback 显式暴露 + verify_pdf hard gate |
| verify exit 0 | 看起来"成功" | 实际"成功" |

## 完整检测脚本（任何发稿前必跑 6 项）

```python
import re, subprocess, os

# 1. PDF 真的嵌入了图
result = subprocess.run(['pdfimages', '-list', pdf_path], capture_output=True, text=True)
image_count = len([l for l in result.stdout.split('\n')[2:] if l.strip()])
assert image_count > 0, f"❌ PDF has 0 images! cairosvg fallback or WeasyPrint SVG issue"

# 2. HTML 没有 math error（5 个 pattern）
with open(html_path, encoding='utf-8') as f:
    html = f.read()
ERROR_PATTERNS = [
    r'class="mathjax-error"',
    r'class="math-error-(inline|block)"',
    r'data-mjx-error="[^"]+"',
    r'<merror[^>]*>',
    r'MATH\d+_PLACEHOLDER',
]
for pat in ERROR_PATTERNS:
    matches = re.findall(pat, html)
    assert not matches, f"❌ {pat}: {len(matches)} matches"

# 3. PDF 不是空壳（大小）
size = os.path.getsize(pdf_path) / 1024
assert size > 500, f"❌ PDF too small: {size:.0f} KB"
assert size < 5000, f"❌ PDF too large: {size:.0f} KB"

# 4. PDF 时间戳晚于 MD（确认是新 render 出来的）
import time
md_mtime = os.path.getmtime(md_path)
pdf_mtime = os.path.getmtime(pdf_path)
assert pdf_mtime > md_mtime, "❌ PDF older than MD — render.py silently failed"

# 5. cairosvg fallback 数（应该 0-5%，不是 90%）
fallback_count = html.count('[cairosvg error:')
assert fallback_count < len(re.findall(r'<mjx-container', html)) * 0.05, \
    f"❌ {fallback_count} cairosvg fallbacks (>5% — check SVG complexity)"

# 6. pdftotext 抽样
result = subprocess.run(['pdftotext', '-layout', '-f', '1', '-l', '1',
                        pdf_path, '-'], capture_output=True, text=True)
# 关键字抽检：报告主标题 + 至少一个公式相邻的英文符号
assert '扩散模型' in result.stdout
assert '$' not in result.stdout or '\\varepsilon' in result.stdout or 'bar' in result.stdout

print("✓ 6 项硬验证全过")
```

## 给未来 agent 的强约束

1. **任何 verify_*() 函数不要 `sys.exit(1)`**——verify 只报告，绝不阻止后续步骤
2. **发稿前 4 项必查**：`pdfimages -list` 张数 / PDF 时间戳 / HTML 6 个 error pattern / `pdftotext` 抽检
3. **任何"看起来成功"的报告渲染** → 第一时间 `ls -la` 看时间戳 → 确认 PDF 是这次 render 出来的
4. **记住 WeasyPrint + MathJax = 不兼容** → 必须 cairosvg 转 PNG（除非升级到 WeasyPrint 70+ 或换 PDF 后端如 weasyprint-pdfsync + Cairo）
5. **cairosvg fallback 永远 graceful**——永远不要让 cairosvg 失败阻塞整个 PDF 生成

## 相关文件

- `scripts/render.py` — 含 v7.2.1 修复（cairosvg → PNG 嵌入 + fallback + 移除 sys.exit）+ v7.2.1 YAML strip
- `references/render-verification-blind-spots.md` — v7.2 复盘（`\tag in aligned` + 6 项错误 pattern）
- `references/this file` — v7.2.1 复盘（WeasyPrint SVG + cairosvg fallback + sys.exit 删除 + YAML strip + footer leak）

---

# 附：v7.2.1+ 二次复盘 — YAML frontmatter + 页脚 leak

> 2026-06-23 修完上面 4 个坑后，用户要求"你再看看现在怎么样了"——重新跑 verify_render 才发现还有 2 个**完全不同的**问题：YAML frontmatter 漏出 + CSS 页脚 leak。这两个跟"公式渲染"无关，是**结构**层面的坑。

## 坑 5：YAML frontmatter 漏出到 PDF 第 1 页

**症状**：

`pdftohtml -i -noframes -f 1 -l 1 report.pdf` 输出第 1 页第 1 行：

```
title: 扩散模型：把生成拆成 1000 步去噪的方向场 subtitle: 从一团噪声到一张图——为什么 1000 步能跑
赢一步 author: Hermes Agent date: 2026-06-23
```

**4 行元数据**（`title:` / `subtitle:` / `author:` / `date:`）被当裸文本显示在 H1 标题**之前**——读者看到的第一行不是"扩散模型..."，而是 `title: 扩散模型...`。

**根因**：

`python-markdown` 库**不原生解析 YAML frontmatter**。Jekyll / Hugo 等静态站点生成器靠自定义插件处理；`markdown.Markdown(extensions=['extra'])` 完全不识别 `---` 包围的 YAML 块——把它当 Markdown 文本处理。`title:` 等冒号开头的行在 markdown 里是普通段落。

**修复**（render.py `strip_yaml_frontmatter`）：

```python
def strip_yaml_frontmatter(md_text: str) -> str:
    if not md_text.startswith('---'):
        return md_text
    m = re.match(r'^---\s*\n.*?\n---\s*\n', md_text, flags=re.DOTALL)
    if m:
        return md_text[m.end():]
    return md_text

# 在 md_to_html() 开头调用
md_text = strip_yaml_frontmatter(md_text)
```

**配套 verify_render 4b 项**（防止未来再漏）：

```python
fm_lines = re.findall(r'>\s*(title|subtitle|author|date):\s*[^<]*<', html)
if fm_lines:
    issues.append(f"❌ YAML frontmatter leaked: {len(fm_lines)} raw metadata lines in body")
```

**教训**：

任何用 `python-markdown` 库写报告生成管线的 agent 都会踩这个坑——**别假设它解析 frontmatter**。要 `pip install python-frontmatter` 或者手动 strip（render.py 选了手动 strip，避免加依赖）。

## 坑 6：`@page` 里的 `@bottom-left` / `@bottom-right` 自动 leak

**症状**：

每页底部显示：

```
RethinkFun-Style 技术报告
1 / 17
```

**根因**：

`report.css` 第 14-30 行（v7.2.1 之前）有：

```css
@page {
  size: A4;
  margin: 2cm 1.8cm 2.2cm 1.8cm;

  @bottom-right {
    content: counter(page) " / " counter(pages);
    ...
  }
  @bottom-left {
    content: "RethinkFun-Style 技术报告";
    ...
  }
}
```

WeasyPrint 完美支持 CSS Paged Media Module Level 3 的 `@bottom-*` 区域——自动在每页渲染。用户没明确要求页脚，但 CSS 模板里写了 → 出现。

**为什么是坑**：

- **页脚跟正文争注意力**——读者眼睛在阅读时不断被"X / 17"打断
- **署名"技术报告"每页都一样**——冗余信息密度为 0
- **页码**有目录可以代替，文本里页码没意义（流式阅读）

**修复**（v7.2.1 删 footer）：

```css
@page {
  size: A4;
  margin: 2cm 1.8cm 2.2cm 1.8cm;
  /* v7.2.1: Page footer disabled — was leaking "RethinkFun-Style 技术报告" + page numbers
     at the bottom of every page, which competed with body content for attention. */
}
```

**教训**：

CSS 模板里 `@bottom-left` / `@bottom-right` 是**强默认**——一旦写了就出现在每页。**写 CSS 时不主动加；用户明确要"页脚 + 页码"才加**。这是一个**反向默认**问题——能不加就不加。

## 检测脚本（发稿前必跑）

```bash
# 1. PDF metadata 和第 1 页内容分离检查
pdftohtml -i -noframes -f 1 -l 1 report.pdf /tmp/page1
head -50 /tmp/page1.html | grep -E "title:|subtitle:|author:|date:|^[0-9]+ / [0-9]+"
# 输出任何非空行 = 问题

# 2. PDF 全文 dump，看是否有 footer 漏
for p in 1 2 3 17; do
  pdftotext -f $p -l $p report.pdf - | tail -3
done
# 看 "RethinkFun-Style 技术报告" 或 "X / 17" 出现频率
```

## v7.2.1 完整复盘结论

修完 6 个坑后，PDF 才是真"发得出去"：

| 坑 | 影响 | 修了什么 |
|---|---|---|
| 1. WeasyPrint SVG 不兼容 | 公式 0 张图 | cairosvg → PNG → base64 |
| 2. cairosvg ex 单位 | cairosvg 失败抛错 | ex → px 替换 |
| 3. cairosvg 大 SVG 失败 | 11/574 公式漏 | fallback 到原 SVG |
| 4. sys.exit(1) 阻塞 | 新 PDF 从未生成 | 删 sys.exit |
| 5. YAML frontmatter leak | 4 行元数据裸文本 | strip_yaml_frontmatter() |
| 6. @page footer leak | 每页 2 行冗余 | 删 @bottom-* |

**核心教训**：**渲染管线有 6 个独立坑**——任何一个没修都会让用户看到"渲染离谱"或"页脚奇怪"或"元数据错位"。**verify_render() 必须覆盖这 6 项**，不能只查 MathJax 错误。

## 给未来 agent 的额外强约束

7. **YAML frontmatter 永远 strip**——`python-markdown` 不解析，漏出必死
8. **CSS `@bottom-*` 永远不主动加**——用户没说要页脚就别给页脚
9. **发稿前 2 项结构检查**：第 1 页 dump 看 metadata leak / 最后 3 行 dump 看 footer leak
10. **任何用户"你再看看现在怎么样了"的请求 → 立即 `ls -la` + `pdftohtml` 第 1 页 + `pdftotext` 最后 3 行**——这 3 个命令 5 秒内能抓出所有 v7.2.1 列的 6 类问题
