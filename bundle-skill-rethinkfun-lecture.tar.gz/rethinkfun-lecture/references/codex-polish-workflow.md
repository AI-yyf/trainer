# Codex 子 Agent 深度打磨 workflow

> 适用于：`rethinkfun-lecture` 这类有大量历史迭代（v6 → v19+）的 skill，需要"独立第三方审计"找出 SKILL.md / scripts / references 之间的内部矛盾和隐藏 bug。

## 触发场景

- skill 经历过 10+ 个版本迭代，SKILL.md 89KB+，references/ 有 10+ 文档
- 你已经在一个主线上磨了几小时，但发现还有"内部矛盾" / "过时说明" / "v6 行为但代码已 v19"的隐性 drift
- 你想"**完全交给 codex**"做深度审计 + 实际修改，而不是再列一份 plan 然后自己干

**recurring 用户原话**：
- "请你完全交给codex 帮你在深度调整打磨"
- "深度解决问题"
- "修改skill"
- "记得加--yolo"
- "使用 5.4xhigh"（gpt-5.4-xhigh）

## 关键 flag & 平台坑（实测）

### 1. `--yolo` 在 codex CLI 0.141+ 的真实 flag 名

```bash
# ❌ 老文档/老 skill 里写的 --yolo — codex 0.141+ 不认
codex exec --yolo "..."

# ✅ 实际 flag（codex exec --help 里能看到）
codex exec --dangerously-bypass-approvals-and-sandbox "..."

# ✅ 配 sandbox 配置（推荐两个一起用，确保不弹 approval）
codex exec \
  --dangerously-bypass-approvals-and-sandbox \
  -c sandbox=danger-full-access \
  ...
```

### 2. `gpt-5.4-xhigh` 在 Dora2API proxy **返回 503**

实测：cc-switch 配置的 custom provider (Dora2API) **不支持 `gpt-5.4-xhigh` 模型名**——连续 5 次 reconnect 后 503 Service Unavailable。

**回退**：
```bash
# ❌ 503
codex exec -m gpt-5.4-xhigh -c model_reasoning_effort=xhigh ...

# ✅ 工作
codex exec -m gpt-5.4 -c model_reasoning_effort=high ...
```

**为什么这样工作**：`gpt-5.4` 是 cc-switch 当前激活的 model 名称（`~/.codex/config.toml` 里 `model = "gpt-5.4"`），reasoning_effort=high 已经够"深度思考"。

**未来的 fallback 链**（proxy 升级后）：

| 模型 | reasoning effort | 适用场景 |
|---|---|---|
| `gpt-5.4` | `high` | 默认 (Dora2API 当前支持) |
| `gpt-5.4` | `xhigh` | 更深推理（先试，503 就降级） |
| `gpt-5.4-xhigh` | (内置) | 未来 proxy 支持时直接用 |
| `claude-4` / `o3` | 任意 | proxy 切换 provider 时备选 |

### 3. prompt 文件**不要放 `/tmp`**——会被 systemd-tmpfiles 清掉

```bash
# ❌ /tmp 在 codex 还没读到就被清理（实测一次）
cat > /tmp/codex-prompt.md << 'EOF'
...
EOF
codex exec "$(cat /tmp/codex-prompt.md)"  # ← cat: No such file or directory

# ✅ 放 workdir 或 ~/.hermes/cache/，绝对稳定
mkdir -p /home/yanyunfei/codex-work/prompts
cat > /home/yanyunfei/codex-work/prompts/v720-polish.md << 'EOF'
...
EOF
codex exec "$(cat /home/yanyunfei/codex-work/prompts/v720-polish.md)"
```

## 完整工作流（5 步）

### Step 1: 建 workdir + git baseline

```bash
WORK=/home/yanyunfei/codex-work/<task-name>
mkdir -p $WORK
cp -r /home/yanyunfei/.hermes/skills/<skill-name>/* $WORK/
# 加上测试输入（如果适用）
cp /path/to/test-input.md $WORK/

cd $WORK
git init -q
git add -A
git -c user.email=hermes@local -c user.name=Hermes commit -q -m "<version> baseline"
git log --oneline   # 记录 commit hash，codex 之后 diff 用
```

**为什么 workdir 而不是直接改 skill 目录**：
- codex 可能改错，留 baseline 可以回滚
- skill 目录是 Hermes 实时加载的，改动会污染下次激活
- workdir 可以保留多版本（v720 / v721 / v722）做 A/B

### Step 2: 写 prompt（中文，详细到 codex 无需问问题）

**必须包含**：
1. **工作目录 + baseline commit**（让 codex 自己 diff）
2. **目标 + 范围**（明确"必须改文件" vs "只 review"）
3. **输入文件清单**（路径 + 用途）
4. **必须做的 4 件事**：全文审计 / 深度打磨 / 实际验证 / 提交报告
5. **约束**（不能动 .git 历史 / 不能动测试输入 / 必须中文报告）
6. **完成标准**（至少改 1 个文件 / 验证通过 / 用中文输出）

**prompt 模板**：
```markdown
# 任务：深度打磨 <skill-name>

## 工作目录
`<absolute-workdir>` (已有 git baseline: `<hash>` "<version> baseline")

## 目标
你是一个深度技术审计 agent，独立审计并深度打磨 `<skill-path>`...
当前状态：<version-with-key-fixes>...
但 skill 内可能还有：
1. <internal-contradictions>
2. <outdated-docs>
3. <hidden-blind-spots>

## 输入文件（在 workdir 内）
- `<file>` — <purpose>
- `<file>` — <purpose>
...

## 必须做的事

### 1. 全文审计
读 SKILL.md / scripts/ / templates/ / references/，找出：
- **内部矛盾**
- **过时说明**
- **冗余内容**
- **盲点**

### 2. 深度打磨（必须改文件）
- 修正 SKILL.md...
- 优化 scripts/...
- 更新 references/...

### 3. 必须实际验证（不能只看代码）
- 跑 render 命令
- 验证 PDF / page count / 0 errors
- 验证 formula attributes (retina + char/line)
- **任何回归都不允许**

### 4. 提交 + 报告
- git commit
- git diff --stat
- 报告: 改了什么 / 验证结果 / 是否回归

## 约束
- 不要修改 .git/ 历史
- 不要修改 <test-input>
- 用中文回复

## 完成标准
- 至少改 1 个文件
- git commit
- 验证通过
- 中文报告
```

### Step 3: 启动 codex（**background + notify**）

```bash
# 关键：background=true + notify_on_complete=true
# 因为 gpt-5.4 high reasoning 经常跑 5-15 分钟
codex exec \
  --dangerously-bypass-approvals-and-sandbox \
  -m gpt-5.4 \
  -c sandbox=danger-full-access \
  -c model_reasoning_effort=high \
  --skip-git-repo-check \
  -C <workdir> \
  "$(cat <prompt-file>)" 2>&1 | tail -200
```

**为什么 `tail -200`**：codex 输出可能上千行（reasoning trace + tool calls），tail -200 留最后总结，够用。

**为什么 `--skip-git-repo-check`**：workdir 刚 `git init` 完，codex 默认会检查"是不是 trusted git repo"——跳过省一次 prompt。

### Step 4: 等待 + 进度监控

```bash
# poll 输出
poll codex_pid  # Hermes process tool

# 实时看 git 改动（codex 改文件了）
cd <workdir> && git status --short

# 实时看 commit
cd <workdir> && git log --oneline
```

**典型 timeline**（gpt-5.4 high, 89KB SKILL.md + 14 references + 3 scripts）：
- 0-30s: 启动 + reading phase
- 30s-5min: thinking + 第一批 tool calls
- 5-15min: 主要编辑 + 多次重读
- 15-20min: 验证（render + check）+ 最终报告

### Step 5: 应用结果到真实 skill 目录

```bash
# 看 codex 改了啥
cd <workdir>
git log --oneline
git diff --stat HEAD~N..HEAD

# 验证（**重要**——不要直接 cp，要先在自己环境重跑一次）
python3 scripts/render.py <test-input>.md -o /tmp/test-render.pdf
python3 scripts/verify_pdf.py /tmp/test-render.pdf
python3 scripts/verify_formulas.py /tmp/test-render.html

# 全过 → copy 到真 skill 目录
rsync -av --delete \
  --exclude='.git' \
  --exclude='*.bak.md' \
  --exclude='diffusion-model-report.*' \
  <workdir>/ /home/yanyunfei/.hermes/skills/<skill-name>/

# 触发 Hermes 重新加载（hermes agent 自己会检测 mtime）
```

## 边界情况

### codex 503 持续 → 降级到本地 audit

如果 `gpt-5.4-xhigh` / `gpt-5.4` 都 503：
1. 看 proxy 状态（`curl -I https://gpt.r0vzatp3j.nyat.app:33867/`）
2. 切 cc-switch provider
3. 实在不行，本地用 `claude` / `o3` 在 execute_code 里写一个 audit script（read all files → grep contradictions → output report）

### codex 跑完没改文件

`git log` 没新 commit → codex 只做了 review 没改：
- 看 codex 输出尾部（应该有"would do X but didn't" 之类的话）
- 加一句到 prompt："**强制要求**：至少改 1 个文件，否则不算完成"
- 重跑

### codex 改了但引入回归

`verify_pdf` 失败 / `verify_formulas` 失败：
- `git log` 找 codex 的 commit
- `git show <hash>` 看具体改了什么
- 如果是 pitfall 退化（如 v7.5 修好的黑块又回来），**回滚那个 commit**（`git revert`）
- 把"不要再走这条反修复路径"写进 prompt 重跑

## 视觉证据（visual fix 任务的硬要求）

**关键发现（v7.20 vs v7.21 polish 对比，2026-06-24）**：

- **v7.20 polish**：prompt 只说"验证所有 12 display 公式 retina=2.0 + char/line=14px" → codex 跑完 attribute 检查，commit 9e18e38，**号称 PASSED safe to ship**。用户看到 PDF 立即发现 3 个 P0 视觉问题（CSS 拉伸公式 + 实心黑块）。
- **v7.21 fix**：prompt 包含 6 张 300 DPI audit 页图 + 坐标级 audit 报告 → codex 上来先看图，**改了 report.css 加 max-height + !important**（直接命中根因）。

**结论**：让 codex 修"视觉问题"时，**必须给真实页面图 + 坐标级 audit**。attribute-only prompt 必失败。

### 视觉证据打包模板

```bash
# 1. 把当前 PDF 复制到 workdir
cp /path/to/current.pdf <workdir>/audit-input.pdf

# 2. 抽 300 DPI 全页
mkdir -p <workdir>/_audit
for p in $(seq 1 $(pdfinfo <workdir>/audit-input.pdf | grep Pages | awk '{print $2}')); do
  pdftoppm -png -r 300 -f $p -l $p <workdir>/audit-input.pdf <workdir>/_audit/p$p
done

# 3. 跑坐标级 audit（输出每页 P0/P1/P2 列表）
python3 scripts/visual_audit.py <workdir>/audit-input.pdf --report <workdir>/audit-report.txt
```

### codex prompt 必须包含的视觉证据段

```markdown
## 视觉证据（在 workdir 内）
- `audit-input.pdf` — 当前 PDF（含已知视觉问题）
- `_audit/p1-01.png ... _audit/pN-NN.png` — 300 DPI 全页抽图
- `audit-report.txt` — 坐标级问题清单（每页 P0/P1/P2）

## 完成标准（额外加硬）
- 必须把 p4 / p11 重新抽 300 DPI PNG 跑 PIL 分析
- 公式显示尺寸 / 原始尺寸 aspect 比 ≈ 1（不允许 ~5x 拉伸）
- 不允许有 >5000px² 实心黑块
- 修改后 git commit，重新跑 visual_audit.py 必须 0 issues
```

**没给视觉证据的视觉修复任务 = 必失败，不要省**。

## 给用户的报告模板

codex 跑完后，**自己**给用户发总结（不要直接贴 codex 原始输出，太长）：

```markdown
codex 跑完了，**改了 N 个文件**：

- `scripts/render.py`: 修了 [具体问题]
- `references/xxx.md`: 更新 [过时内容]
- `SKILL.md`: 新增 [新 pitfall 编号]

验证（v720 实际跑过）：
- PDF: 1.77 MB / 16 页
- 574 个公式全部 retina=2.0, char=14px
- 0 cairosvg errors
- 回归测试：v7.19 baseline 对比无退化

要不要我把它推到真 skill 目录？
```

**关键**：用户原话是"完全交给codex"——意味着你**应该真正让 codex 做工作**，不要在 prompt 里写"先列个计划"然后自己实现。codex 有完整文件权限（--yolo），让它真改。
