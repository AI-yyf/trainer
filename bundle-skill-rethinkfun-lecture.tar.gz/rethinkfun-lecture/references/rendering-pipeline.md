# Markdown → PDF 渲染管线技术细节

本文件是 `scripts/render.py` 背后的关键技术沉淀。**修改渲染逻辑前请先读完**。

> **当前栈**：MathJax v3 + cairosvg retina PNG + WeasyPrint。本文保留通用坑（数学抽取、`<em>` 渗漏、verifier 误报、视觉差异化 CSS、调试清单）；KaTeX 专属段落仅作历史记录。当前实现的详细参数和 fallback 规则见 `references/retina-render-pipeline.md` 与 `scripts/render.py`。

## TL;DR

- **数学公式用 MathJax v3**，不是 KaTeX 也不是 latex2mathml。
  - ~~KaTeX 路径~~（**v7.1 废弃**）：输出 CSS 定位 HTML，复杂中文公式支持弱
  - **MathJax v3**（**当前**）：输出纯 inline SVG glyph，LaTeX 风最接近，无字体依赖
- **数学抽取必须在 markdown 之前**，否则 `_` 被当斜体。
- **任何渲染异常都要显式暴露**：`render.py` 负责前置告警，`scripts/verify_pdf.py` 负责最终 hard gate。

完整 MathJax v3 调试笔记见 `references/mathjax-v3-pipeline.md`（替代原来的 `katex-pdf-pipeline.md`）。

## 1. 核心坑：markdown 会吃掉 LaTeX 的下划线

**问题**：`markdown` 库默认把 `_x` 识别成 emphasis，单下划线会被包成 `<em>`。如果先跑 `md.convert(md_text)`，再跑 KaTeX CLI，所有形如 `L_{\mathrm{simple}}` 的 LaTeX 已经变成 `L<em>mathrm{simple}</em>`，KaTeX 解析必然失败 → fallback 到 `katex-error` 红框。

**正确顺序**：

```
1. extract_math_placeholders(md_text)   # 用正则把 $$...$$ 和 $...$ 抽出来，放进占位符 \x00MATH0000\x00
2. md.convert(text_with_placeholders)   # markdown 只看到占位符，不会动 _ 和 *
3. restore_math_in_html(html, phs)      # 占位符 → KaTeX HTML（shell-out 到 node katex/cli.js）
```

**占位符必须避开 markdown 元字符**：用 `\x00MATH0000\x00` 这种 NULL 字符包裹的格式，确保 markdown 不会把它当特殊语法。

## 2. 行内 vs 块级正则区别

- 块级：`\$\$(.+?)\$\$` + `re.DOTALL`（贪婪要小，要支持多行公式）
- 行内：`(?<!\\)\$([^$\n]+?)\$(?!\$)` — 必须有负向断言防止吃掉 `$$...$$` 的尾 `$`，也排除 `\$` 转义

## 3. `<em>` 渗漏检测

即使按正确顺序跑了，理论上仍可能有 `<em>` 出现在 math 容器里。verify_render 必须检查：

```python
em_in_math = re.findall(r'math-(block|inline)[^<]*<em>', html)
```

## 4. CSS 类名误报

`math-error-inline` 和 `math-error-block` 是 fallback span 的 class name，同时又是 CSS 里的 selector。verifier 用 `html.count()` 简单计数会误报（CSS 里的定义也被算进去）。

**修复**：verify 前先 `re.sub(r'<style>.*?</style>', '', html)` 去掉 style 块。

> **v7.1 更新**：现在用 MathJax v3，错误回退的 class 是 `mjx-error`（MathJax v3 的错误容器），HTML 里出现 `mjx-error` 一定是真实问题。MathJax v3 CSS 里也没有 `mjx-error` 样式定义，所以**这个误报坑在 MathJax 路径下也不存在了**。

## 5. verify_render 必查清单（MathJax v3 版本，v7.1）

| 检查 | 失败原因 | 修复方向 |
|---|---|---|
| `mjx-error` 出现（v7.1 MathJax） | MathJax 解析失败 | 看占位符里存的 LaTeX，手测 `node render_math.js` |
| ~~`katex-error` 出现~~（v7.1 前） | ~~KaTeX 解析失败~~ | ~~看占位符里存的 LaTeX~~ |
| `MATH####` 占位符残留 | restore 漏掉了 | 检查 placeholder 列表和 html 内容是否一致 |
| 正文有原始 `$...$` | 抽取正则没匹配上 | 检查是否有 `\$` 转义或嵌套 `$` |
| `<em>` 在 math 容器里 | markdown 先于 math 处理 | 确认管线顺序 |
| mermaid fallback 提示 mmdc 缺失 | mmdc 没装 | 文档说明，不算 fatal |
| 公式在 PDF 里变方块或回退默认字体 | WeasyPrint 没找到 MathJax 字体 | v7.1 路径下**不应该出现**——MathJax 输出纯 inline SVG，无外部字体依赖。如果出现说明 render.py 还在用旧 KaTeX 路径 |

任何一项失败 → render.py 退出码 1，**不发 PDF**。

## 6. CSS 视觉差异化铁律

math 和 code 必须一眼区别于正文，否则读者分不清哪里是公式：

**行内 math**（KaTeX 已经包了 `.katex`，外面再包 `.math-inline`）：
```css
.math-inline {
  background: #fff8e1;
  border: 1px solid #f0b400;
  border-radius: 3px;
  padding: 0.05em 0.4em;
}
```

**块级 math**：
```css
.math-block {
  background: #fffbf0;
  border: 2px solid #ff9800;
  border-radius: 5px;
  padding: 1em 1.2em;
  font-size: 1.15em;
  box-shadow: 0 1px 3px rgba(255, 152, 0, 0.15);
}
```

**代码块**（必须深色 + 高亮）：
```css
pre {
  background: #1e1e1e;
  color: #d4d4d4;
  border-left: 5px solid #4caf50;
  font-family: 'JetBrains Mono', 'DejaVu Sans Mono', monospace;
}
pre span.k { color: #c586c0; font-weight: bold; }  /* Pygments 暗主题 */
```

**错误回退**（KaTeX 解析失败时）：
```css
.katex-error {
  background: #ffebee;
  border: 2px dashed #d32f2f;
  color: #b71c1c;
  padding: 0.5em 1em;
}
```

## 7. 调试快速检查清单

PDF 出来看着不对？按这个顺序查：

```bash
# 1. 看 HTML 调试版（render.py 自动保存）
less report.html
grep -c "mjx-error" report.html           # v7.1: 应该 = 0
grep -c "math-block" report.html           # 应该是公式数
grep "<em>" report.html                    # 检查是否渗入 math（CSS 之外不应有）
grep -c 'class="mjx-container"' report.html  # v7.1: MathJax 渲染数

# 2. 看 PDF 文本提取
pdftotext -layout report.pdf - | head -100
pdftotext -layout report.pdf - | grep "L_simple"   # 看公式是否堆叠（应该是 εθ(α¯t x0 + ...) 而不是 εθ(α¯tx0+...)

# 3. 看元数据
pdfinfo report.pdf | grep Pages

# 4. 直接测 MathJax v3
cd /home/yanyunfei/reports/mathjax-test && node -e "
const mj = require('mathjax-full').tex2svg;
const svg = mj('L_{\\\\mathrm{simple}}(\\\\theta)');
console.log(svg.outerHTML.slice(0, 200));
"
```

## 8. WeasyPrint 已知行为

- **MathJax v3 不需要字体解析**（v7.1）：输出纯 inline SVG，glyph 都是 `<path>`，WeasyPrint 不需要找外部字体。这意味着 `base_url` 不再必须指向 `templates/`，但**保留传 `base_url=str(templates_dir)` 没坏处**（用于解析 CSS 里其他相对路径）。
- **KaTeX 字体必须能解析**（~~v7.1 前~~，已废弃）：KaTeX CSS 用 `url(fonts/...)` 相对路径，`base_url` 必传。
- **MathML 在 MathJax v3 输出里是冗余的**：MathJax v3 同时输出 `<mjx-container>` 和 `<svg>`，WeasyPrint 用 SVG 层渲染。MathML/mjx-container 是给屏幕阅读器用的。
- **中文字体链首位必须是 `Noto Serif/Sans CJK SC`**，否则豆腐方块。
- **Pygments 高亮现在通过 `pre span.k` 等选择器匹配**（不用 `.codehilite` 容器，因为新版 markdown 库的 `codehilite` 扩展不再生成 wrapper class）。
- **`$` 匹配冲突**：MD 里如果有 USD 价格（`$100`），会被误判为 inline math 起点/终点。脚本里用了 `(?<![\\$])\$(?!\$)` 防止，但还是有边界情况。

## 9. 历史教训：发 PDF 之前必须 verify_render

2026-06-23 那次会话：第一次发 PDF 时里面有 `math-error-block` 红色回退块（latex2mathml 解析失败），但我直接发了。被大哥怼："你自己报告你都有报错，你就直接发给我了，这样行吗"

现在 `render.py` 末尾 `verify_render()` 强制卡住，**任何异常 exit 1，PDF 不出**。这条铁律不许绕过。

---

**附录：完整 KaTeX 调试笔记见 `references/katex-pdf-pipeline.md`**
