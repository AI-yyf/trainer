# Retina 渲染管线（v7.19 — 修公式模糊）

## TL;DR

cairosvg → PNG → base64 → `<img>` 嵌入的 pipeline，**必须**让 PNG 分辨率 ≥ 2× display 分辨率。任何 `output_height = display_h` 的写法都是错的——cairosvg 输出 PNG 是 fixed pixels，1× raster 在 1× display = 锯齿/模糊；2× raster 在 1× display = 锐利（downscale 抗锯齿）。

**v7.19 实测**：574 个公式（562 inline + 12 display）全部 retina=2.0，全部 char visual 14.0px（1em body）。v7.5–v7.18 同样字号设置但 retina=1.0 → 全部模糊。

## 为什么之前的版本没发现

`verify_pdf.py`（v7.5–v7.8）的所有结构检查**全过**：

- 黑块 smoke test → 过（没黑块）
- YAML frontmatter leak → 没有
- Footer leak → 没有
- MathJax error attr / `<merror>` → 没有
- cairosvg 失败扫描 → 0 个

但用户拿到 PDF 后说"你能不能让每一个公式输出的都不会模糊"——所有公式都是锯齿/重模糊。

**根因**：blur 是**视觉问题**，不是结构问题。smoke test 抓 75×72 黑块、YAML leak、cairosvg 失败——但**完全不查 PNG 像素质量**。v7.19 retina 是**第一个**让"公式视觉锐利"成为可验证属性的版本。

## 根因分析

v7.5–v7.18 的 render.py 用 `EX_TO_PX=7` 同时承担两个轴：

```python
EX_TO_PX = 7.0  # 1ex = 7px（在 SVG natural x-height 单位里，这是对的）
SCALE = 1.0

# Display path
target_h = int(round(h_ex * EX_TO_PX * SCALE))  # h_ex=1 → target_h=7px
png_bytes = cairosvg.svg2png(bytestring=s, output_height=target_h)
# → 1 行公式 raster 成 7px 高的 PNG
# → CSS/HTML 把 <img> 拉到 20px 显示
# → 3× upscale → 模糊
```

**EX_TO_PX=7 是 SVG 的自然 x-height 单位**（1ex ≈ 0.5em body，body 14px 时 1ex ≈ 7px）。所以：

- SVG intrinsic size：35×7（1 行公式）
- PNG raster size：35×7
- Display size（CSS/HTML）：100×20（拉大到 1em body）
- **Scale factor：20/7 ≈ 2.86× upscale**

cairosvg → PNG 是像素采样。PNG 是 fixed pixels，浏览器拉大显示是 bilinear/nearest upscaling——锯齿 + 模糊 = 1990s GIF 效果。

## 修复 v7.19：解耦两个轴

```python
# render.py constants
EX_TO_PX = 7.0          # 仅控制 SVG intrinsic width/height attribute
DISPLAY_EX_TO_PX = 20.0 # 新参数：display 公式 target_h（1em body per line）
RETINA = 2              # 新参数：每公式 rasterize 在 2× target_h

# Display path
if is_display:
    if h_ex > 0:
        target_h = int(round(h_ex * DISPLAY_EX_TO_PX))  # 1 行 = 20px, 5 行 = 100px
    else:
        target_h = 20
    target_h = max(20, target_h)
    retina_h = target_h * RETINA                         # 1 行 raster = 40px, 5 行 = 200px
    try:
        png_bytes = cairosvg.svg2png(bytestring=s.encode('utf-8'),
                                       output_height=retina_h)
        png_w = int.from_bytes(png_bytes[16:20], 'big')
        png_h = int.from_bytes(png_bytes[20:24], 'big')
        b64 = base64.b64encode(png_bytes).decode('ascii')
        data_url = f"data:image/png;base64,{b64}"
    except Exception:
        pass
    display_w = max(1, int(round(target_h * png_w / png_h)))
    return (f'<div class="math-block">'
            f'<img src="{data_url}" alt="formula" '
            f'width="{display_w}" height="{target_h}" '
            f'style="display:block; margin:0.6em auto; max-width:100%; height:auto;"/>'
            f'</div>')

# Inline path（同样 retina）
display_h = 20
retina_h = display_h * RETINA
try:
    png_bytes = cairosvg.svg2png(bytestring=s.encode('utf-8'),
                                  output_height=retina_h)
    png_w = int.from_bytes(png_bytes[16:20], 'big')
    png_h = int.from_bytes(png_bytes[20:24], 'big')
    b64 = base64.b64encode(png_bytes).decode('ascii')
    data_url = f"data:image/png;base64,{b64}"
except Exception:
    pass
display_w = max(1, int(round(display_h * png_w / png_h)))
return (f'<img src="{data_url}" alt="formula" '
        f'width="{display_w}" height="{display_h}" '
        f'style="vertical-align: middle;"/>')
```

**关键设计选择**：

1. **EX_TO_PX 只控制 SVG intrinsic width/height attribute**——cairosvg 用它来算 aspect ratio（不指定 output_height 时回退到 intrinsic size × scale）。
2. **DISPLAY_EX_TO_PX 控制 display 公式 target_h**——1em body per line（14px body + 一点 padding = 20px）。
3. **RETINA=2 让 PNG 永远是 2× display**——这是 sharpness 的唯一来源。

## 公式 char visual 校验

对每个公式：

```
char_visual = 0.7 × target_h / h_ex
```

v7.19 实测：

| 类型 | img WxH | PNG WxH | retina | h_ex | char/line |
|---|---|---|---|---|---|
| Display 1-line (h_ex=2.30) | 954×46 | 1909×92 | 2.0 | 2.30 | **14.0px** |
| Display 2.7-line | 1097×54 | 2194×108 | 2.0 | 2.70 | **14.0px** |
| Display 3.15-line (×4) | ~1100×63 | ~2200×126 | 2.0 | 3.15 | **14.0px** |
| Display 5.2-line | 760×104 | 1520×208 | 2.0 | 5.20 | **14.0px** |
| Display 5.6-line (×2) | ~1130×112 | ~2260×224 | 2.0 | 5.60 | **14.0px** |
| Display 5.95-line | 1074×119 | 2148×238 | 2.0 | 5.95 | **14.0px** |
| Display 6.75-line | 695×135 | 1390×270 | 2.0 | 6.75 | **14.0px** |
| Display 9.65-line | 948×193 | 1896×386 | 2.0 | 9.65 | **14.0px** |
| Inline (×562) | varies×20 | varies×40 | **2.0** | n/a | **14.0px** |

**全部 574 个公式 = retina 2.0 + char 14.0px**（1em body）。

## 检测脚本（发稿前必跑）

```python
import re, base64, struct
from pathlib import Path

html = Path('report.html').read_text()

# 抓所有 math 公式的 <img>
display_imgs = re.findall(
    r'<div class="math-block">\s*<img src="data:image/png;base64,([^"]+)" alt="formula" width="(\d+)" height="(\d+)"',
    html,
)
inline_imgs = re.findall(
    r'<img src="data:image/png;base64,([^"]+)" alt="formula" width="(\d+)" height="(\d+)" style="vertical-align',
    html,
)

def png_dims(b64):
    png = base64.b64decode(b64[:100])
    return struct.unpack('>I', png[16:20])[0], struct.unpack('>I', png[20:24])[0]

failed = 0
for label, imgs in [('display', display_imgs), ('inline', inline_imgs)]:
    for i, (b64, w, h) in enumerate(imgs):
        png_w, png_h = png_dims(b64)
        retina = png_h / int(h)
        if retina < 2.0:
            print(f"❌ [{label} #{i+1}] img={w}×{h} PNG={png_w}×{png_h} retina={retina}")
            failed += 1

print(f"\n{'✓' if failed == 0 else '❌'} {len(display_imgs)} display + {len(inline_imgs)} inline formulas, {failed} below 2× retina")
```

或者一行 shell：

```bash
python3 -c "
import re, base64, struct
from pathlib import Path
html = Path('report.html').read_text()
imgs = re.findall(r'<img src=\"data:image/png;base64,([^\"]+)\" alt=\"formula\" width=\"(\d+)\" height=\"(\d+)\"', html)
below_2x = sum(1 for b64, w, h in imgs if struct.unpack('>I', base64.b64decode(b64[:100])[20:24])[0] / int(h) < 2.0)
print(f'{below_2x}/{len(imgs)} formulas below 2× retina (must be 0)')
"
```

## v7.18 vs v7.19 对比（实测数字）

| | v7.18 | v7.19 |
|---|---|---|
| target_h (1-line display) | 7px (`h_ex × EX_TO_PX × SCALE = 1 × 7 × 1`) | 20px (`h_ex × DISPLAY_EX_TO_PX = 1 × 20`) |
| PNG raster_h (1-line display) | 7px | 40px (retina) |
| CSS display_h | 20px | 20px |
| Upscale factor | 2.86× | **0.5×** (downscale 抗锯齿) |
| Char visual | 14.7px (1em body) | 14.0px (1em body) |
| Visual sharpness | **模糊** | **锐利** |
| Retina ratio | 0.35× | **2.0×** |

## 反修复教训（v7.12 误诊）

之前用过 `cairosvg output_width = 500` 想"统一公式宽度"——结果：

- 1 行短公式（intrinsic 35×7）被横向拉散到 500×100 = **14× stretch**
- 5 行 aligned（intrinsic 200×35）也被拉到 500×88 = **2.5× stretch**
- **结果是更糟的模糊**（横向纵向都拉伸）

**修复 v7.19**：用 `output_height`（不是 output_width），让 aspect 由 SVG intrinsic 决定（cairosvg 自动算 output_width = output_height × svg_aspect）。短公式不会被横向拉散。

## retina 的额外好处：超宽公式自动缩也锐利

```html
<img src="..." width="1500" height="100" style="max-width:100%; height:auto;"/>
```

如果 1500px > A4 内容宽（约 624px @ 96dpi），浏览器自动按 aspect 缩到 624×42。**v7.18（1× raster）**：缩到 624×42 时 PNG 也是 624×42 = 0.5× retina = **亚像素模糊**。**v7.19（2× raster）**：缩到 624×42 时 PNG 是 1500×100，被下采样到 624×42 = 1× retina = **依然锐利**。

所以 v7.19 可以放心保留 `max-width:100%`——超宽公式**不会**因为 CSS 自动缩而变模糊。

## 与其他 pitfall 的关系

- **#50（公式字号不和 body 字号匹配 = 行被撑爆）**：#50 是**尺寸错**（字号选错），#55 是**分辨率错**（字号对了但 raster 低了）。两者**完全独立**——v7.5–v7.18 #50 修好了但 #55 没修（字号对了、smoke test 过了、公式还是模糊）。
- **#54（aligned env SVG 把尺寸藏在 style="min-width"）**：#54 是 cairosvg 直接抛错的根因（需要 fallback chain 解析 min-width），#55 是 cairosvg **没**抛错但渲染出模糊 PNG 的根因（EX_TO_PX 用错了）。两个 pitfall 都需要修，但**修的代码位置不同**——#54 在 mjx_to_img 的 ex 提取，#55 在 mjx_to_img 的 PNG rasterize。
- **#57（max-width: 100% retina 仍生效）**：#57 是 #55 的扩展应用——retina rasterize 让 CSS 自动缩也锐利。

## 完整发稿 pipeline（v7.19）

```bash
python3 scripts/render.py report.md -o report.pdf
python3 scripts/verify_pdf.py report.pdf       # 必跑：黑块 / YAML / footer / MathJax error

# 新增 v7.19：retina + char visual 校验
python3 -c "
import re, base64, struct
from pathlib import Path
html = Path('report.html').read_text()
imgs = re.findall(r'<img src=\"data:image/png;base64,([^\"]+)\" alt=\"formula\" width=\"(\d+)\" height=\"(\d+)\"', html)
below_2x = sum(1 for b64, w, h in imgs if struct.unpack('>I', base64.b64decode(b64[:100])[20:24])[0] / int(h) < 2.0)
assert below_2x == 0, f'❌ {below_2x}/{len(imgs)} formulas below 2× retina'
print(f'✓ {len(imgs)} formulas all ≥ 2× retina')
"

# v7.7+ 视觉抽检
pdftoppm -r 150 -f 1 -l 1 report.pdf _p1 -png
pdftoppm -r 150 -f 4 -l 4 report.pdf _p4 -png
pdftoppm -r 150 -f 7 -l 7 report.pdf _p7 -png
# 肉眼过一遍：字号 / 锐利 / 溢出

# 必跑（v7.8+）
pdftotext -layout report.pdf - | grep -c '\[公式渲染失败'  # 必须 = 0

# 发 PDF + 3 张 PNG 给用户
```

**任何一步省了准备挨骂**。

## 为什么 SVG → PNG 这件事本身就需要 retina

浏览器渲染矢量 SVG 时**始终**用显示器 native DPI（macOS retina 屏 ≈ 2× DPI，外接 1× 屏 = 1× DPI）。SVG 的"矢量"属性让它可以任意 DPI 渲染而**不模糊**。

但 **cairosvg 是将 SVG rasterize 成 PNG**——这一步**丢失矢量属性**，PNG 是 fixed pixels。浏览器再显示这个 PNG 时，按显示器的 DPI 缩放：
- macOS retina 屏显示 PNG：每个 PNG 像素对应 0.5× 显示像素 = 锐利（downscale 抗锯齿）
- 外接 1× 屏显示 PNG：每个 PNG 像素对应 1× 显示像素 = 锐利（1:1）
- **macOS retina 屏显示 v7.18 的 PNG**（7px tall，display 20px）：每个 PNG 像素对应 2.86× 显示像素 = **upscale 模糊**

所以 v7.19 的 retina 不是"奢侈"，是 PNG 显示的**最低标准**——任何 vector → raster → display 的 pipeline 都要满足 `raster_h ≥ 2 × display_h`。

## 相关文件

- `scripts/render.py:mjx_to_img()` — v7.19 retina 实现（EX_TO_PX / DISPLAY_EX_TO_PX / RETINA 三个常量 + mjx_to_img 的 display / inline 两条路径都用 `output_height = target_h × RETINA`）
- `references/font-size-debugging.md` — v7.7 字号调试（v7.19 之前是 1× raster，#50 已修但 #55 没修）
- `references/mathjax-aligned-svg-pitfall.md` — v7.8 aligned env 的 SVG size 解析
- `references/cairosvg-mathjax-pipeline.md` — 完整 cairosvg 6 步 pipeline
- `references/weasyprint-svg-incompatibility.md` — WeasyPrint 不能直接吃 SVG，必须 cairosvg→PNG
