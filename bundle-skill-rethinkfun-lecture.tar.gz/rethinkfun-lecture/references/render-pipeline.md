# 三层 PDF 渲染管线 — 知识库与踩坑史

> 为什么有这份文档：三层数学渲染（latex2mathml → KaTeX → MathJax v3 → cairosvg retina PNG）踩了一圈坑才稳定下来。本文档记录每次切换的原因、安装命令、已知限制，方便后续 agent 接手或回退；当前实现以 `scripts/render.py` 和 `references/retina-render-pipeline.md` 为准。

---

## 一、为什么最终选 MathJax v3 SVG 输出

### 三个候选方案的失败 / 通过记录

| 方案 | 渲染质量 | 中文混排 | 字体依赖 | 包体积 | 决定 |
|---|---|---|---|---|---|
| **latex2mathml → MathML** | ❌ 分数不堆叠、根号不画 | ⚠️ 字体回退不稳 | — | 小（pip 装） | 不用 |
| **KaTeX CLI (HTML+CSS)** | ✅ 分数/根号都画 | ⚠️ CSS `ex` 单位在中文环境下不稳 | 60 个 woff/woff2 (~1.2MB) | snap 自带 | 备选 |
| **MathJax v3 SVG** | ✅ STIX 风格，最接近 LaTeX Computer Modern | ✅ 稳定 | 0（glyph 全内联 SVG `<path>`） | ~43MB | **主选** |

### latex2mathml 为什么不行

WeasyPrint 用 Pango 渲染 MathML。Pango 对 `<mfrac>`、`<msqrt>`、`<mfenced>` 支持不完整 —— 分数不堆叠、根号符号位置错、大括号不动态撑高。pdftotext 抓出来的公式全是平铺文字：`1/α_t`、`√(1-α̅_t)·ε` 这种。视觉上跟正文几乎无差别。

### KaTeX 为什么不够好

KaTeX 输出 HTML + CSS 定位的数学，分数用 `display: inline-block` + 绝对定位堆叠，效果不错。但：

1. KaTeX 是 React 出生的，CSS 单位偏好 px / em
2. 中文环境下 CSS 单位 `ex` 计算不稳定（取决于行内字体的 x-height）
3. block math 的内层 `mord` 等样式在 WeasyPrint 里有时渲染异常
4. 字体是 KaTeX 自家（KaTeX_Main、KaTeX_Math），不是 LaTeX 默认 Computer Modern

### MathJax v3 为什么最稳

1. SVG 输出，glyph 全部内联为 `<path>`，没有外部字体依赖，WeasyPrint 完美渲染
2. STIX 风格字体（嵌入在 SVG path 里），跟 LaTeX 默认 Computer Modern 外观接近
3. 通过 Node.js API 直接调用，`mathjax-full` 包 `~43MB`，但安装只要 14 秒
4. 支持 `\begin{aligned}...\end{aligned}` 多行公式（用 amsmath）
5. a11y / CHTML 输出有 MathJax 自己的支持

---

## 二、安装与路径

### 主选：MathJax v3 安装

```bash
mkdir -p /home/yanyunfei/reports/mathjax-test
cd /home/yanyunfei/reports/mathjax-test
npm init -y
npm install --no-optional --no-audit --no-fund mathjax-full@3
```

**关键 flag**：`--no-optional`。默认 `npm install mathjax-full@3` 会拉 `mhchemparser` 这个化学公式扩展包，它依赖装不全会挂死（实测 120 秒超时仍未完成）。`--no-optional` 跳过它，14 秒搞定。MathJax 99% 的功能都用不上 mhchem。

### render_math.js 脚本

放在 `/home/yanyunfei/reports/mathjax-test/render_math.js`：

```js
const { mathjax } = require('mathjax-full/js/mathjax.js');
const { TeX } = require('mathjax-full/js/input/tex.js');
const { SVG } = require('mathjax-full/js/output/svg.js');
const { liteAdaptor } = require('mathjax-full/js/adaptors/liteAdaptor.js');
const { RegisterHTMLHandler } = require('mathjax-full/js/handlers/html.js');
const { AllPackages } = require('mathjax-full/js/input/tex/AllPackages.js');

const adaptor = liteAdaptor();
RegisterHTMLHandler(adaptor);
const tex = new TeX({ packages: AllPackages });
const svg = new SVG({ fontCache: 'none' });  // 不缓存字体，每条 SVG 自带
const html = mathjax.document('', { InputJax: tex, OutputJax: svg });

// stdin → LaTeX，stdout → SVG 字符串（外层包 <mjx-container>）
// --display → display mode；默认 inline
```

`render.py` 通过 `subprocess.run(["node", "render_math.js", "--display"], cwd=...)` 调用，每条公式 ~80ms。

### 备选：KaTeX 路径（如果 mathjax-full 装不上）

snap 安装的 VS Code 自带完整 KaTeX 0.16.22 + fonts：

```
/snap/code/247/usr/share/code/resources/app/node_modules/katex/
  cli.js
  dist/
    katex.min.css
    fonts/
      KaTeX_Main-Regular.woff2
      ...
```

切换步骤（手动，不在 render.py 默认路径里）：

```bash
# 1. 复制 CSS 和字体到 skill templates
cp /snap/code/247/usr/share/code/resources/app/node_modules/katex/dist/katex.min.css \
   /home/yanyunfei/.hermes/skills/rethinkfun-lecture/templates/
mkdir -p /home/yanyunfei/.hermes/skills/rethinkfun-lecture/templates/katex-fonts
cp /snap/code/247/usr/share/code/resources/app/node_modules/katex/dist/fonts/* \
   /home/yanyunfei/.hermes/skills/rethinkfun-lecture/templates/katex-fonts/

# 2. 改 render.py 的 find_*() 函数指向 cli.js，改 shell-out 调用
# 3. CSS 里 inline katex.min.css，WeasyPrint base_url 指向 templates/
```

注意 KaTeX 在中文 + 复杂公式场景下有偶发的 `ex` 单位计算问题，不是首选。

---

## 三、verify_render() 的坑

`render.py` 内置的 `verify_render(html_path)` 函数扫描渲染后的 HTML 找问题。当前它负责前置告警，不是最终 hard gate；`scripts/verify_pdf.py` 才负责最终放行。早期实现里有个 bug：

```python
# ❌ 错误：CSS 类名 `.math-error-inline` 在 <style> 块里也会被算上
err_inline = html.count("math-error-inline")
err_block = html.count("math-error-block")
```

CSS 类定义长这样：`.math-error-inline { color: #cc0000; ... }`。扫描整页 HTML 时，CSS 块里的字面字符串 `.math-error-inline` 被算成 "出现 1 次"，导致 verify_render() 误报 `❌ math conversion FAILED: 0 inline + 1 block fallbacks`，阻断 PDF 生成。

**修复**：扫描前先剥掉 `<style>` 块：

```python
body_only = re.sub(r'<style>.*?</style>', '', html, flags=re.DOTALL)
err_inline = body_only.count("math-error-inline")
err_block = body_only.count("math-error-block")
```

同样的思路适用于任何扫描整页 HTML 找错误模式的 verifier。当前实现还会额外抓 `mathjax-error`、`math-block-fallback`、`math-inline-fallback`、`data-mjx-error`、`<merror>` 和残留占位符。

---

## 四、公式宽度控制

### A4 内容区估算

A4 页面宽 21cm，左右页边距各 1.8cm → 内容区 ~17.7cm。1ex ≈ 8pt ≈ 0.28cm → 17.7cm ≈ **63ex**。

**目标**：所有 block math ≤ 55ex（留 13% 余量）。

### 超过 55ex 的处理

两层兜底：

1. **写稿时手动换行**：用 `\begin{aligned}...\end{aligned}` 把公式拆成多行，`&` 对齐，`\\` 换行：

```latex
$$
\begin{aligned}
L &= D_{\mathrm{KL}}(q(x_T|x_0)\,\|\,p(x_T)) \\
  &+ \sum_{t>1} D_{\mathrm{KL}}(q(x_{t-1}|x_t,x_0)\,\|\,p_\theta(x_{t-1}|x_t)) \\
  &- \log p_\theta(x_0|x_1)
\end{aligned}
$$
```

2. **CSS 自动缩放兜底**：`.math-block mjx-container > svg { max-width: 100%; height: auto }`，SVG 超过容器宽度时自动缩小。但**会缩小字号**，可读性下降，是 fallback 不是首选。

### verify_render() 的宽度检测

```python
for m in re.finditer(r'<mjx-container[^>]*display="true"[^>]*>.*?</mjx-container>',
                      body_only, flags=re.DOTALL):
    svg_match = re.search(r'<svg[^>]*width="([\d.]+)ex"', m.group(0))
    if svg_match:
        width_ex = float(svg_match.group(1))
        if width_ex > 60:
            overflow_count += 1
```

> 60ex 是 warn 阈值，不是 hard error。warn 让 stdout 打印出来但仍生成 PDF，给作者改稿的机会。

---

## 五、整条管线一图流

```
md_text
  ↓ extract_math_placeholders()  ← 关键：先抽 $...$ 避免 markdown 截胡
md_safe (含 MATH#### 占位符)
  ↓ markdown.Markdown(...).convert(md_safe)
html_with_placeholders
  ↓ restore_math_in_html() → subprocess: node render_math.js
html_with_katex_or_mathjax
  ↓ replace_mermaid_in_html() → subprocess: npx mmdc (可选)
html_with_diagrams
  ↓ inline CSS (report.css)
html_final
  ↓ verify_render()  ← 拦截 ❌ 硬错误，warn 可放行
pdf = WeasyPrint(html_final, base_url=templates_dir).write_pdf()
  ↓
[✓] send MEDIA:/abs/path/to/report.pdf
```

每个箭头都是单步操作，每步都有失败回退：

| 步骤 | 失败回退 |
|---|---|
| extract math | markdown 截胡 `_` → 公式被斜体污染 |
| markdown.convert | 解析错误 → 抛异常 |
| render_with_mathjax | subprocess 失败 → 红框 `mathjax-error` 包裹原始 LaTeX |
| mermaid | mmdc 不可用 → 保留为代码块，标 `[mermaid diagram — mmdc unavailable]` |
| verify_render | ❌ 拦截 → exit 1，不发 PDF；⚠️ 放行 → stdout 提示 |
| weasyprint | 抛异常 → 不发 PDF |

---

## 六、未来扩展方向

- **PDF 字体嵌入**：WeasyPrint 默认嵌入所有字体，PDF 跨平台显示一致，但包体积略大。可考虑 subset fonts 进一步压缩。
- **mmdc 安装提速**：mermaid-cli 首次拉 Chromium 慢（60-180 秒），可预下载 `puppeteer` 离线包避免。
- **公式自动换行**：MathJax v3 的 CHTML 输出有 linebreak 自动换行，SVG 输出没有。如果以后 SVG 公式超宽情况多，可考虑切到 CHTML（但 CHTML 需要外部字体，不如 SVG 自包含）。
- **KaTeX 切回**：如果对中文公式排版有更高要求，可切回 KaTeX + 大量手动调整 CSS。snap 自带的 KaTeX 是兜底。
- **离线 vs CDN**：当前所有渲染都本地完成（不联网），适合敏感环境。如果允许联网，可用 jsDelivr CDN 加载 MathJax 包，省去本地安装。

---

## 七、一句话总结

**MathJax v3 SVG 输出是最稳的选择**。`--no-optional` 是装它的关键。verify_render 必须剥 `<style>` 块再扫。公式超宽在写稿时就拆，别等 CSS 兜底。
