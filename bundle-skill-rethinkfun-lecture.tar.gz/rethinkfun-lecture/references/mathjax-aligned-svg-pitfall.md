# MathJax aligned-environment SVG size pitfall (v7.8)

## TL;DR

MathJax v3 对 `\begin{aligned}...\end{aligned}`、`\begin{align*}...\end{align*}`、`\begin{matrix}...\end{matrix}`、`\begin{cases}...\end{cases}`、`\begin{split}...\end{split}` 以及 `\tag{}` 公式输出的 SVG，**不**走标准 `width="Xex" height="Yex" viewBox="..."` 模板。它把尺寸放在 `style="min-width: Xex"`（width-only），整个 SVG 长这样：

```html
<svg xmlns="http://www.w3.org/2000/svg" style="vertical-align: -1.009ex; min-width: 50.649ex;" role="img" focusable="false">
  <g stroke="currentColor" ...>
    <g data-mml-node="math">
      <g data-mml-node="mtable" ...>
        ...
      </g>
    </g>
  </g>
</svg>
```

**没有 `width` / `height` attribute，也没有 `viewBox`。**

之前的 `mjx_to_img` 只用 `re.sub(r'<svg[^>]*\swidth="([\d.]+)ex"', ...)` 抓 ex——**对这种 SVG 匹配 0 次**，导致 `_force_pixel_dims` 收到 `w_ex = h_ex = 0`，注入 `width="0" height="0"`，cairosvg 抛 `The SVG size is undefined`，fallback 到红色错误 span，**PDF 里 10+ 个公式渲染成红色"\[公式渲染失败: cairosvg 错误\]"**。

`verify_render()` 完全抓不到——因为 fallback span 没有 `mjx-container` / `mathjax-error` class，HTML 看起来一切正常。

## 实测发现过程（2026-06-24）

1. 用户原话："一些渲染错误你没看到吗？你再好好调整一下，别逼我骂你啊"
2. `pdftotext -layout report.pdf - | grep -c '\[公式渲染失败'` → **8 个**（v7.7.2）→ **10 个**（v7.8 改 iter 时误增）
3. 加 debug 日志 print 失败原因到 stderr：`[cairosvg-FAIL] display=True err=The SVG size is undefined`
4. **所有失败都是同一个错**——不是 cairosvg 不支持的标签、不是 ex 单位、不是嵌套 SVG。**SVG size is undefined** 意味着 cairosvg 收到的 SVG 根本没 size 信息
5. 把失败的 SVG dump 到 `/tmp/cairo_fail_*.svg`，看第一个的 `<svg>` 开 tag：
   ```html
   <svg xmlns="http://www.w3.org/2000/svg" style="vertical-align: -1.009ex; min-width: 50.649ex;" role="img" focusable="false">
   ```
6. **确诊**：MathJax 把 width 放在 `style="min-width: Xex"`，没走 attribute
7. 验证 `style="min-width: 50.649ex"` —— 50.649 ex ≈ 50.649 × 7.2 × 1.5 = 547 px（v7.7 用的 EX_TO_PX=5, SCALE=1.5 → 实际应是 50.649 × 5 × 1.5 = 379.87 px —— 和 pdfimages 看到的 380px display 公式对得上）

## 修复 (v7.8.3)

在 `mjx_to_img` 提取 ex 的 fallback chain 里加 `min-width` style 解析：

```python
# 3. Extract width="Xex" / height="Yex" from <svg> attributes.
w_ex, h_ex = 0.0, 0.0
sm = re.search(r'<svg[^>]*\swidth="([\d.]+)ex"', svg_inner)
if sm:
    w_ex = float(sm.group(1))
sm = re.search(r'<svg[^>]*\sheight="([\d.]+)ex"', svg_inner)
if sm:
    h_ex = float(sm.group(1))

# v7.8.3 FALLBACK: MathJax aligned/eqnarray envs put width in style="min-width: Xex"
if w_ex == 0:
    sm = re.search(r'style="[^"]*min-width:\s*([\d.]+)ex', svg_inner)
    if sm:
        w_ex = float(sm.group(1))
if h_ex == 0:
    sm = re.search(r'style="[^"]*height:\s*([\d.]+)ex', svg_inner)
    if sm:
        h_ex = float(sm.group(1))

# Last resort: any inner <svg> with width/height attribute (some MathJax
# outputs nest a sized <svg> inside a positioning <svg>)
if w_ex == 0 or h_ex == 0:
    for nested_sm in re.finditer(r'<svg[^>]*\swidth="([\d.]+)ex"\s+height="([\d.]+)ex"', svg_inner):
        iw, ih = float(nested_sm.group(1)), float(nested_sm.group(2))
        if iw > w_ex: w_ex = iw
        if ih > h_ex: h_ex = ih
        break
```

修复后所有 10 个 cairosvg 失败 → 0 个。

## Smoking-gun detection (v7.8 强制 verify protocol)

`verify_render()` 抓不到，必须 **pdftotext PDF 后 grep 错误 span**：

```bash
pdftotext -layout report.pdf - | grep -c '\[公式渲染失败'
# 必须 = 0
```

一键脚本：`scripts/check_cairosvg_errors.py`。失败时它会：
- 打印错误数
- 抽前 5 个错误 span 的前后文（让用户定位是哪个公式）
- exit 1 → 阻止发稿

## 反修复教训（v7.8.1 误诊）

第一反应以为"`findall('.//svg')` 是 descendant-or-self 把 root 也 unwrap 了"，改成 `iter()` 反而**错误数从 8 涨到 10**。回去查 lxml 文档：

> lxml's `findall('.//x')` uses **ElementPath syntax**, which is **descendant ONLY** (not descendant-or-self). Root is not matched.

**所以原来 findall 是对的，bug 在别处**。这个误诊浪费了一次迭代 + 一次重渲染。教训：

- **改 lxml 行为前先读 lxml 文档**，别凭 XPath 记忆假设
- **不要根据错误数变化反推"哪个改动有效"**——可能是别的变量（不同 LaTeX 顺序、不同 ex 数）触发的
- **dump 失败 SVG 到磁盘看** 比看错误数变化快 10 倍

## 完整 detection chain (v7.8 必跑)

```
1. render.py exit 0
2. pdftotext -layout report.pdf - | grep -c '\[公式渲染失败'   → 必须 0
3. python3 scripts/verify_pdf.py report.pdf                  → exit 0
4. pdftoppm -r 150 -f 1 -l 1 report.pdf _p1 -png            → 肉眼过一遍
5. pdftoppm -r 150 -f 4 -l 4 report.pdf _p4 -png
6. pdftoppm -r 150 -f 7 -l 7 report.pdf _p7 -png
7. 发 PDF + 3 张 PNG 给用户
```

第 2 步是 v7.8 唯一新增。**没跑第 2 步 = 准备挨骂**（用户原话："一些渲染错误你没看到吗？"）

## 为什么"为什么是 MathJax 这样输出"

aligned 环境的 SVG 本质是一个 **layout container**——它不知道自己的最终宽度，因为宽度取决于行内最长那行。MathJax 选择 `min-width: Xex` 是因为：
- `Xex` 是最长那行 estimate 出来的 minimum
- 不写 `width` attribute 是因为实际宽度可能因为 align/justify 比 min-width 大
- 不写 `viewBox` 是因为整个 SVG 不是矢量缩放的（它是 absolute positioned）

cairosvg 不理解这个 layout 语义——它要求 SVG 自报 size。所以我们要从 `min-width` 里**手动**给 cairosvg 一个 size hint（按 min-width 渲，反正 align 之后宽度不会比 min-width 小）。

## 相关文件

- `scripts/render.py:mjx_to_img()` — 修复在第 3 步 fallback chain
- `scripts/check_cairosvg_errors.py` — 自动扫描脚本
- `references/cairosvg-mathjax-pipeline.md` — 完整 cairosvg 6 步 pipeline (v7.2.3)
- `references/font-size-debugging.md` — 字号调试（v7.7）
- `references/weasyprint-svg-incompatibility.md` — WeasyPrint SVG 不支持根因 (v7.2.1)
