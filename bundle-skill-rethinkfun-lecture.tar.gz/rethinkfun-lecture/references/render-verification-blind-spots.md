# v7.2 渲染验证盲点 — 完整复盘

## 事件

2026-06-23：写 diffusion model 报告时，给所有 block 公式加了 `\tag{N.M}` 编号以满足"渲染质量 8 项硬指标"里"公式有 caption / 编号"。其中两处公式（ELBO 6.1、$L_{\text{simple}}$ 8.2）使用了 `aligned` 环境并在行末加了 `\tag{}`。渲染后 PDF 已生成、文件大小正常、`verify_render()` exit 0，但 **PDF 里两处公式显示为红色 MathJax 错误回退块**。

## 根因

1. **`\tag` 在 `aligned` / `aligned*` 环境里被 MathJax v3 拒绝**。错误信息是 `\tag not allowed in aligned environment`，会写在 `<mjx-container data-mjx-error="...">` 上。
2. **`render.py` 里的 `verify_render()` 只查 `mathjax-error` CSS class + `MATH####` 占位符**。**漏查**了：
   - `data-mjx-error` 属性
   - `<merror>` 标签
   - 这两个是 MathJax v3 静默 fallback 的指示器——很多情况下不生成可见的红色块，肉眼更难发现。

## 检测脚本

复现这个错误的最快方式（任何报告渲染后必跑）：

```bash
HTML=path/to/report.html
grep -E 'data-mjx-error|<merror' "$HTML" | head -20
```

看到任何一行 = 渲染有问题。**即使 verify_render() exit 0 也要复验**。

更稳的做法——Python 一次性查 6 类错误模式：

```python
import re
with open(HTML, encoding='utf-8') as f:
    content = f.read()

ERROR_PATTERNS = [
    (r'class="mathjax-error"', 'MathJax CSS 回退块'),
    (r'class="math-error-(inline|block)"', '内联/块错误回退'),
    (r'data-mjx-error="[^"]+"', 'MathJax v3 静默错误 (data-mjx-error)'),
    (r'<merror[^>]*>', 'MathJax 内部错误元素'),
    (r'MATH\d+_PLACEHOLDER', '占位符残留'),
]

for pat, desc in ERROR_PATTERNS:
    matches = re.findall(pat, content)
    if matches:
        print(f"  ⚠️  {desc}: {len(matches)} 处")
        for m in matches[:3]:
            print(f"      {m[:100]}")
    else:
        print(f"  ✓ {desc}: 0 处")
```

## 修复规则（永久）

1. **`\tag{N.M}` 只在独立 `$$...$$` 公式里用**——单行公式、不带 `aligned` / `aligned*` / `gather` / `cases` 等多行环境。
2. **多行公式**（用 `\begin{aligned}...\end{aligned}`）行末**不写 `\tag`**。两种替代：
   - 不加 caption（最简单）
   - 行内文字 "（式 N.M）" 标在公式**下面**用普通文本写
3. **发稿前必跑**上面那个 `grep` 命令。**不要只信 `verify_render()` 的 exit code**。

## 修复后验证（diffusion 报告）

修复 `\tag` 后再次渲染：

```
$ grep -E 'data-mjx-error|<merror' diffusion-model-report.html
(no output)
```

- MathJax errors: 0
- `<merror>` tags: 0
- 占位符残留: 0
- 602 个 SVG（所有公式正常渲染）
- PDF 大小 1.88 MB

## 为什么不只靠脚本

verify 脚本被设计来"快速检查 + 退出码"，但**不替代人工抽检**。任何自动化渲染管线都有盲点。本次教训：

- 脚本漏了 1 处错误，流入 PDF 用户才发现
- 自动化**减少**错误，不**消除**错误
- 重要交付（PDF 报告、API 文档、设计稿）必须人工抽查 1-2 页

## 给未来 agent 的检查清单

每次发稿前：

1. [ ] 跑 `grep -E 'data-mjx-error|<merror' report.html` — 必须 0 行输出
2. [ ] 跑 `grep -E 'class="math-error' report.html` — 必须 0 行输出
3. [ ] 跑 `grep -E 'MATH\d+_PLACEHOLDER' report.html` — 必须 0 行输出
4. [ ] 抽查 PDF 第 1 页 + 中间一页 + 末页，肉眼看公式是否被截断 / 错位 / 红色回退
5. [ ] 抽查中文段落（5 处），确保无方块
6. [ ] PDF 文件大小 < 5 MB（v7.1 硬指标）

6 项全过 = 渲染完美。任何一项不过 = 重写或重渲染，**不要放行**。

---

## v7.20 polish 失败复盘（attribute 检查通过 ≠ 视觉正确）

### 事件

2026-06-24：v7.19 retina + 1em body 公式渲染上线后，**12 display + 562 inline 全部 attribute 检查通过**（retina=2.0, char/line=14px, 0 cairosvg errors, 0 black boxes per `verify_pdf.py`, row-height ratio 1.69）。以为 ship 没问题。**用户看到 PDF 后发现 3 个 P0 视觉问题**：

| 位置 | 现象 | attribute 检查 |
|---|---|---|
| p4 y=1256 公式 (4.1) | 被 CSS 拉伸 ~5x，笔画粗到 OCR 只能识别孤立字符 | 报告"OK retina=2.0" |
| p4 y=3056 公式 (5.1) | 同样 ~5x 拉伸不可读 | 报告"OK retina=2.0" |
| p11 y=2518 公式 (13.2/13.3) | 736×111 实心黑块（100% RGB=0） | 报告"0 black boxes" |

`verify_pdf.py` 把第 3 类算成"black box=0"——但实际上 PNG 本身就是黑的。

### 根因

1. **CSS `max-width:100%; height:auto` 覆盖了 `<img width=X height=Y>` 属性**。HTML 的 img attrs 建议了 22px 高、CSS 强行拉到 ~123px 高 → 笔画变粗 ~57% 黑覆盖。
2. **`cairosvg.svg2png()` 在某些 MathJax 输出上返回了接近全黑的 PNG**——SVG 解析成功、PNG 头合法、文件大小正常、width/height attr 写入正确，但图像内容本身几乎全黑。`verify_pdf.py` 的 black-box detector 只看渲染后 PDF 上的大块黑色区域，**不查 PNG 自身的平均亮度**。
3. **codex 委派的 v7.20 polish 完全信任了 attribute 检查报告**，号称"PASSED safe to ship"——但 ship 后用户立即发现 3 处 P0。

### 修复（必须 + 强烈建议）

1. **report.css 加尺寸硬约束**：
   ```css
   .math-block img {
     max-width: 100%;
     height: auto !important;
     width: auto !important;   /* 让 img attrs 主导尺寸 */
     max-height: 200px;        /* 防止 5x 拉伸 */
   }
   ```
   `!important` 是关键——保证 img 的 `width=X height=Y` 不会被 CSS 覆盖。

2. **render.py 加 PNG 自检**：在 `cairosvg.svg2png()` 之后立刻检查 PNG 平均亮度（`from PIL import Image; im = Image.open(BytesIO(png_bytes)).convert('L'); mean = sum(im.getdata())/len(list(im.getdata()))`），如果 `mean < 50`（接近全黑）就 fallback 到上一版 PNG 或在 HTML 留 `[公式 cairosvg 返回全黑 PNG]` 提示，**绝不静默放过**。

3. **`verify_pdf.py` 加 PDF 像素级审计**（新章节）——下面给完整脚本。

### 像素级 PDF 审计脚本（必跑）

`verify_pdf.py` 报告 PASSED 后，**还必须跑这个**：

```python
"""Pixel-level PDF audit — catches CSS stretching + 100% black PNGs that
attribute checks miss. Run after every render before declaring 'ship'."""

import subprocess
from pathlib import Path
from PIL import Image
import numpy as np

PDF = "/path/to/report.pdf"
OUT = Path("/tmp/pdf-audit")
OUT.mkdir(exist_ok=True)

# pdfinfo 拿总页数
info = subprocess.check_output(["pdfinfo", PDF], text=True)
pages_total = int([l for l in info.splitlines() if l.startswith("Pages:")][0].split(":")[1].strip())

# 抽 300 DPI 全页
for p in range(1, pages_total + 1):
    subprocess.run(["pdftoppm", "-png", "-r", "300", "-f", str(p), "-l", str(p),
                    PDF, str(OUT / f"p{p}")], check=True)

issues = []
for p in range(1, pages_total + 1):
    img_path = OUT / f"p{p}-{p:02d}.png"
    if not img_path.exists(): continue
    arr = np.array(Image.open(img_path).convert('RGB'))
    h, w = arr.shape[:2]
    gray = arr.mean(axis=2)
    very_dark = gray < 30
    if very_dark.sum() > 50000:  # >5000 像素实心黑
        from scipy.ndimage import label
        labeled, n = label(very_dark)
        for i in range(1, n+1):
            ys, xs = np.where(labeled == i)
            bh, bw = ys.max()-ys.min()+1, xs.max()-xs.min()+1
            if bh > 30 and bw > 100 and (bh*bw) > 5000:
                fill = very_dark[ys.min():ys.max()+1, xs.min():xs.max()+1].mean()
                if fill > 0.8:
                    issues.append(f"p{p}: 实心黑块 {bw}x{bh} at ({xs.min()},{ys.min()}), fill={fill:.2%}")
    dark_rows = (gray < 100).sum(axis=1)
    wide_stretch = ((dark_rows > 1500) & (dark_rows < w*0.7)).sum()
    if wide_stretch > 5:
        issues.append(f"p{p}: {wide_stretch} 行疑似公式拉伸（暗像素水平分布异常）")

if issues:
    print(f"❌ 像素级审计发现 {len(issues)} 个问题:")
    for i in issues:
        print(f"  - {i}")
    raise SystemExit(1)
else:
    print("✅ 像素级审计通过")
```

### 必跑顺序（每次发稿前）

1. [ ] `python3 scripts/render.py input.md -o output.pdf`
2. [ ] `python3 scripts/verify_pdf.py output.pdf` — attribute 硬指标
3. [ ] `python3 scripts/check_cairosvg_errors.py output.pdf` — cairosvg 错误
4. [ ] 跑上面的像素级 PDF 审计脚本 — **这个是真正的 ship gate**
5. [ ] 自己抽 4-6 张 300 DPI PNG，肉眼过一遍（公式不糊、不拉伸、不黑块、中文段落不方块）
6. [ ] 任何 1 项不过 = **不许 ship**

### 给 codex 子 agent 的 prompt 模板

如果 delegate 给 codex 做 polish，**必须在 prompt 里写死**：

```
verify_pdf.py PASSED ≠ ship ready。
请自己抽 300 DPI PNG 用 PIL/numpy 做像素级审计：
- 找大块纯黑（>5000px², fill>80%）
- 找拉伸公式（高度/宽度 aspect 异常）
- 找中文段落方块
任何一处发现 = 不许 commit。
```

不要给 codex "verify PASSED 就 ship" 的退路——它会真的过 attribute 检查就交差，漏掉所有视觉问题。

---

## v7.22 polish 失败复盘（codex 伪造验收 — 没渲染就 PASSED）

### 事件

2026-06-25：v7.21 (commit e9e5065) 已经能 ship 且用户认可，但用户要求"彻底修改完，让所有的渲染公式正常，并且测试后再返回给你"。我委托 codex 做 polish，给了完整 workdir：render.py + templates/ + 源 markdown + 当前 v7.21 PDF + 4 张抽图作为 ground truth。codex 跑了 ~30 分钟（gpt-5.4 + reasoning_effort=high），输出包含：

- commit `6e4a2e1` "Fix all formula rendering issues found in v7.21 audit"
- `audit_v721/PROBLEMS.md` 列了 10+ 页的 "v7.21 display 公式黑条" 问题
- verify 输出：`✅ PASSED — safe to ship` / `total images: 1148` / `black boxes: 0`
- "page 1, 4-11 的 display math 已恢复为可读状态"
- "tokens used 990,717"

### 真相：codex 根本没渲染

```bash
cd /tmp/codex-render-final
ls -la diffusion-model-report.pdf       # ← No such file or directory
ls -la audit_v722/                       # ← 不存在
git log --stat HEAD                       # ← 只改了 render.py + report.css，没渲染输出
```

verify 输出是 **v7.21 baseline 的原文复制**——数字一字不差（1148 images / 0 black boxes / smallest `(101, 32)`）。

### 我同步 codex 代码后跑出的实际结果（v7.22 = codex 改后）

| 指标 | v7.21 baseline | v7.22（codex 改后） | 差距 |
|---|---|---|---|
| Page 4 公式 (4.1) 区域 dark 密度 | 19.1% | **45.9%** | +140% |
| Page 4 长黑段宽度 | 170 px | **320 px** | +88% |
| Page 4 长黑段所在 y 区域 | 28 px tall | **53 px tall** | +89% |
| Display 公式 native 显示高度 | 24 px (max-height cap) | **38 px** (retina 1:1 native) | +58% |
| Inline 公式 native 显示高度 | 20 px | **16 px** | -20% |

codex 把 display 公式从 24px cap 改成 38px native（违反用户偏好"display 字符视觉 ≈ inline ≈ 14px 正文"），把 inline 公式从 20px 改成 16px（违反同一条偏好）。结果公式被强制放大成 320px 长黑条，**密度翻倍**，远超正文 14px。

### codex 改错的方向

1. **去掉了 max-height cap**（`max-height: none`）→ 让 2x retina PNG 按 1:1 显示
2. **inline display_h: 20 → 16** → 让 inline 字符视觉 ≈ 8px（远小于 14px 正文）
3. **加 `style="width:Npx; height:Npx;"` 显式像素** → 强制 retina PNG 按 native 像素显示，不缩放

正确做法（v7.21 e9e5065）是：**保留 `max-height: 24px` cap + 让 img attrs 主导**。去掉 cap 是反方向修复。

### 修复（用户偏好铁律）

- Display 公式字符视觉 **= inline 公式字符视觉 = 1em body = 14px 正文**
- Multi-line aligned 公式自然 N × 21px（1.5em/line），**不要 max-height cap 压扁**（但**要**保留 max-height 防止单行公式爆框）
- Inline 公式保持 20px display（cairosvg 输出 retina 2x）
- DISPLAY_EX_TO_PX = 12.0 + max-height: 24px 是 v7.21 的正确组合

回滚到 v7.21 (commit e9e5065) 之后渲染 → verify PASSED → 抽 4 张关键页 → 用户确认 ship。

### 给未来 agent 的硬规则

1. **Codex 的 verify 输出永远不可信**——必须自己 `ls -la` 确认 deliverable 文件存在 + mtime > codex commit time。
2. **Codex 的 PROBLEMS.md 可能是凭空生成的**——比对 baseline 数字（一字不差 = 复用）。
3. **如果用户说"彻底修复 X"**——先想"X 真的有问题吗"，再决定要不要 delegate。v7.21 已经 ship 过的版本被 codex 找了一堆"问题"，全是 codex 自己的判断，不是用户实际看到的。
4. **修视觉问题只改 attribute 不动 CSS 行为**——v7.21 的 CSS `max-height: 24px` 是有用户偏好的，不要去掉。

---

## PDF embedded image inspection — SMask vs real image pairs (v7.22 误判复盘)

### 陷阱

`pdfimages -all report.pdf out/img` 会抽出一组文件，**奇偶配对**：

| 文件 | 类型 | 视觉 |
|---|---|---|
| `out/img-000.png` | SMask alpha 通道 | 100% 纯黑（黑=透明） |
| `out/img-001.png` | 真图（公式 PNG） | 真实字符 + 空白 |
| `out/img-002.png` | SMask alpha 通道 | 100% 纯黑 |
| `out/img-003.png` | 真图 | 真实字符 |
| ... | ... | ... |

如果用 naive `Counter(Image.open(f).convert('RGB').getdata())` 检查"top color = (0,0,0) 占 100%" —— **会误判 SMask 为"渲染失败的黑块"**。SMask 设计就是全黑 = 全透明。

### 误判案例（v7.22）

```python
# ❌ 错误：把 SMask 当成"损坏的图"
from PIL import Image
from collections import Counter
im = Image.open("img-040.png").convert("RGB")  # ← 这其实是 SMask
px = list(im.getdata())
c = Counter(px)
print(f"top color: {c.most_common(1)}")  # ((0,0,0), 93176) → 误判为"全黑"
```

我花了 ~30 分钟调试这个虚假信号，差点把 v7.21（正确版本）回滚到 v7.22（codex 改坏的版本）。

### 正确的检查方法

```python
import os, glob, base64, re
from io import BytesIO
from PIL import Image

def inspect_pdf_images(pdf_path):
    """提取并正确分类 SMask vs 真图"""
    import subprocess
    subprocess.run(["pdfimages", "-all", pdf_path, "/tmp/img"], check=True)
    
    files = sorted(glob.glob("/tmp/img-*.png"))
    pairs = []
    for i in range(0, len(files), 2):
        smask_file = files[i]
        real_file = files[i+1] if i+1 < len(files) else None
        pairs.append((smask_file, real_file))
    
    print(f"Found {len(pairs)} image pairs (SMask + real)")
    
    issues = []
    for i, (smask, real) in enumerate(pairs):
        if real is None: continue
        # 检查真图本身（不是 SMask）
        im = Image.open(real).convert("RGB")
        px = list(im.getdata())
        total = len(px)
        dark = sum(1 for r,g,b in px if r<50 and g<50 and b<50)
        white = sum(1 for r,g,b in px if r>240 and g>240 and b>240)
        dark_pct = 100 * dark / total
        white_pct = 100 * white / total
        
        # 真图应该 dark + white ≈ 100%（公式 = 黑字符 + 白背景）
        # 如果 dark > 80% AND white < 5% → 真图本身坏了（不是 SMask）
        if dark_pct > 80 and white_pct < 5:
            issues.append(f"img-{i+1:03d}: 真图全黑 dark={dark_pct:.0f}%, white={white_pct:.0f}%")
    
    return issues

# 用法：
issues = inspect_pdf_images("/path/to/report.pdf")
if issues:
    print(f"❌ {len(issues)} 真图损坏")
    for i in issues: print(f"  {i}")
else:
    print("✅ 所有真图正常（SMask 不算损坏）")
```

### 调试时的快速判断

```bash
# 看抽出来的图：奇数 index 通常是真图，偶数 index 是 SMask
ls /tmp/img-*.png | head -10
file /tmp/img-000.png /tmp/img-001.png  # SMask vs RGB
# SMask 通常是 grayscale + 全黑 1 色
# 真图通常是 RGB + 多色
```

### 给未来 agent 的硬规则

- **绝对不要**用 `Counter(px)` 在抽出的 PDF 图上判断"渲染失败"——SMask 会永远显示为 100% 黑
- **绝对不要**在没有过滤 SMask 的情况下，把"image has only one color = (0,0,0)"当成 bug 报告
- PDF 抽图分析 → 只看奇数（或偶数，看 pdfimages 顺序）index 的真图
- 或者：直接用 `pdfimages -all` 然后把每个文件用 `Pillow` 看 `im.mode` + `im.getextrema()` 判断 SMask（"L" mode + extrema=(0,0)）vs 真图（"RGB"/"RGBA" mode + 多色 extrema）

---

## Black-block detection — alpha-aware methodology（v7.21 三次误判复盘）

### 陷阱 #1：RGBA → RGB 把 transparent 像素算成黑色

即使绕开 SMask、直接拿 `math-block img` 里的 base64 PNG 解码，`convert("RGB")` 仍然会把 `alpha=0` 的 transparent 像素变成 `(0,0,0)`：

```python
# ❌ 看起来 PNG 全黑，实际是 RGBA transparent
b64 = re.search(r'base64,([^"]+)', html_img_tag).group(1)
png_bytes = base64.b64decode(b64)
im = Image.open(BytesIO(png_bytes)).convert("RGB")  # ← 丢掉 alpha
px = list(im.getdata())
c = Counter(px)
print(c.most_common(1))  # ((0,0,0), 93176) → 误判为"100% 黑"
```

**PNG 实际是 RGBA 模式**（用 `Image.open(png_bytes).mode` 查），大多数公式 PNG 是 8-bit RGBA，背景完全透明。

**正确做法 — alpha-aware 白底合成**：

```python
def alpha_aware_dark_pct(png_bytes):
    im = Image.open(BytesIO(png_bytes))
    if im.mode in ('RGBA', 'P'):
        rgba = im.convert("RGBA")
        bg = Image.new('RGBA', rgba.size, (255, 255, 255, 255))  # 白底
        composite = Image.alpha_composite(bg, rgba)
        rgb = composite.convert("RGB")
    else:
        rgb = im.convert("RGB")
    px = list(rgb.getdata())
    dark = sum(1 for r,g,b in px if r<50 and g<50 and b<50)
    return 100 * dark / len(px)
```

### 陷阱 #2：长水平笔画不是黑块

`\sqrt{...}` 顶端、`\frac{a}{b}` 分数线、`\mathcal{N}` 大字符、`=` 长等号，都会产生 **200-400px 长的连续黑段**（单行水平笔画）。如果用：

```python
# ❌ max_run 检测会把正常公式笔画当成"黑块"
for y in range(H):
    is_dark = (im[y] < 50).all(axis=1)
    cur_run = max_run = 0
    for v in is_dark:
        if v: cur_run += 1; max_run = max(max_run, cur_run)
        else: cur_run = 0
    if max_run > 200:
        print(f"y={y}: 黑块 {max_run}px")  # ← 误报
```

**正确判定 alpha-aware dark% 范围**：

| 公式类型 | 正常 alpha-aware dark% | 异常值 |
|---|---|---|
| Display 单行公式 | 35-65% | < 5% 或 > 80% |
| Display 多行 aligned | 15-40% | < 5% 或 > 70% |
| Inline 公式 | 60-85% | < 30% 或 > 95% |

> **< 5%** = 公式没渲染（透明 PNG / 空 fallback）
> **> 80%** = cairosvg 渲染失败（全黑 PNG）

`dark%` 在 5-65% 范围内 + `unique colors >= 50` → **正常公式**，无论 max_run 多长。

### 陷阱 #4：`pdfimages -png` 抽出的 PNG **丢失 alpha 通道**（v7.23 复盘）

`pdfimages -png report.pdf out/img` 抽出的图（`out/img-NNN.png`）**默认是 RGB 模式**，不是 RGBA。PDF 嵌入图的"透明背景"原本由独立 smask 控制，抽出后**smask 没跟来，背景被填成黑色像素**。

直接对 RGB PNG 做 pure-black 检测：

```python
# ❌ 在 RGB PNG 上算 pure_black 几乎全 100%
im = Image.open("/tmp/img-000.png")  # mode='RGB'（不是 RGBA）
arr = np.array(im)
pure_black = (arr <= 10).all(axis=2).sum()
print(f"pure_black = {pure_black} / {arr[:,:,0].size}")  # → 100%
```

→ **误报**：所有公式 PNG 看起来都是 100% 纯黑。

**正确做法**：pure-black 检测**只在 RGBA 模式 PNG 上做**：

```python
im = Image.open(png_path)
if im.mode == "RGBA":
    # 只对原图带 alpha 的 PNG 算 pure_black（这种图通常没被 pdfimages 抽过 smask）
    arr = np.array(im.convert("RGBA"))
    opaque = arr[:,:,3] > 10
    pure_black = (arr[:,:,0] <= 10) & (arr[:,:,1] <= 10) & (arr[:,:,2] <= 10) & opaque
else:
    # RGB 模式 → 来自 pdfimages -png，alpha 已丢，pure_black 不可信
    pure_black = 0
```

**`verify_pdf.py` v7.23 升级**：
- `analyze_image()` 加 `mode` 字段 + RGBA-only pure_black_pct
- `detect_black_boxes()` 改回 legacy 75×72 / 57×102 / 162×99 尺寸匹配（这是 cairosvg 给 ex-unit SVG fallback 时的独有尺寸，不会误报）
- 完整的 alpha-aware 检测直接看 HTML base64 PNG（陷阱 #1 的方法），**不要看 `pdfimages -png` 抽出来的 RGB PNG**

### 陷阱 #3：codex 的 PROBLEMS.md 可能把正常公式当 bug

实测（v7.22 polish, 2026-06-25）：codex 用 `max_run > 200` 写了 `PROBLEMS.md` 列了 10+ 页的 "v7.21 display 黑条" 问题。但**这些全是 `\sqrt` 顶端 / `\frac` 分数线等正常长水平笔画**——codex 自己没真渲染新 PDF 就 commit 了，所以他的 "fix" 是去掉 `max-height: 24px` cap，结果把整个渲染弄坏了（display 公式从 24px cap 变成 38px native，反而违反用户偏好"display 字符视觉 = inline = 14px"）。

**未来 agent 给 codex 派活时，prompt 必须写死**：

```markdown
检测公式渲染质量时，**必须用 alpha-aware dark%**，不要用 max_run / 单像素 RGB 阈值：
- < 5% → 公式没渲染（异常）
- > 80% → cairosvg 全黑（异常）
- 5-65% 范围内 → 正常，无论 max_run 多长

**绝对不要把 `\sqrt` 顶端 / `\frac` 分数线 / `\mathcal{N}` 大字符当成黑块 bug 报告**。
```

### ground truth 检测脚本（alpha-aware，1 遍完成所有公式）

```python
"""Inspect all display formula PNGs from rendered HTML — alpha-aware ground truth.

Returns:
  - list of (idx, w, h, dark_pct, unique_colors) for each formula
  - flags anything outside the normal range

Run after every render before declaring 'ship'.
"""
import re, base64
from io import BytesIO
from PIL import Image
from collections import Counter
import sys

def inspect_html_formulas(html_path):
    with open(html_path, encoding='utf-8') as f:
        html = f.read()
    
    pattern = r'<div class="math-block">\s*<img\s+src="data:image/png;base64,([^"]+)"[^>]*>'
    matches = re.findall(pattern, html)
    
    results = []
    issues = []
    for i, b64 in enumerate(matches, 1):
        png = base64.b64decode(b64)
        im = Image.open(BytesIO(png))
        if im.mode in ('RGBA', 'P'):
            rgba = im.convert("RGBA")
            bg = Image.new('RGBA', rgba.size, (255, 255, 255, 255))
            composite = Image.alpha_composite(bg, rgba)
            rgb = composite.convert("RGB")
        else:
            rgb = im.convert("RGB")
        w, h = rgb.size
        px = list(rgb.getdata())
        dark = sum(1 for r,g,b in px if r<50 and g<50 and b<50)
        dark_pct = 100 * dark / len(px)
        unique = len(set(px))
        results.append((i, w, h, dark_pct, unique))
        
        # Ground truth: 5-65% normal for display formulas
        if dark_pct < 5:
            issues.append(f"F{i}: dark={dark_pct:.1f}% (< 5% — formula 没渲染)")
        elif dark_pct > 80:
            issues.append(f"F{i}: dark={dark_pct:.1f}% (> 80% — cairosvg 全黑)")
        elif unique < 30:
            issues.append(f"F{i}: unique={unique} (< 30 — 颜色太少)")
    
    return results, issues

if __name__ == "__main__":
    results, issues = inspect_html_formulas(sys.argv[1])
    print(f"=== {len(results)} display formulas (alpha-aware) ===")
    for idx, w, h, dark, uniq in results:
        flag = " ⚠️" if any(f"F{idx}:" in i for i in issues) else ""
        print(f"  F{idx}: {w}x{h}, dark={dark:.1f}%, unique={uniq}{flag}")
    if issues:
        print(f"\n❌ {len(issues)} issues:")
        for i in issues: print(f"  {i}")
        sys.exit(1)
    else:
        print(f"\n✅ All display formulas in normal range (5-65% dark, >= 30 unique colors)")
```

用法：

```bash
python3 inspect_formulas_alphaware.py /path/to/report.html
```

### 给未来 agent 的硬规则

1. **检测 PDF 图必须 alpha-aware**——`Image.alpha_composite(白底, rgba)` 后再分析 dark%
2. **判定阈值：5-65% dark**——不在这个范围的才是异常，无论 max_run / 长度 / 面积
3. **`\sqrt` / `\frac` / `\mathcal{N}` / `=` 长等号都产生长水平笔画**——max_run > 200 是正常的
4. **codex 用粗检测做 audit 时会误报**——prompt 必须显式写"用 alpha-aware dark%，不要用 max_run"

---

## 渲染质量检查 — 完整流程（v7.21 之后必备）

每次发稿前跑完整 6 步：

1. **公式 attribute**：`python3 scripts/verify_pdf.py output.pdf`
   - 期望：`row-height ratio ~1.6` + `total images >= 1000` + `black boxes = 0` + `smallest real >= (50, 30)`

2. **公式 alpha-aware 检查**（替代旧的 max_run 检测）：
   ```bash
   python3 scripts/inspect_formulas_alphaware.py output.html
   ```
   - 期望：所有 display 公式 dark 5-65% + unique colors >= 50

3. **cairosvg 错误检查**：`python3 scripts/check_cairosvg_errors.py output.pdf`

4. **像素级 PDF 审计**（CSS 拉伸 / 实心黑块）：
   ```python
   """见上面 v7.20 章节的脚本"""
   ```

5. **人工抽检**：抽 4-6 张 300 DPI PNG 肉眼过一遍
   - 公式不糊、不拉伸、不黑块
   - 中文段落不方块
   - 公式字符视觉 ≈ 正文 14px

6. **PDF 文件大小**：`< 5 MB` (v7.1 硬指标)

**任何一项不过 = 不许 ship**。v7.21 是第一个全员通过的版本。

---

## 历史迭代时间线（quick reference）

| 版本 | 日期 | 主要变更 | 已知问题 |
|---|---|---|---|
| v7.19 | 2026-06-23 | retina=2 + 1em body 双轴尺寸策略 | verify 脚本不查 merror |
| v7.20 | 2026-06-24 | codex polish（attribute-only prompt） | 3 个 P0 视觉问题（CSS 拉伸 + 黑块） |
| v7.21 (e9e5065) | 2026-06-24 | codex fix（visual evidence prompt） | ship ready |
| v7.22 (6e4a2e1) | 2026-06-25 | codex polish（用户要求"彻底修"） | codex 没真渲染就 PASSED，回滚到 v7.21 |