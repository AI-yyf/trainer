# Reference PDF #16 — the user-approved ground truth (v7.9)

> **TL;DR**：用户亲口说"这个版本就很好很到位"并要求"回到这个版本的公式渲染方法"。这个 PDF 是**所有未来改动必须对照的 ground truth**。

## 是什么

- **路径**：`/home/yanyunfei/.hermes/cache/documents/doc_41157ed1034f_diffusion-model-report(16).pdf`
- **生成时间**：2026-06-23（用户认可）
- **大小**：1.93 MB
- **页数**：18 页
- **Producer**：WeasyPrint 69.0

## 用户原话（必须记住）

> "你看看这一版本的 这个就很好很到位 请你重新生成这一版本的"

> "请你回到这个版本的公式渲染方法"

## 它用的渲染参数（这就是 v7.9 target）

| 参数 | 值 | 来源 |
|---|---|---|
| `EX_TO_PX` | 7.2 | render.py 第 68-72 行 |
| `SCALE` | 1.5 | render.py 第 73 行 |
| `body.line-height` | 1.7 | templates/report.css 第 25 行 |
| `body.font-size` | 10.5pt (≈ 14px) | templates/report.css 第 25 行 |
| inline formula `height` | **17px** (1.2em body) 固定 | render.py mjx_to_img |
| display formula sizing | **PNG 物理尺寸** + `max-width: 100%` + `height: auto` | render.py mjx_to_img |

**绝对不要做的事**（v7.8.4-v7.8.7 反修复教训）：
- ❌ 给 display 公式强制 `max_h`（任何值：80/40/25/50 都不对）
- ❌ 给 display 公式强制 `min_h`（18/17 都不对）
- ❌ 给 display 公式强制 `disp_h = png_h × 2`（让字符 visual = 1em body 这种"完美理论值"实际反而让单行公式看起来比正文小）
- ❌ 给 display 公式强制 `aspect-fit` 到固定宽度 max_w=550/600（参考 PDF 没有这个强制）

**为什么**：这些强制让"公式按 PNG 物理尺寸自然显示"的特性消失——数学公式应该和 LaTeX 一样按 ex 数自然缩放，**人为 clamp 让公式看着别扭**。

## 像素测量数据（作为 regression check baseline）

用 `pdftoppm -r 150` 抽出参考 PDF 各页，用 PIL + numpy 测每段墨水高度：

| 页 | display 公式数 | avg actual_h (px) | range (px) |
|---|---|---|---|
| p1 | 22 | 25.0 | 20-79 |
| p4 | 26 | 25.0 | 20-30 |
| p7 | 23 | 26.0 | 20-30 |
| p12 | 27 | 24.9 | 20-29 |

**预期**：任何"参考 v7.9 风格"的渲染，display 公式平均高度应在 **24-27 px** 范围。

inline 公式预期：
- 参考 PDF 文字行（text rows）≈ 17.0 px
- 参考 PDF inline 公式行 ≈ 21.3 px（被 line-height 1.7 撑到行高）
- 比值：inline / text = 21.3 / 17.0 = 1.25 ✓（可接受范围 < 1.5）

## 字体表特征（reference 用了什么字体）

`pdffonts` 输出关键字体：
- `LWGGBP+Noto-Serif-CJK-SC` — 正文中文
- `DFCEGX+Noto-Sans-CJK-SC-Bold` — H2/H3 标题
- `TSPJMR+Noto-Sans-CJK-SC` — 备用
- `HUQPOW+Noto-Serif` — 英文正文
- `IKCJUC+DejaVu-Sans-Mono` — 代码

**没有 MathJax 字体**（说明公式是 vector / SVG 路径，不是 raster PNG with font fallback）—— 但 v7.9 当前实现是 cairosvg PNG 嵌入，**字体内嵌在 PNG 里**所以字体表不一样但视觉接近。

## 跟 v7.9 当前实现的已知差异（不影响公式效果）

| 项 | reference (16) | v7.9 current | 影响 |
|---|---|---|---|
| 页数 | 18 | 16 | 不影响公式渲染 |
| 大小 | 1.93 MB | 1.5 MB | cairosvg PNG 没 inline SVG 大 |
| YAML strip | 未 strip（4 行 metadata 漏出） | 已 strip | 当前更好 |
| cairosvg 失败 | 10 个 fallback 红色 span | 0 | 当前更好 |
| 公式行高 | 自然 | 自然 | 一致 ✓ |
| 公式字符 visual | 自然 ≈ 14-21 px | 自然 ≈ 14-21 px | 一致 ✓ |

**结论**：v7.9 = reference (16) 的"修好版"——所有渲染参数和公式效果一致，**额外修复了 reference 的 10 个 cairosvg 失败 + YAML leak**。这两件事让 v7.9 比 reference 还少 2 页（更紧凑）。

## Regression check — 任何改 render.py / report.css 后必跑

```bash
# 1. 重新渲染
python3 /home/yanyunfei/.hermes/skills/rethinkfun-lecture/scripts/render.py \
  reports/diffusion-model-report.md -o /tmp/_regression.pdf

# 2. 抽 4 页 PNG
for p in 1 4 7 12; do
  pdftoppm -r 150 -f $p -l $p /tmp/_regression.pdf /tmp/_reg_p$p -png
done

# 3. Pixel audit — display 公式 avg actual_h 必须 = 24-27 px
python3 -c "
from PIL import Image
import numpy as np
def measure(path):
    im = Image.open(path).convert('L')
    arr = np.array(im)
    h, w = arr.shape
    row_ink = (arr < 128).sum(axis=1)
    segs = []
    in_s, s = False, 0
    for y, ink in enumerate(row_ink > 5):
        if ink and not in_s: in_s, s = True, y
        elif not ink and in_s:
            in_s = False
            if 20 <= y - s <= 100:
                row = arr[s:y]
                ink_rows = (row < 128).any(axis=1)
                if ink_rows.any():
                    actual_h = (len(ink_rows) - 1 - np.argmax(ink_rows[::-1])) - np.argmax(ink_rows) + 1
                    segs.append(actual_h)
    return segs

import glob
for p in [1, 4, 7, 12]:
    path = f'/tmp/_reg_p{p}-{p:02d}.png'
    segs = measure(path)
    if segs:
        avg = sum(segs) / len(segs)
        ok = 22 <= avg <= 28
        flag = 'OK' if ok else 'FAIL'
        print(f'p{p}: avg_h={avg:.1f}px (count={len(segs)})  {flag}')
    else:
        print(f'p{p}: 0 formulas')
"

# 4. cairosvg 错误检查
pdftotext -layout /tmp/_regression.pdf - | grep -c '\[公式渲染失败'
# 必须 = 0

# 5. PDF 嵌入图必须有 ≥ 100 张
pdfimages -list /tmp/_regression.pdf | awk '$2 ~ /^[0-9]+$/' | wc -l
# 必须 ≥ 100
```

**判断标准**：
- 4 页 avg actual_h 都在 22-28 px 范围 → v7.9 reference 风格保持 ✓
- 任意一页 avg > 30 → display 公式被强制放大 / 走错了
- 任意一页 avg < 22 → display 公式被强制缩小 / 走错了
- cairosvg 错误 > 0 → min-width 修复回退了（v7.8 教训）
- 嵌入图 < 100 → PNG 嵌入管断了（v7.5 之前的黑块会回来）

## 历史脉络

| 版本 | display 公式 sizing | cairosvg 错误 | user 反应 |
|---|---|---|---|
| v7.5 | PNG 物理（reference 风格） | 10 | 用户拒绝（"公式渲染问题太多"） |
| v7.6 | 同 v7.5 | 10 | 同上 |
| v7.7 | EX_TO_PX 5 + inline 17px | 10 | 用户："公式字体大" |
| v7.7.2 | EX_TO_PX 5 + inline 17px + display max-width 100% | 10 | "渲染错误没看到" |
| v7.8 | + min-width: Xex fallback | **0** | "大公式显示不正确" |
| v7.8.4 | + max_h=80 display | 0 | "还是太大" |
| v7.8.5 | + max_h=40 display | 0 | 同上 |
| v7.8.6 | + max_h=25 display | 0 | 同上 |
| v7.8.7 | + min 18 / max 50 / ×2 display | 0 | "输出"（含糊认可） |
| **v7.9** | **EX_TO_PX=7.2 + PNG 物理 + max-width: 100%** | **0** | **"这个版本就很好很到位"** |

**v7.8.4-v7.8.7 是反修复（fixing nothing wrong）**——display 公式在 v7.7.2 就已经按 PNG 物理显示且用户没抱怨大小（只是 v7.5 修复 cairosvg 失败时 inline 公式撑高了行）。v7.8.4-v7.8.7 的 max_h/min_h clamp 是**过度修正**。

## 不要尝试的修改（明确禁止）

1. **不要加 display 公式 max_h/min_h clamp**（v7.8.4-v7.8.7 反修复路径，已证伪）
2. **不要改 EX_TO_PX** 从 7.2 改成 5 或 8.5（5 = 字符视觉太小，8.5 = 字符视觉太大；7.2 = LaTeX 0.45em 标准）
3. **不要改 inline 17px**（1.2em body 是 LaTeX 默认 inline formula 高度；改 14px 让字符 visual = 12px = 0.85em 太矮）
4. **不要把 body line-height 从 1.7 改回 1.55**（v7.7 当时改 1.55 是想让 inline 公式不撑高行；现在 PNG 物理对了 line-height 1.7 不会撑高）
5. **不要"为了一致性"把所有公式固定同一像素高度**（LaTeX 不同公式自然不同高度；强制统一是反 LaTeX 风格）

## 一句话总结

**Reference PDF #16 = v7.9 的 ground truth。** 改 render.py / report.css 之前先**对照这个文件** —— pixel baseline 是 4 页 display 公式平均 24-27px。**任何让 avg 偏离 [22, 28] 范围的改动 = 错。**
