# KaTeX + WeasyPrint PDF Pipeline — 调试笔记

> 写于 2026-06-23，扩散模型报告渲染时发现并解决的真实问题。

## TL;DR

**别用 latex2mathml + WeasyPrint 直接出 PDF**。数学公式会平铺成文字（分数不堆叠、根号不显示、大括号不变形），看着像 LaTeX 实际不是。

**用 KaTeX CLI**。KaTeX 输出带 CSS 定位的 HTML+MathML，WeasyPrint 能正确执行这些 CSS，分数、根号、大括号都能像 LaTeX 那样渲染。

## 现象

写完扩散模型报告用 latex2mathml 渲染数学公式，PDF 出来后用 `pdftotext` 抽文字看：

```
xt−1= 1 αt (xt− βt 1−α¯t εθ(xt,t))+σtz
```

期望是 `x_{t-1} = 1/α_t · (x_t − β_t/√(1-α_bar_t) · ε_θ) + σ_t z` 这种带堆叠分数的 LaTeX 风，实际是 `1/αt` 平铺成 `1 αt`，`β_t/√(1-α_bar_t)` 平铺成 `βt 1−α¯t εθ`。

## 根因

WeasyPrint 走 Pango 渲染，Pango 的 MathML 支持**不完整**：
- `<mfrac>` 不堆叠（numerator/denominator 平铺）
- `<msqrt>` 可能不渲染（变成普通字符）
- `<mfenced>` 大括号不动态撑高
- 大型运算符号（∫, ∑）尺寸不缩放

latex2mathml 输出的是合法 MathML，但 Pango 不会按 LaTeX 期望那样画。

## 解法：KaTeX

KaTeX 是 Khan Academy 出的 LaTeX 渲染器，跟 MathJax 同类但更轻量、专为服务器端优化。

KaTeX 的关键差异：**用 CSS 定位 + 自家字体做数学排版**，不依赖浏览器 MathML 实现。

具体地：
- 分数用 `display: inline-block` + `position: absolute` 堆叠分子分母
- 根号用 inline SVG
- 大括号用绝对定位动态撑高
- 数学符号用 KaTeX 自家字体（KaTeX_Main, KaTeX_Math, KaTeX_Size 等）
- 希腊字母、子上下标都按 LaTeX 习惯排版

WeasyPrint 能正确执行 KaTeX 的 CSS（毕竟就是 CSS），所以渲染效果接近 LaTeX。

## 实现路径

### 工具链

- **KaTeX CLI**：`/snap/code/247/usr/share/code/resources/app/node_modules/katex/cli.js`
  - 来源：snap 装的 VS Code 自带 katex 0.16.22
  - **不要重新 `npm install katex`**，网络装 katex + mhchemparser 会 timeout
- **KaTeX CSS**：`/snap/code/247/usr/share/code/resources/app/node_modules/katex/dist/katex.min.css`
  - 复制到 `~/.hermes/skills/rethinkfun-lecture/templates/katex.min.css`
- **KaTeX 字体**：`/snap/code/247/usr/share/code/resources/app/node_modules/katex/dist/fonts/`
  - 60 个 woff/woff2/ttf 文件（KaTeX_Main / KaTeX_Math / KaTeX_Size / KaTeX_AMS / KaTeX_Caligraphic / KaTeX_Fraktur）
  - 共 ~1.2 MB
  - 复制到 `~/.hermes/skills/rethinkfun-lecture/templates/katex-fonts/`

### 关键陷阱：base_url 必传

KaTeX CSS 里的字体引用是相对的：

```css
@font-face {
  font-family: 'KaTeX_Main';
  src: url(fonts/KaTeX_Main-Regular.woff2) format('woff2'),
       url(fonts/KaTeX_Main-Regular.woff) format('woff'),
       url(fonts/KaTeX_Main-Regular.ttf) format('truetype');
}
```

WeasyPrint 解析 `url(fonts/...)` 时必须有 base_url 指向 `templates/` 目录，否则字体找不到 → 公式变方块或回退到默认字体。

```python
from weasyprint import HTML

HTML(string=html_str, base_url=str(templates_dir)).write_pdf(pdf_path)
#                                          ^^^^^^^^^^^^^^^^^^^^ 关键
```

### KaTeX CLI 调用

```python
import subprocess

KATEX_CLI = "/snap/code/247/usr/share/code/resources/app/node_modules/katex/cli.js"

def render_math(latex, display=False):
    args = ["node", KATEX_CLI]
    if display:
        args.append("-d")  # display mode（块级）
    args += ["-F", "htmlAndMathml"]  # 同时输出 HTML + MathML
    args += ["-t"]  # 解析失败时不要 throw，渲染错误文字
    
    result = subprocess.run(args, input=latex + "\n", 
                          capture_output=True, text=True, timeout=15)
    if result.returncode != 0 or not result.stdout.strip():
        return f'<span class="katex-error">{result.stderr[:200]}</span>', False
    return result.stdout.strip(), True
```

`htmlAndMathml` 格式输出两层：`<span class="katex-mathml">...MathML...</span>` 给屏幕阅读器，`<span class="katex-html">...HTML...</span>` 给视觉渲染。WeasyPrint 渲染 HTML 层，忽略 MathML 层（MathML 在 WeasyPrint 里反而画不好）。

### 渲染顺序

**关键**：先抽数学占位符，再让 markdown 处理，最后再把占位符替换成 KaTeX 输出。

如果顺序反了（先 markdown 再抽数学），markdown 会把 LaTeX 里的 `_` 当斜体：`\mathbb{E}_{t, x_0}` → `\mathbb{E<em>{t, x_0}` → KaTeX 解析失败。

```python
# Step 0: 抽占位符
md_safe, placeholders = extract_math_placeholders(md_text)

# Step 1: markdown → HTML（占位符不会被解释）
body = markdown.Markdown(...).convert(md_safe)

# Step 2: 占位符 → KaTeX HTML
for ph, latex, display in placeholders:
    rendered, ok = render_math(latex, display)
    body = body.replace(ph, wrapped_html(rendered, display))
```

占位符用 `\x00MATH####\x00`（NUL 字符包裹），markdown 不会解释 NUL，KaTeX 也不会见到。

## 渲染验证

跑完后必须验证：

```python
def verify_render(html_path):
    issues = []
    body_only = re.sub(r'<style>.*?</style>', '', html, flags=re.DOTALL)
    
    # 1. KaTeX 错误回退
    if body_only.count("katex-error"):
        issues.append("KaTeX 渲染失败")
    
    # 2. 占位符残留
    if re.findall(r'\x00MATH\d{4}\x00', html):
        issues.append("占位符未替换")
    
    # 3. 原始 $ 残留
    if re.findall(r'(?<!\\)\$[^$\n]+\$(?!\$)', body_only):
        issues.append("未转换的 $...$")
    
    # 4. <em> 渗入 math（说明 markdown 把 _ 当斜体了）
    if re.findall(r'math-(block|inline)[^<]*<em>', html):
        issues.append("markdown 斜体污染了 LaTeX")
    
    return issues
```

任何一项失败 → exit 1，**不发 PDF**。

之前那次发送的 PDF 里有 `math-error-block` 红色回退块但我直接发了，被大哥怼了"你自己报告有报错就直接发给我了"。现在 verify_render 强制卡住，渲染失败必重试不绕过。

## 验证视觉效果

PDF 出来后用 `pdftotext -layout` 抽文字看：

```bash
pdftotext -layout report.pdf - | grep "Lsimple"
```

期望看到 `Lsimple(θ)=𝔼t,x0,ε[∥ε−εθ(...)∥²]` 这种带完整子标和范数符号的输出，而不是 `Lsimple(θ)=Et,x0,e[...]` 平铺版本。

如果公式还是平铺的，检查：
1. `base_url` 是否传了
2. KaTeX CSS 是否 inline 进 HTML 了
3. `templates/katex-fonts/` 目录是否存在且有 60 个字体文件
4. 用浏览器打开 `.html` debug 文件，公式应该正常显示（如果 HTML 里正常但 PDF 里不正常，问题在 WeasyPrint 的 CSS 应用）

## 不该做的事

- ❌ 用 `latex2mathml`（分数不堆叠，看起来像 LaTeX 实际不是）
- ❌ 让 markdown 先跑再处理 LaTeX（`_` 会被当斜体）
- ❌ 不传 `base_url` 给 WeasyPrint（字体找不到）
- ❌ 跳过 verify_render 直接发 PDF（用户会怼）
- ❌ `npm install katex` 从零装（timeout 概率高）

## 该做的事

- ✅ KaTeX CLI shell-out（每条公式 ~50ms，长报告可接受）
- ✅ 先抽占位符 → markdown → KaTeX 替换
- ✅ WeasyPrint `base_url` 指向 templates/
- ✅ verify_render 强制卡住 + KaTeX 错误时直接 exit 1
- ✅ Reuse `/snap/code/.../node_modules/katex/` 而不是重装