# v7.2.3 cairosvg + MathJax 完整 SVG 处理 Pipeline

> **v7.5 重要更新（supersedes v7.2.3 的部分修复）**：v7.2.3 的 `ex→px` 替换靠 `re.sub(r'width="([\d.]+)ex"', ...)` 改 attribute——**但 lxml.etree recover+unwrap 后，width/height attribute 可能丢失**（特别是嵌套 SVG unwrap 时）。结果 cairosvg 拿到没有 width/height 的 SVG，**fallback 到默认 75×72 / 300×150**——PDF 里每个失败公式变成 117B 纯黑方块。**v7.5 修复**（`mjx_to_img` + 新 helper `_force_pixel_dims`）：解析完 SVG 后**强制重新注入** `<svg ... width="Wpx" height="Hpx">`——三个分支 (a) width+height 都从 ex 算 (b) 只有 width，从 viewBox aspect 推 height (c) 都没就别报错。**核心原则**：**ex 单位永远不许出现在 cairosvg 输入或 WeasyPrint 输入里**。cairosvg 失败时 fallback 改成红字错误 span，**禁止** fallback 到原 SVG（原 SVG 进 WeasyPrint 必出 75×72 纯黑方块）。

> 这是 v7.2.1（WeasyPrint SVG 不兼容 → 用 cairosvg 转 PNG）的**深入补丁**。v7.2.1 解决了"是否转 PNG"，**v7.2.3 解决"cairosvg 怎么正确转 100% 的 MathJax SVG"**。
>
> 2026-06-23 实测：v7.2.1 跑出来 75% 公式成功转 PNG，25% 因 cairosvg 失败 fallback 到 inline SVG。**v7.2.3 把 100% 公式都转成 PNG 嵌入**——这是渲染管线的最后 25% gap。

## 事件链

v7.2.1 把 cairosvg 集成到 render.py，但只做了 ex→px 替换 + 大 SVG fallback。跑 diffusion 报告时**只有 75% 公式转 PNG**——25% cairosvg 抛 `ParseError`。用户问"现在怎么样了"——3 轮迭代后定位根因，找到完整 6 步处理 pipeline。

**3 个独立失败模式**（cairosvg 对 MathJax SVG 的兼容性 bug）：

1. **`ex` 单位**：MathJax SVG `width="0.817ex"`、`height="2.176ex"`、`style="min-width: 50.649ex"`、`style="vertical-align: -1.009ex"`——cairosvg 不认 `ex` 单位，抛 `The SVG size is undefined`
2. **嵌套 `<svg>`**：MathJax 在处理 `\tag{}` 和 `aligned` 环境时输出 `<svg><svg>...</svg></svg>`——cairosvg 的 SVG 解析器遇到嵌套 SVG 直接放弃整个文件
3. **Unclosed `<g>` 标签**：MathJax v3 SVG 输出**本身有 bug**——某些公式（特别是含 `\tag{}` / `aligned` / 矩阵的）少几个 `</g>` 关闭标签，cairosvg 严格 XML 解析失败

## 6 步处理 Pipeline（顺序固定）

```python
import re
import cairosvg
from lxml import etree

def mjx_to_img(svg_string: str) -> str:
    """Convert MathJax SVG output to <img> with embedded PNG (cairosvg→PNG→base64).
    
    v7.2.3 pipeline — handles all 3 MathJax SVG incompatibilities:
    1. ex→px unit conversion
    2. width=100% → absolute
    3. lxml unwrap nested <svg>
    4. lxml recovery parser auto-closes unclosed <g>
    5. cairosvg → PNG
    6. Decode PNG header for width/height attrs (WeasyPrint layout)
    """
    # Step 0: extract <svg>...</svg>
    m = re.search(r'(<svg[^>]*>.*?</svg>)', svg_string, re.DOTALL)
    if not m:
        return svg_string
    svg_inner = m.group(1)
    
    # Step 1: lxml parse with recovery + unwrap nested <svg>
    if 'xmlns=' not in svg_inner[:200]:
        svg_inner = svg_inner.replace('<svg', '<svg xmlns="http://www.w3.org/2000/svg"', 1)
    
    parser = etree.XMLParser(recover=True, huge_tree=True)  # ← recover=True is critical
    root = etree.fromstring(svg_inner.encode('utf-8'), parser=parser)
    
    ns = '{http://www.w3.org/2000/svg}'
    for nested in root.findall(f'.//{ns}svg'):  # ← unwrap all nested
        parent = nested.getparent()
        if parent is None:
            continue
        idx = list(parent).index(nested)
        for j, child in enumerate(list(nested)):
            parent.insert(idx + j, child)
        parent.remove(nested)
    
    svg_inner = etree.tostring(root, encoding='unicode')
    # lxml may add ns0: prefix — strip
    svg_inner = svg_inner.replace('ns0:', '').replace(':ns0', '')
    svg_inner = re.sub(r'\s+xmlns:ns0="[^"]*"', '', svg_inner)
    
    # Step 2: ex → px (MathJax emits 1ex = 8px at default em=16; scale=3 for high DPI)
    def repl_w(mm): return f'width="{int(float(mm.group(1)) * 8 * 3)}"'
    def repl_h(mm): return f'height="{int(float(mm.group(1)) * 8 * 3)}"'
    s = re.sub(r'width="([\d.]+)ex"', repl_w, svg_inner)
    s = re.sub(r'height="([\d.]+)ex"', repl_h, s)
    s = re.sub(r'style="vertical-align:\s*-?[\d.]+ex;"',
               'style="vertical-align: middle;"', s)
    s = re.sub(r'min-width:\s*[\d.]+ex;?', '', s)
    s = re.sub(r'vertical-align:\s*-?[\d.]+ex;?', 'vertical-align: middle;', s)
    
    # Step 3: width=100% → absolute (cairosvg rejects %)
    s = re.sub(r'width="100%"', 'width="800"', s)
    
    # Step 4: cairosvg → PNG
    try:
        png_bytes = cairosvg.svg2png(bytestring=s.encode('utf-8'), scale=3)
    except Exception:
        # Fallback to original SVG (WeasyPrint will try to render it)
        return svg_string  # or: return f'<div class="math-block">{svg_string}</div>'
    
    # Step 5: decode PNG dimensions from header (bytes 16-24) for WeasyPrint
    try:
        png_w = int.from_bytes(png_bytes[16:20], 'big')
        png_h = int.from_bytes(png_bytes[20:24], 'big')
        size_attr = f'width="{png_w}" height="{png_h}"'
    except Exception:
        size_attr = ''
    
    # Step 6: base64 → <img> with explicit width/height
    b64 = base64.b64encode(png_bytes).decode('ascii')
    data_url = f"data:image/png;base64,{b64}"
    
    is_display = 'display="true"' in svg_string
    if is_display:
        return (f'<div class="math-block">'
                f'<img src="{data_url}" alt="formula" {size_attr} '
                f'style="display:block; margin:0 auto; max-width:100%; height:auto;"/>'
                f'</div>')
    return (f'<img src="{data_url}" alt="formula" {size_attr} '
            f'style="vertical-align: middle; max-height: 1.6em; max-width: 100%;"/>')
```

## 关键 Pitfall：不要手动 balance `<g>` 标签

**v7.2.2 之前**的失败尝试：

```python
# ❌ 错的！lxml recovery 已 auto-close，手动加会破坏嵌套结构
g_open = s.count('<g')
g_close = s.count('</g>')
if g_open > g_close:
    s = s.replace('</svg>', '</g>' * (g_open - g_close) + '</svg>')
    # cairosvg 仍然报 "mismatched tag" at column 14917
```

**为什么错**：MathJax SVG 的 `<g>` 嵌套在 `<defs>` / `<clipPath>` 等元素里——简单 regex 计数假设了"所有 `<g>` 都在同一个 nesting 上下文里"。**手动加 `</g>` 会把"已经修好的"嵌套结构再加一遍 close**——cairosvg 的 strict parser 看到 "多 close" 报 "mismatched tag"。

**正确做法**：让 lxml 的 `recover=True` 自动 close missing `</g>`——它的 tree-walking 知道正确的 nesting 上下文。**完全不要在 cairosvg 之前手动 balance**。

## 验证脚本（v7.2.3 后必跑）

```python
import re
from PIL import Image
import numpy as np

# 1. cairosvg 成功率
import subprocess
result = subprocess.run(
    ['node', 'render_math.js', '--display'],
    input=sample_latex + '\n',
    capture_output=True, text=True, cwd='/home/yanyunfei/reports/mathjax-test'
)
svg = result.stdout

# Try the 6-step pipeline
try:
    from your_render_module import mjx_to_img
    img_html = mjx_to_img(svg)
    has_png = 'data:image/png' in img_html
    has_dims = 'width="' in img_html and 'height="' in img_html
    assert has_png, f"❌ cairosvg failed for: {sample_latex[:30]}"
    assert has_dims, f"❌ no width/height in <img>: {img_html[:200]}"
    print("✓ v7.2.3 pipeline OK")
except Exception as e:
    print(f"❌ pipeline error: {e}")

# 2. Full report: 100% 公式成功
import re
html = open('report.html', encoding='utf-8').read()
all_imgs = []
i = 0
while True:
    idx = html.find('<img', i)
    if idx == -1: break
    end = html.find('>', idx)
    if end == -1: break
    tag = html[idx:end+1]
    if 'data:image/png' in tag:
        all_imgs.append(tag)
    i = end + 1
total = len(all_imgs)
with_dims = sum(1 for t in all_imgs if 'width="' in t and 'height="' in t)
print(f"Formula <img>: {total}, with width/height: {with_dims} ({100*with_dims/max(total,1):.0f}%)")
assert with_dims == total, f"❌ {total-with_dims} <img> missing dims"

# 3. PDF 真实嵌入图
result = subprocess.run(['pdfimages', '-list', 'report.pdf'],
                        capture_output=True, text=True)
image_count = len([l for l in result.stdout.split('\n')[2:] if l.strip()])
print(f"PDF embedded images: {image_count}")
# 每个 PNG 算 2 张 (含 smask alpha 通道)，所以 574 公式 ≈ 1128 张图
assert image_count > total, f"❌ PDF images ({image_count}) < formula count ({total})"

# 4. 视觉抽查（page 1-3 至少要有"公式"视觉密度，不是空白）
for p in [1, 2, 3]:
    subprocess.run(['pdftoppm', '-png', '-r', '120', '-f', str(p), '-l', str(p),
                    'report.pdf', f'/tmp/p{p}'], check=True)
    img = np.array(Image.open(f'/tmp/p{p}-{p:02d}.png').convert('L'))
    row_ink = (img < 200).sum(axis=1) / img.shape[1]
    formula_bands = sum(1 for i in range(1, len(row_ink))
                        if 0.05 < row_ink[i] < 0.4 and abs(row_ink[i] - row_ink[i-1]) > 0.1)
    print(f"  page {p}: {formula_bands} formula-like bands")
    assert formula_bands > 5, f"❌ page {p} has only {formula_bands} formula bands (expected >5)"
```

## 失败模式诊断表

| cairosvg 错误 | 根因 | 修复 |
|---|---|---|
| `The SVG size is undefined` | SVG 含 `ex` 单位或 `width="100%"` | ex→px 替换 + 100%→800 |
| `no element found: line 1, column N` | MathJax SVG 末尾缺失 `</g>` 标签 | lxml `recover=True` 自动修复 |
| `mismatched tag: line 1, column N` (unbalanced) | **手动 balance 加的** `</g>` 太多 | **删除**手动 balance 代码（让 lxml 修） |
| `mismatched tag: line 1, column N` (nested) | MathJax 嵌套 `<svg>` | lxml findall 嵌套 SVG + unwrap |
| `URLError: <urlopen error Is a directory>` | 嵌套 SVG 解析失败暴露给 cairosvg | 同上（unwrap 嵌套 SVG） |
| `ParseError: mismatched tag: column 410` | `strip_nested_svg` regex 太贪婪（v7.2.2 早期） | **改用 lxml unwrap**（不是 regex） |

## 与 v7.2.1 的关系

v7.2.1 引入了 cairosvg fallback pipeline（cairosvg→PNG→base64）。v7.2.3 **不替换** v7.2.1——是**补丁**。v7.2.1 解决了"是否用 cairosvg"，v7.2.3 解决了"cairosvg 100% 成功处理 MathJax SVG"。

**两个版本同时需要**：
- v7.2.1 = cairosvg 集成（架构选择）
- v7.2.3 = cairosvg 6 步处理 pipeline（实现细节）

## 给未来 agent 的强约束

1. **cairosvg 处理 MathJax SVG 必须按 6 步走**——任何一步漏掉都会让 5-25% 公式 cairosvg 失败
2. **`lxml.XMLParser(recover=True)` 是 v7.2.3 的核心**——不要用默认 strict parser
3. **不要手动 balance `<g>` 标签**——lxml recovery 已修好，手动加会破坏嵌套
4. **不要用 regex strip 嵌套 `<svg>`**——regex 太贪婪；用 lxml findall + unwrap
5. **PNG header 解码 width/height**——`int.from_bytes(png[16:20], 'big')` 拿真实像素，让 WeasyPrint 正确布局
6. **超宽公式（width > 600px）加 `height: auto`**——保持宽高比不被 max-width 压扁

## 修复前后对比（diffusion 报告 574 公式）

| 指标 | v7.2.1 (前) | v7.2.3 (后) |
|------|-------------|-------------|
| cairosvg 成功率 | 75% (~430/574) | 100% (574/574) |
| inline SVG fallback | 25% (~144/574) | 0% |
| `<img>` 带 width/height | 0% (regex bug) | 100% (574/574) |
| PDF 嵌入图张数 | 1126 (cairo + smask) | 1128 (PNG + smask) |
| 视觉抽查：page 1-3 公式带 | 10-30/页 | 9-32/页（与前相当） |
| 公式视觉质量 | 模糊 / 错位 | 锐利 / 完整 |

## 相关文件

- `scripts/render.py` — v7.2.3 完整 6 步 pipeline 在 `mjx_to_img()` 函数
- `references/weasyprint-svg-incompatibility.md` — v7.2.1 复盘（WeasyPrint SVG + cairosvg 集成 + sys.exit 删除 + YAML + footer）
- `references/this file` — v7.2.3 复盘（cairosvg 6 步 pipeline，100% 公式成功）
- `references/render-verification-blind-spots.md` — v7.2 复盘（MathJax error 6 项 grep）

## 历史教训

**2026-06-23 三轮迭代的具体过程**（避免未来 agent 重复同样的瞎试）：

**第 1 轮（v7.2.2 末尾）**：试了 `strip_nested_svg` 用 regex `<svg...>(?:(?!<svg).)*?</svg>` 反复 replace——**太贪婪，把所有 SVG 都 strip 了**（只剩 437 字符）。失败。

**第 2 轮**：试了用 lxml 严格 parser `etree.fromstring()` 解析——**失败**，因为 SVG 本身 unclosed `<g>` 让 XMLSyntaxError 失败。失败。

**第 3 轮（突破）**：用 `lxml.XMLParser(recover=True)`——**lxml 自动修复 unclosed tags** + findall nested SVG unwrap。**100% 成功**。

**关键诊断**：
- `re.findall(r'<img[^>]+src="data:image/png:base64,', html)` 这个 regex 漏 width/height 检测——**应该用 `<` split walk**（先找 `<img`，再找匹配 `>`）
- `pdftotext` 不渲染 SVG——不能用作"公式是否真的渲染"的视觉检查
- cairosvg 报 `mismatched tag at column N` 时，N 通常在 SVG 末尾——**先看 SVG 末尾的 `</g></g></g></g></svg>` 区域**

## 完整 pipeline 文件位置

render.py 的 `mjx_to_img` 函数（v7.2.3）——完整实现可直接复制。**不要修改 reference prompts**（intuition-lecture-prompt.md / theory-rebuilder-prompt.md）——这些是写稿用的，不涉及渲染。
