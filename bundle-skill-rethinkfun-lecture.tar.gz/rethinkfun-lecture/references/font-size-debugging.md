# Font-size debugging (v7.7, found 2026-06-24)

User complaint: "公式渲染都这么大？你不能让公式的字体和 markdown 字体一样大小吗？"

## Symptom

Inline formulas visually larger than body text — every inline math row
**balloons to 2× text-row height**. `verify_pdf.py` (v7.5) passes
because the structural check only looks at HTML tags, not visual output.

## Diagnosis

The actual row-height of an inline math row depends on:
- PNG physical height (controlled by EX_TO_PX × SCALE in render.py)
- HTML attribute height (controls display size in WeasyPrint)
- CSS max-height (clamp visual size)
- body line-height (defines baseline-to-baseline spacing)

When any of these is wrong, the row expands to fit the PNG. Worst case:
PNG = 25px physical + body line-height 1.5×14 = 21px → row = max(25, 21) = 25px,
vs text row = 14px. **Ratio 25/14 = 1.78 — visually "too big".**

### Pixel audit (the standard method)

```bash
# Render page 1 at 100dpi and measure row heights
pdftoppm -r 100 -f 1 -l 1 report.pdf _audit_p1 -png

python3 -c "
from PIL import Image
import numpy as np

im = Image.open('_audit_p1-01.png').convert('L')
arr = np.array(im)
row_ink = (arr < 128).sum(axis=1)

# Find contiguous ink segments
segments = []
in_seg, start = False, 0
for y, has_ink in enumerate(row_ink > 5):
    if has_ink and not in_seg: in_seg, start = True, y
    elif not has_ink and in_seg:
        in_seg = False
        segments.append((start, y, y - start))

# Classify
text    = [s for s in segments if 8 <= s[2] <= 18]
inline  = [s for s in segments if 19 <= s[2] <= 32]
display = [s for s in segments if 33 <= s[2] <= 100]

t_avg = sum(s[2] for s in text) / max(1, len(text))
i_avg = sum(s[2] for s in inline) / max(1, len(inline)) if inline else 0
print(f'text_avg={t_avg:.1f}px  inline_avg={i_avg:.1f}px  ratio={i_avg/t_avg:.2f}')
"
```

Healthy range:
- `text_avg = 13-15 px` (body 10.5pt @ 100dpi)
- `inline_avg ≤ 1.5 × text_avg` (= ≤ ~21px)
- `inline_avg > 1.7 × text_avg` → **fix it**

## Root cause (and fix)

The fix has 3 layers and **all 3 are required** — fixing only one leaves
residual issues.

### Layer 1: SCALE in render.py

```python
# render.py — EX_TO_PX × SCALE defines PNG physical height
EX_TO_PX = 5.0     # 1ex = 5px (raw)
SCALE = 1.5        # 1.5× DPI multiplier → 1ex = 7.5px physical

# Bad values (v7.5 / v7.6):
#   EX_TO_PX = 8.5, SCALE = 3  → 1ex = 25.5px  (way too big)
#   EX_TO_PX = 7.2, SCALE = 2  → 1ex = 14.4px  (still too big)
#   EX_TO_PX = 7.2, SCALE = 1.5 → 1ex = 10.8px (v7.7: still row-ballooning)
```

`1ex` physical should be **5-7.5 px** (≈ 0.4-0.55em for 14px body).

### Layer 2: Display size pinned in HTML attribute (CRITICAL)

WeasyPrint honors HTML `width`/`height` attributes more strictly than CSS
`max-height` (because the attribute sets intrinsic size; CSS just constrains
it). CSS `max-height: 1.1em` does NOT reliably clamp the row in WeasyPrint.

```python
# render.py — mjx_to_img() output for INLINE formulas
display_h = 17                              # fixed 1.2em of 14px body
display_w = max(1, int(round(17 * png_w / png_h)))
return (f'<img src="{data_url}" alt="formula" '
        f'width="{display_w}" height="{display_h}" '
        f'style="vertical-align: middle;"/>')
```

17 px = 1.2em × 14px body font-size. This is the LaTeX default
"all inline formulas same visual height regardless of internal ex count".

### Layer 3: CSS line-height on math-inline

```css
/* report.css — prevent .math-inline from blowing up parent row */
.math-inline {
  display: inline-block;
  line-height: 1.0;       /* CRITICAL: clamp row contribution */
  vertical-align: baseline;
}
.math-inline img {
  vertical-align: middle;
  max-height: 1.1em;     /* belt + suspenders */
  width: auto;
  height: auto;
}
```

`line-height: 1.0` on `.math-inline` prevents the math wrapper itself
from contributing extra height to the parent text row.

## Display formula overflow (separate issue)

`pdfimages -list report.pdf` may show entries like `882x33` or `976x51`
or `964x33` — display formulas **wider than A4 content area** (793px
@ 96dpi with default 1.8cm margins). These get clipped or pushed off.

Fix: add to `report.css`:

```css
.math-block img {
  max-width: 100%;   /* scale down to container */
  height: auto;
}
```

And in render.py, for display formulas don't pin width/height — let
WeasyPrint scale down via max-width:

```python
if is_display:
    return (f'<div class="math-block">'
            f'<img src="{data_url}" alt="formula" '
            f'width="{png_w}" height="{png_h}" '
            f'style="display:block; margin:0.6em auto; max-width:100%; height:auto;"/>'
            f'</div>')
```

## verify_pdf.py catches these (v7.7+)

The new `--visual-audit` mode in `scripts/verify_pdf.py` automatically
detects both:
- **Row-height ratio > 1.7**: inline math too tall (the v7.7 bug)
- **Image width > 793px**: display formulas overflowing page

```bash
python3 scripts/verify_pdf.py report.pdf   # runs visual-audit by default
# [row-height] text_avg=13.4px  inline_avg=24.5px  ratio=1.83
# ❌ Inline formula row-height too tall: ...
```

## Verification: eyeball 2-3 pages

Even with all the smoke tests passing, **always** sample 2-3 pages
visually (render PNG via `pdftoppm -r 150`, send via `MEDIA:` path).
Pixel analysis catches structural issues; vision catches:
- Formula glyph looks blurry (low DPI)
- Formula baseline doesn't align with text baseline
- Specific formulas rendered wrong (not just "too big")
- Footer/header artifacts the smoke test missed

This was the v7.7 lesson: smoke test passing ≠ visually correct.
