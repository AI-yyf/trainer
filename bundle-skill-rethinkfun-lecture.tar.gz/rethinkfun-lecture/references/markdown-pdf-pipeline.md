# Markdown → PDF Pipeline 设计笔记

> **当前栈**：MathJax v3 + cairosvg PNG + WeasyPrint。本文保留整体渲染结构与常见坑；KaTeX 专属细节仅作历史记录，当前实现以 `scripts/render.py`、`references/retina-render-pipeline.md`、`references/weasyprint-svg-incompatibility.md` 为准。

## 为什么选这套工具栈

环境约束（hermes-agent 容器，2026 年实测）：

- 没有 `pandoc` / `xelatex` / `pdflatex`（apt 装需要 sudo，TeX Live 又大又慢）
- 没有 `wkhtmltopdf` / `typst`
- Python venv 里已有 `weasyprint 69`、`markdown 3.10`、`Pygments 2.19`
- Node.js 可装 `mathjax-full@3`（**注意 `--no-optional` 必传**，跳 mhchemparser）+ `mmdc`（首次拉 Chromium 100+ MB）

最终栈：**weasyprint + markdown + MathJax v3 + mmdc (optional)**。

## 关键决策

### 1. LaTeX 公式：MathJax v3 替换 KaTeX

> **v7.1 切换**：原 KaTeX 路径已废弃。KaTeX 输出 CSS 定位 HTML+MathML，WeasyPrint 渲染效果不错但**对中文混排的某些复杂公式（如 `\operatorname{}`、嵌套分数）支持较弱**。MathJax v3 输出**纯 SVG**，glyph 全部内联为 `<path>`，不需要外部字体，STIX 风格字体更接近 LaTeX Computer Modern。**完整迁移笔记见 `references/mathjax-v3-pipeline.md`。**

- WeasyPrint 57+ 原生支持 MathML，但走 Pango 渲染时分数不堆叠、根号不显示、大括号不变形 — 公式平铺成文字
- `latex2mathml` 输出的 MathML 是合法的，但 Pango 渲染不完整
- ~~KaTeX CLI~~（**已废弃**）：复用 snap code 自带 katex，**不要 npm install**
- **当前方案：MathJax v3**：
  - 安装：`cd /home/yanyunfei/reports/mathjax-test && npm install --no-optional --no-audit --no-fund mathjax-full@3`
  - **`--no-optional` 必传**：跳过 `mhchemparser`（依赖装不上，整个 install 会失败）
  - MathJax v3 输出**纯 inline SVG**，每个 glyph 都是 `<path>`，WeasyPrint 无需找外部字体
  - 字体用 STIX 风格（更接近 LaTeX Computer Modern 的外观）
  - 调试笔记见 `references/mathjax-v3-pipeline.md`

### 2. Mermaid：mmdc + inline SVG，fallback 到代码块

- mmdc 渲染 Mermaid 到 SVG（矢量、可缩放）
- 第一次跑 `npx -y @mermaid-js/mermaid-cli` 会下载 ~150 MB Chromium，60-180 秒
- 加 `--no-mermaid` 可跳过，PDF 里会保留代码块（带 `mermaid-source` 黄色背景 CSS 区分）
- **重要**：SVG 内的 `font-family` 不会继承 PDF 全局字体，需要在 SVG 里显式指定 `Noto Sans CJK SC`，否则中文变豆腐
- 更稳的替代：直接手写 inline SVG（无外部依赖），放报告里需要流程图时手画

### 3. Chinese 字体：Noto CJK SC

- 系统已装 `/usr/share/fonts/opentype/noto/NotoSerifCJK-*.ttc`
- CSS 用 `font-family: 'Noto Serif CJK SC', 'Noto Sans CJK SC', serif;`
- 衬线（serif）做正文，无衬线（sans）做标题 — RethinkFun 视频风格的视觉对应

### 4. MathJax 字体

> **v7.1 切换**：MathJax v3 输出**纯 inline SVG**，glyph 全部内联为 `<path>`，**不需要外部字体文件**。原来 KaTeX 字体复制那一段（`templates/katex-fonts/`、`base_url` 必须指向 templates/）已废弃。MathJax 路径下 WeasyPrint 不需要 `base_url` 解析字体路径——这是 MathJax 相对 KaTeX 的**最大简化**。

### 5. Markdown 扩展选择

- `extra` — 表格、围栏代码、脚注等基础扩展
- `codehilite` — 代码块语法高亮（需要 Pygments）
- `toc` — 自动生成目录（如果 H1/H2/H3 多）
- `sane_lists` — 智能列表嵌套
- `smarty` — 引号智能转换

⚠️ 新版 markdown 库的 `codehilite` 扩展不再生成 `.codehilite` wrapper class。CSS 选择器改成 `pre span.k` / `pre span.nf` 等直接匹配 Pygments 输出的 span class。

## 坑位清单

1. **数学必须先抽占位符再让 markdown 跑**：markdown 会把 `_x` 当斜体，LaTeX 下标会变 `<em>`。占位符用 `\x00MATH####\x00`（NUL 字符包裹）。
2. **WeasyPrint 不支持 `<style scoped>`**：必须把所有 CSS 塞到 `<style>` 标签或外部文件。
3. **inline SVG 里的中文**：必须在 SVG 内部 `text` 标签写 `font-family="Noto Sans CJK SC"`，不继承全局。
4. **H1 自动分页**：CSS 写 `page-break-before: always` 让每个 H1 起新页；但首张 H1 写 `page-break-before: avoid`。
5. **代码块过长导致分页丑**：用 `page-break-inside: avoid` 保护，但代码很长时强制不切也不行——只能在写稿时控制代码块 ≤ 30 行。
6. **`$` 匹配冲突**：MD 里如果有 USD 价格（`$100`），会被误判为 inline math 起点/终点。脚本里用了 `(?<![\\$])\$(?!\$)` 防止，但还是有边界情况。
7. **Pygments CSS 主题**：模板里写的是自定义配色（基于 One Dark 调色板）；要换主题就改 CSS 里 `pre span.k` 等那一段。
8. **venv 路径**：脚本默认用 `python3` 解释器。如果 weasyprint 装在 hermes-agent venv 里，要用 `/home/yanyunfei/.hermes/hermes-agent/venv/bin/python` 显式调用。
9. **verify_render 只做前置告警**：任何渲染异常（MathJax 失败 / cairosvg fallback / 占位符残留 / `<em>` 渗漏）都要显式报出来；真正阻断发稿的是 `scripts/verify_pdf.py`。
10. **CSS 必须 inline 进 HTML**：不要 `CSS(filename=...)`，用 `<style>{css_text}</style>` 内联。这样报告是单文件，WeasyPrint 解析也更稳定。

## 替代方案对比

| 方案 | 优点 | 缺点 |
|---|---|---|
| **当前栈 (weasyprint + markdown + MathJax v3 + mmdc)** | 纯本地、轻量、矢量公式、LaTeX 风最接近 | mmdc 首次慢、MathJax v3 每条公式比 KaTeX 慢约 2x（~100ms）但 SVG 质量更高 |
| pandoc + LaTeX (xelatex) | 公式完美、生态最丰富 | 装 TeX Live 1-2 GB，apt 需 sudo |
| md-to-pdf (npm) | 一行命令、内置 MathJax | MathJax 需要网络、定制性差 |
| Puppeteer / Playwright | JS 全支持、MathJax / KaTeX 原生 | 装 Chromium 重、慢 |
| Typst | 新、公式漂亮、编译快 | 装 typst CLI、md 支持有限 |
| ~~weasyprint + latex2mathml~~ | ~~纯本地、轻量~~ | **分数不堆叠、根号不显示、大括号不变形 — 公式平铺成文字，已废弃** |
| ~~weasyprint + KaTeX~~ | ~~CSS 定位、效果接近 LaTeX~~ | **中文混排复杂公式（\operatorname{}、嵌套分数）支持弱，v7.1 切到 MathJax v3** |

## 性能数据

- 一份 ~30 页中文技术报告（带 20 个公式、5 张表、3 个 inline SVG、2 个 mermaid 流程图、80 行代码）
- 渲染时间：< 10 秒（mmdc 首次 +60-180s，KaTeX 每条 +50ms）
- PDF 大小：~2-5 MB（含 Noto CJK 字体子集）

## 未来优化

- 把 Noto CJK 字体子集化（只嵌用到的字）— PDF 体积减半
- 接入 pandoc 后端作为可选路径（需要 apt 权限）
- 写一个 verifier 脚本（`scripts/verify_pdf.py`）：渲染后跑一遍 PDF 文本提取，验证关键章节/公式/表格存在
- 调研 Typst 作为更现代的替代

## 历史教训

2026-06-23：第一次发 PDF 时里面有 `math-error-block` 红色回退块（latex2mathml 解析失败），但我直接发了。被大哥怼："你自己报告你都有报错，你就直接发给我了，这样行吗"。

修复：
1. 换 KaTeX 路径，根除 MathML 渲染问题
2. 加 `verify_render()`，任何异常 exit 1
3. 写 `references/katex-pdf-pipeline.md` 沉淀调试过程

现在的规则是：`render.py` 只负责生成 HTML/PDF 并把问题显式打印出来，`scripts/verify_pdf.py` 负责最终 hard gate。两者都不能跳过。
