#!/usr/bin/env python3
"""
Markdown → PDF renderer for RethinkFun-style technical reports.

Pipeline:
  0. Extract $$...$$ and $...$ into placeholders BEFORE markdown runs
  1. MD → HTML (markdown library + extra + codehilite)
  2. Replace placeholders with MathJax-rendered SVG (via mathjax-full v3 shell-out)
  3. Recover the outer <svg>, unwrap nested <svg>, and force pixel width/height
  4. Rasterize each formula through cairosvg → retina PNG → base64 data URL
  5. Mermaid ```mermaid blocks → inline SVG (via mmdc if installed)
  6. Apply CSS (report.css)
  7. HTML → PDF (WeasyPrint)
  8. Verify HTML for unresolved math, frontmatter leaks, and fallback spans

Usage:
    python render.py report.md -o report.pdf
    python render.py report.md -o report.pdf --no-mermaid
"""
import argparse
import base64
import re
import subprocess
import sys
import tempfile
import shutil
import struct
from pathlib import Path

import markdown
from weasyprint import HTML


# MathJax SVG → pixel-dimension mapping (v7.19 retina + 1em-per-line)
# v7.19: Two-axis size policy that fixes the persistent blur problem.
#
#   EX_TO_PX = 7.0  — natural x-height conversion (1em body = 14px → 1ex ≈ 7px)
#                     controls SVG's intrinsic width/height attributes.
#   DISPLAY_EX_TO_PX = 12.0  — display formulas render closer to body scale.
#                              One-line blocks stay compact enough for the
#                              page while still preserving sharpness.
#   RETINA = 2  — render each PNG at 2× the target display height. A 20px-tall
#                formula gets a 40px PNG, a 100px-tall formula gets a 200px PNG.
#                WeasyPrint then embeds the high-res PNG inside the smaller
#                <img width=... height=...> slot — no upscaling, no blur.
#
# Earlier versions either (a) rasterized at 7px (matching x-height) and got
# blown up to 20px by the browser → mush, or (b) forced a hard 600px-wide
# cap that stretched short formulas horizontally. v7.19 fixes both: the
# height axis is decoupled from the 1ex natural unit, and a 2× retina pass
# guarantees the rasterizer's resolution always exceeds the display slot.
EX_TO_PX = 7.0
SCALE = 1.0
DISPLAY_EX_TO_PX = 12.0
RETINA = 2

PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"


def _extract_outer_svg(svg_fragment: str) -> str:
    """Recover the first complete MathJax <svg>...</svg> element.

    MathJax may emit nested <svg> or unclosed <g> tags. Parse the fragment with
    lxml recovery when available, then fall back to a simple regex scan.
    """
    if "<svg" not in svg_fragment:
        return svg_fragment

    try:
        from lxml import etree
    except ImportError:
        etree = None

    if etree is not None:
        try:
            parser = etree.XMLParser(recover=True, huge_tree=True)
            root = etree.fromstring(f"<root>{svg_fragment}</root>".encode("utf-8"), parser=parser)
            for node in root.iter():
                tag = getattr(node, "tag", None)
                if isinstance(tag, str) and tag.endswith("svg"):
                    return etree.tostring(node, encoding="unicode")
        except Exception:
            pass

    m = re.search(r"(<svg\b.*</svg>)", svg_fragment, re.DOTALL)
    if m:
        return m.group(1)
    return svg_fragment


def _png_dims(png_bytes: bytes) -> tuple[int, int]:
    """Read PNG width/height with boundary checks."""
    if len(png_bytes) < 24 or not png_bytes.startswith(PNG_SIGNATURE):
        return 0, 0
    try:
        width, height = struct.unpack(">II", png_bytes[16:24])
    except struct.error:
        return 0, 0
    if width <= 0 or height <= 0:
        return 0, 0
    return width, height


def _rasterize_svg(svg: str, output_height: int | None = None) -> tuple[bytes | None, str | None]:
    """Rasterize SVG through cairosvg, returning (png_bytes, error_message)."""
    import cairosvg

    try:
        kwargs = {"bytestring": svg.encode("utf-8")}
        if output_height is not None:
            kwargs["output_height"] = output_height
        return cairosvg.svg2png(**kwargs), None
    except Exception as exc:
        return None, str(exc)


def _force_pixel_dims(svg_str: str, w_ex: float, h_ex: float) -> tuple[str, int, int]:
    """Force-inject width="Wpx" height="Hpx" on the outer <svg> tag.

    Handles three cases:
      a) <svg width="Xex" height="Yex" viewBox="...">  → compute from ex
      b) <svg width="Xex" viewBox="...">  (no height)  → derive height from viewBox aspect
      c) <svg viewBox="...">  (no ex dims at all)      → return as-is, will use PNG native
    """
    m = re.search(r'<svg([^>]*)>', svg_str)
    if not m:
        return svg_str, 0, 0
    attrs = m.group(1)

    # Pull viewBox (for aspect-ratio fallback)
    vb_w, vb_h = 0.0, 0.0
    vbm = re.search(r'viewBox="[\d.\s-]+\s+([\d.]+)\s+([\d.]+)"', svg_str)
    if vbm:
        vb_w, vb_h = float(vbm.group(1)), float(vbm.group(2))

    w_px, h_px = 0, 0
    if w_ex > 0:
        w_px = int(round(w_ex * EX_TO_PX * SCALE))
    if h_ex > 0:
        h_px = int(round(h_ex * EX_TO_PX * SCALE))

    # If width missing but we have viewBox + height, derive width from aspect
    if w_px == 0 and h_px > 0 and vb_w > 0 and vb_h > 0:
        w_px = int(round(h_px * vb_w / vb_h))
    # If height missing but we have viewBox + width, derive height from aspect
    if h_px == 0 and w_px > 0 and vb_w > 0 and vb_h > 0:
        h_px = int(round(w_px * vb_h / vb_w))

    # Strip any existing width="..." / height="..."
    attrs = re.sub(r'\s+width="[^"]*"', '', attrs)
    attrs = re.sub(r'\s+height="[^"]*"', '', attrs)

    if w_px > 0 and h_px > 0:
        new_open = f'<svg{attrs} width="{w_px}" height="{h_px}">'
    elif w_px > 0:
        new_open = f'<svg{attrs} width="{w_px}">'
    else:
        new_open = f'<svg{attrs}>'

    return svg_str[:m.start()] + new_open + svg_str[m.end():], w_px, h_px


def mjx_to_img(svg: str) -> str:
    """Convert <mjx-container><svg>...</svg></mjx-container> to <img> with PNG data URL.

    v7.5: Fix the "75×72 black box" bug.
    Root cause: cairosvg rejected ex units + nested SVG in older paths; we used
    a fragile regex that didn't cover all cases. When conversion failed we
    fell back to the *original* MathJax SVG, which WeasyPrint then rendered
    as a 75×72 black square (ex units unrecognized → collapsed to default).
    Fix:
      1. Force-inject explicit pixel width/height on the <svg> root before
         cairosvg (no more ex units ever reach cairosvg or WeasyPrint).
      2. lxml recovery parser handles unclosed <g> + nested <svg> from \tag{}.
      3. If cairosvg STILL fails: emit a <code> with the raw LaTeX text, NOT
         the original SVG (which would render as a black box).
    """
    import cairosvg
    try:
        from lxml import etree
    except ImportError:
        etree = None

    is_display = 'display="true"' in svg or 'display: true' in svg

    # 1. Extract the outer <svg> from the MathJax container.
    svg_inner = _extract_outer_svg(svg)
    if "<svg" not in svg_inner:
        return svg

    # 2. lxml recover + unwrap nested <svg> nodes.
    if etree is not None:
        try:
            if 'xmlns=' not in svg_inner[:200]:
                svg_inner = svg_inner.replace('<svg', '<svg xmlns="http://www.w3.org/2000/svg"', 1)
            parser = etree.XMLParser(recover=True, huge_tree=True)
            root = etree.fromstring(svg_inner.encode('utf-8'), parser=parser)
            ns = '{http://www.w3.org/2000/svg}'
            for nested in root.findall(f'.//{ns}svg'):
                if nested is root:
                    continue
                parent = nested.getparent()
                if parent is None:
                    continue
                idx = list(parent).index(nested)
                for j, child in enumerate(list(nested)):
                    parent.insert(idx + j, child)
                parent.remove(nested)
            svg_inner = etree.tostring(root, encoding='unicode')
            svg_inner = svg_inner.replace('ns0:', '').replace(':ns0', '')
            svg_inner = re.sub(r'\s+xmlns:ns0="[^"]*"', '', svg_inner)
        except Exception:
            pass

    # 3. Extract width="Xex" / height="Yex" from <svg> attributes.
    # v7.8.3: Also extract from style="...min-width: Xex" — MathJax emits
    # this for aligned / eqnarray environments where it can't determine
    # a clean width/height attribute. Without this, those 10 display
    # formulas hit cairosvg's "SVG size is undefined" error.
    w_ex, h_ex = 0.0, 0.0
    sm = re.search(r'<svg[^>]*\swidth="([\d.]+)ex"', svg_inner)
    if sm:
        w_ex = float(sm.group(1))
    sm = re.search(r'<svg[^>]*\sheight="([\d.]+)ex"', svg_inner)
    if sm:
        h_ex = float(sm.group(1))
    # Fallback: extract from style="...min-width: Xex..." if width attribute
    # was missing. MathJax puts it there for aligned / matrix / case envs.
    if w_ex == 0:
        sm = re.search(r'style="[^"]*min-width:\s*([\d.]+)ex', svg_inner)
        if sm:
            w_ex = float(sm.group(1))
    # Fallback for height too: style="...height: Xex..." (less common)
    if h_ex == 0:
        sm = re.search(r'style="[^"]*height:\s*([\d.]+)ex', svg_inner)
        if sm:
            h_ex = float(sm.group(1))
    # Last resort for aligned envs: read width/height from any inner <svg>
    # that DOES have them (some MathJax outputs nest a sized <svg> inside
    # a positioning <svg>).
    if w_ex == 0 or h_ex == 0:
        for nested_sm in re.finditer(r'<svg[^>]*\swidth="([\d.]+)ex"\s+height="([\d.]+)ex"', svg_inner):
            iw, ih = float(nested_sm.group(1)), float(nested_sm.group(2))
            if iw > w_ex: w_ex = iw
            if ih > h_ex: h_ex = ih
            break  # first one is enough

    # 4. Force-inject pixel width/height.
    s, w_px, h_px = _force_pixel_dims(svg_inner, w_ex, h_ex)

    def _render_with_fallback(heights: list[int | None]) -> tuple[bytes | None, str | None]:
        last_error = None
        for height in heights:
            png, error = _rasterize_svg(s, output_height=height)
            if png is not None:
                return png, None
            last_error = error
        return None, last_error

    if is_display:
        # Target display height: 1em body character visual per line.
        target_h = int(round(h_ex * DISPLAY_EX_TO_PX)) if h_ex > 0 else 20
        target_h = max(20, target_h)
        retina_h = target_h * RETINA
        png_bytes, _error = _render_with_fallback([retina_h, target_h, None])
        if png_bytes is None:
            cls = 'math-block-fallback'
            return (f'<span class="{cls}" '
                    f'style="color:#c00; font-family:monospace; font-size:0.9em;">'
                    f'[公式渲染失败: cairosvg 错误]'
                    f'</span>')
        png_w, png_h = _png_dims(png_bytes)
        if png_w == 0 or png_h == 0:
            png_w, png_h = w_px or 100, h_px or target_h
        b64 = base64.b64encode(png_bytes).decode('ascii')
        data_url = f"data:image/png;base64,{b64}"
        display_w = max(1, int(round(target_h * png_w / max(png_h, 1))))
        return (f'<div class="math-block">'
                f'<img src="{data_url}" alt="formula" '
                f'width="{display_w}" height="{target_h}" '
                f'style="display:block; margin:0.6em auto; max-width:100%; height:auto;"/>'
                f'</div>')
    # Inline: display at 20px height (1em body of 14px font). v7.19: re-render
    # at 2× so the inline PNG is also retina-sharp, matching the display path.
    display_h = 20
    retina_h = display_h * RETINA
    png_bytes, _error = _render_with_fallback([retina_h, display_h, None])
    if png_bytes is None:
        cls = 'math-inline-fallback'
        return (f'<span class="{cls}" '
                f'style="color:#c00; font-family:monospace; font-size:0.9em;">'
                f'[公式渲染失败: cairosvg 错误]'
                f'</span>')
    png_w, png_h = _png_dims(png_bytes)
    if png_w == 0 or png_h == 0:
        png_w, png_h = w_px or 100, h_px or display_h
    b64 = base64.b64encode(png_bytes).decode('ascii')
    data_url = f"data:image/png;base64,{b64}"
    display_w = max(1, int(round(display_h * png_w / max(png_h, 1))))
    return (f'<img src="{data_url}" alt="formula" '
            f'width="{display_w}" height="{display_h}" '
            f'style="vertical-align: middle;"/>')


HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>{title}</title>
{css_link}
</head>
<body>
{body}
</body>
</html>
"""


# ----------------------------------------------------------------------
# MathJax path (Node.js)
# ----------------------------------------------------------------------

# mathjax-full v3 — try several install locations
_MATHJAX_CANDIDATES = [
    "/home/yanyunfei/reports/mathjax-test",  # local install we set up
    "/usr/local/lib/node_modules",
    "/opt/mathjax",
]


def find_mathjax_dir() -> Path:
    """Locate the mathjax-full install directory (containing render_math.js)."""
    for p in _MATHJAX_CANDIDATES:
        path = Path(p)
        if (path / "render_math.js").exists() and (path / "node_modules" / "mathjax-full").exists():
            return path
    raise FileNotFoundError(
        f"mathjax-full not found. Tried {_MATHJAX_CANDIDATES}.\n"
        "Install: mkdir mathjax && cd mathjax && npm init -y && npm install --no-optional mathjax-full@3 && "
        "save the included render_math.js to that dir."
    )


def render_with_mathjax(latex: str, display: bool) -> tuple[str, bool]:
    """Render LaTeX to SVG (wrapped in mjx-container) via MathJax v3.
    Returns (html, success)."""
    mj_dir = find_mathjax_dir()
    args = ["node", "render_math.js"]
    if display:
        args.append("--display")

    try:
        result = subprocess.run(
            args,
            input=latex + "\n",
            capture_output=True,
            text=True,
            timeout=15,
            cwd=str(mj_dir),
        )
        if result.returncode != 0 or not result.stdout.strip():
            err = (result.stderr or "<no stderr>").strip()[:200]
            return (f'<span class="mathjax-error">[MathJax error: {err}]</span>', False)
        return (result.stdout.strip(), True)
    except subprocess.TimeoutExpired:
        return ('<span class="mathjax-error">[MathJax timeout]</span>', False)
    except Exception as e:
        return (f'<span class="mathjax-error">[MathJax exception: {e}]</span>', False)


# ----------------------------------------------------------------------
# Math extraction (BEFORE markdown)
# ----------------------------------------------------------------------

def extract_math_placeholders(md_text: str):
    """Replace $$...$$ (block) and $...$ (inline) with unique placeholders."""
    placeholders = []

    def stash(latex: str, display: bool):
        idx = len(placeholders)
        ph = f"\x00MATH{idx:04d}\x00"
        placeholders.append((ph, latex, display))
        return ph

    def block_sub(m):
        return stash(m.group(1).strip(), True)

    text = re.sub(r'\$\$(.+?)\$\$', block_sub, md_text, flags=re.DOTALL)

    def inline_sub(m):
        return stash(m.group(1).strip(), False)

    text = re.sub(r'(?<!\\)\$([^$\n]+?)\$(?!\$)', inline_sub, text)
    return text, placeholders


def restore_math_in_html(html: str, placeholders) -> tuple[str, list]:
    """Replace each placeholder with MathJax SVG (inline-embedded).

    v7.3: Direct SVG embed (WeasyPrint handles MathJax SVG natively).
    Earlier versions tried cairosvg → PNG → base64 <img>, but cairosvg
    rejects nested SVG, ex units, %, and unclosed <g> tags — too many
    edge cases for too little benefit. Going back to clean inline SVG.
    """
    failed = []
    for ph, latex, display in placeholders:
        rendered, ok = render_with_mathjax(latex, display)
        if not ok:
            failed.append(ph)
            continue
        try:
            img_html = mjx_to_img(rendered)
        except Exception as e:
            failed.append(ph)
            img_html = f'<span class="mathjax-error">[cairosvg error: {e}]</span>'
        html = html.replace(ph, img_html)
    return html, failed


# ----------------------------------------------------------------------
# Mermaid rendering (optional)
# ----------------------------------------------------------------------

def render_mermaid_block(mermaid_code: str, work_dir: Path) -> str:
    mmdc_input = work_dir / "input.mmd"
    mmdc_output = work_dir / "output.svg"
    mmdc_input.write_text(mermaid_code)

    try:
        result = subprocess.run(
            ["npx", "-y", "@mermaid-js/mermaid-cli", "-p", "/dev/stdin",
             "-o", str(mmdc_output), "-b", "transparent"],
            input=mermaid_code,
            capture_output=True,
            text=True,
            timeout=180,
        )
        if result.returncode != 0:
            raise RuntimeError(f"mmdc failed: {result.stderr[:300]}")
        svg = mmdc_output.read_text()
        svg = re.sub(r'<\?xml[^>]+\?>\s*', '', svg)
        return f'<div class="mermaid-diagram">{svg}</div>'
    except (subprocess.TimeoutExpired, subprocess.CalledProcessError,
            FileNotFoundError, RuntimeError):
        escaped = (mermaid_code.replace('&', '&amp;')
                            .replace('<', '&lt;')
                            .replace('>', '&gt;'))
        return (f'<div class="mermaid-fallback">'
                f'<div class="mermaid-fallback-label">[mermaid diagram — mmdc unavailable]</div>'
                f'<pre><code>{escaped}</code></pre></div>')


def replace_mermaid_in_html(html: str, work_dir: Path) -> str:
    pattern = re.compile(
        r'<pre><code class="language-mermaid">(.*?)</code></pre>',
        re.DOTALL,
    )

    def replace(m):
        code = m.group(1)
        code = (code.replace('&lt;', '<').replace('&gt;', '>')
                     .replace('&amp;', '&').replace('&quot;', '"'))
        return render_mermaid_block(code, work_dir)

    return pattern.sub(replace, html)


# ----------------------------------------------------------------------
# Top-level pipeline
# ----------------------------------------------------------------------

def strip_yaml_frontmatter(md_text: str) -> str:
    """Strip YAML frontmatter (--- block at top of file).

    The Python `markdown` library doesn't natively parse YAML frontmatter, so
    `title:` / `subtitle:` / `author:` / `date:` lines would otherwise appear
    as raw text in the rendered output. We detect the leading `---` block and
    remove it before markdown conversion.
    """
    if not md_text.startswith('---'):
        return md_text
    # Match leading `---` block (the closing `---` on its own line)
    m = re.match(r'^---\s*\n.*?\n---\s*\n', md_text, flags=re.DOTALL)
    if m:
        return md_text[m.end():]
    return md_text


def md_to_html(md_text: str, templates_dir: Path, title: str = "Report",
               enable_mermaid: bool = True) -> tuple[str, list]:
    # v7.2.1: Strip YAML frontmatter so it doesn't leak as raw text
    md_text = strip_yaml_frontmatter(md_text)
    md_safe, math_placeholders = extract_math_placeholders(md_text)

    md = markdown.Markdown(
        extensions=[
            'extra',
            'codehilite',
            'toc',
            'sane_lists',
            'smarty',
        ],
        extension_configs={
            'codehilite': {'css_class': 'codehilite', 'guess_lang': False},
            'toc': {'permalink': False},
        },
    )
    body = md.convert(md_safe)
    body, failed_math = restore_math_in_html(body, math_placeholders)

    if enable_mermaid:
        work_dir = Path(tempfile.mkdtemp(prefix="rethinkfun_"))
        try:
            body = replace_mermaid_in_html(body, work_dir)
        finally:
            shutil.rmtree(work_dir, ignore_errors=True)

    report_css = templates_dir / "report.css"
    css_inline = ""
    if report_css.exists():
        css_inline = f"<style>{report_css.read_text(encoding='utf-8')}</style>"

    return HTML_TEMPLATE.format(title=title, css_link=css_inline, body=body), failed_math


def html_to_pdf(html_str: str, output_pdf: Path, base_url: Path):
    HTML(string=html_str, base_url=str(base_url)).write_pdf(str(output_pdf))


def verify_render(html_path: Path) -> list:
    """Sanity-check rendered HTML for problems before PDF delivery."""
    html = html_path.read_text(encoding="utf-8")
    issues = []

    body_only = re.sub(r'<style>.*?</style>', '', html, flags=re.DOTALL)

    # 1. MathJax / cairosvg error spans in body?
    for cls in ("mathjax-error", "math-block-fallback", "math-inline-fallback"):
        count = body_only.count(cls)
        if count:
            issues.append(f"❌ render FAILED: {count} × {cls} in body")

    # 2. Unresolved math placeholders?
    leftover = re.findall(r'\x00MATH\d{4}\x00', html)
    if leftover:
        issues.append(f"❌ unresolved math placeholders: {len(leftover)}")

    # 3. Raw $...$ left in body?
    body_only_no_pre = re.sub(r'<pre>.*?</pre>', '', body_only, flags=re.DOTALL)
    raw_dollar = re.findall(r'(?<!\\)\$[^$\n]+\$(?!\$)', body_only_no_pre)
    if raw_dollar:
        issues.append(f"❌ raw $...$ left in body: {len(raw_dollar)} (math not converted)")

    # 4. <em> leaked into math?
    em_in_math = re.findall(r'math-(block|inline)[^<]*<em>', html)
    if em_in_math:
        issues.append(f"❌ <em> leaked into math: {len(em_in_math)} occurrences")

    # 4b. v7.2.1: YAML frontmatter leaked as raw text?
    # Detect "title:" / "subtitle:" / "author:" / "date:" in the body (excluding CSS).
    fm_lines = re.findall(r'>\s*(title|subtitle|author|date):\s*[^<]*<', html)
    if fm_lines:
        issues.append(f"❌ YAML frontmatter leaked: {len(fm_lines)} raw metadata lines in body")

    # 5. Code blocks highlight?
    body_only_pre = re.findall(r'<pre>.*?</pre>', body_only, flags=re.DOTALL)
    if body_only_pre:
        pygments_class_count = sum(1 for p in body_only_pre if 'class="k"' in p or 'class="nf"' in p)
        if pygments_class_count == 0:
            issues.append("⚠️  code blocks present but no Pygments syntax highlight (span.k/.nf missing)")

    # 6. v7.4: PNG embed via cairosvg — verify rendered MathJax output exists
    math_img_count = len(re.findall(r'<img[^>]+src="data:image/png;base64,', body_only))
    svg_count = len(re.findall(r'<svg[^>]+class="mjx-(?:display|inline)"', body_only))
    if math_img_count == 0 and svg_count == 0:
        issues.append("⚠️  no MathJax output (formulas may be empty)")

    return issues

# v7.2.0 — SVG → PNG via cairosvg (WeasyPrint SVG compatibility fix)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("input_md", type=Path)
    ap.add_argument("-o", "--output", type=Path, required=True)
    ap.add_argument("--title", type=str, default=None)
    ap.add_argument("--no-mermaid", action="store_true")
    args = ap.parse_args()

    md_text = args.input_md.read_text(encoding="utf-8")
    title = args.title or args.input_md.stem

    script_dir = Path(__file__).resolve().parent
    # templates is at <skill>/templates — i.e. one level up from scripts/
    templates_dir = script_dir.parent / "templates"
    print(f"[*] Input:    {args.input_md}")
    print(f"[*] Output:   {args.output}")
    print(f"[*] Templates: {templates_dir}")

    html, failed_math = md_to_html(
        md_text, templates_dir=templates_dir, title=title,
        enable_mermaid=not args.no_mermaid,
    )

    debug_html = args.output.with_suffix(".html")
    debug_html.write_text(html, encoding="utf-8")
    print(f"[*] HTML:     {debug_html}")

    issues = verify_render(debug_html)
    if failed_math:
        issues.append(f"❌ MathJax render FAILED: {len(failed_math)} placeholder(s) not converted")
    if issues:
        print()
        print("=" * 60)
        print("RENDER VERIFICATION — issues detected (PDF still generated)")
        print("=" * 60)
        for i in issues:
            print(f"  {i}")
        print("=" * 60)
        # The HTML debug file is still emitted so verify_pdf.py can make the
        # final ship/no-ship decision. render.py itself does not abort.

    html_to_pdf(html, args.output, base_url=templates_dir)
    size_kb = args.output.stat().st_size / 1024
    print(f"[✓] PDF rendered: {args.output}  ({size_kb:.1f} KB)")


if __name__ == "__main__":
    main()
