#!/usr/bin/env python3
"""
Post-render PDF smoke test for RethinkFun-style reports.

Catches the rendering regressions that verify_render() in render.py misses
(because verify_render only inspects the HTML, not the actual rendered PDF).

The "75×72 black box" smoking gun (v7.4 → v7.5 bug):
  When cairosvg failed and we fell back to the original MathJax SVG,
  WeasyPrint rendered `ex` units as 0×0 → a tiny solid black square.
  Every failed formula became a 117-byte 75×72 (or 57×102 / 75×75) PNG
  repeated dozens of times. The HTML looked fine; the PDF was garbage.

The "formula too big" smoking gun (v7.5 → v7.7 bug, found 2026-06-24):
  Inline formula PNG physical height > body line-height → every inline
  formula balloons the row to 2× text-row height. The PDF looks fine
  structurally (verify_render passes) but the typography is broken.
  Detection: pdftoppm + PIL row_ink analysis — text rows avg 13-15px,
  inline math rows should be ≤ 1.5× that. If avg_inline_row > 1.7×
  avg_text_row → SCALE too high or display size not pinned.

The "formula overflows page" smoking gun (v7.7 fix):
  Display formulas with width > A4 content width (~793px @ A4 with 1.8cm
  margins) → either get clipped or pushed off the page. Detection:
  pdfimages -list sizes — any image with w > 793 on display-math pages.

Run after every render.py invocation, BEFORE sending the PDF to the user:

    python3 verify_pdf.py path/to/report.pdf

Exit code 0 = pass, 1 = at least one check failed. Use this as a gate:

    python3 render.py report.md -o report.pdf \\
      && python3 verify_pdf.py report.pdf \\
      && echo "OK to ship" \\
      || echo "DO NOT SHIP"

It also accepts the .html sibling to check HTML-side issues (MathJax error
attributes, unresolved placeholders, raw $...$ leakage).

For deep font-size / overflow debugging (when smoke test passes but user
says "looks wrong"), see references/font-size-debugging.md for the
pdftoppm + PIL pixel-analysis workflow.
"""
import argparse
import re
import subprocess
import sys
from pathlib import Path


# ----------------------------------------------------------------------
# Image-content analysis: detect the "75×72 black box" pattern
# ----------------------------------------------------------------------

def extract_pdf_images(pdf_path: Path, out_dir: Path) -> list[Path]:
    """Run pdfimages -png and return list of extracted PNG paths."""
    out_dir.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        ["pdfimages", "-png", str(pdf_path), str(out_dir / "img")],
        check=True, capture_output=True,
    )
    return sorted(out_dir.glob("img-*.png"))


def analyze_image(png_path: Path) -> dict:
    """Compute ink % and dimensions for one PNG. PIL only, no vision.

    v7.23 note: `pdfimages -png` strips the alpha channel from PDF
    embedded images, so PNGs come out as RGB with black "background"
    (where the PDF smask had transparent). Pure-black pixel counting on
    those RGB PNGs is therefore meaningless — they look 100% black even
    when the original formula was perfectly fine. We keep `pure_black_pct`
    for RGBA PNGs only and never use it for black-box detection.

    Real black-box detection relies on the legacy cairosvg-fallback-size
    signature (see BLACK_BOX_SIZES below).
    """
    try:
        from PIL import Image
    except ImportError:
        return {"path": png_path, "error": "PIL not installed"}

    im = Image.open(png_path).convert("RGBA")
    px = list(im.getdata())
    total = len(px)
    # Opaque ink: alpha > 10 AND any channel < 240
    ink = sum(
        1 for p in px
        if p[3] > 10 and (p[0] < 240 or p[1] < 240 or p[2] < 240)
    )
    pure_black = 0
    if im.mode == "RGBA":
        # Only count pure-black on RGBA PNGs — RGB PNGs from `pdfimages`
        # are missing transparency so their black pixels are not real ink.
        pure_black = sum(
            1 for p in px
            if p[3] > 10 and p[0] <= 10 and p[1] <= 10 and p[2] <= 10
        )
    return {
        "path": png_path,
        "size": im.size,
        "bytes": png_path.stat().st_size,
        "ink_pct": 100.0 * ink / total if total else 0,
        "pure_black_pct": 100.0 * pure_black / total if total else 0,
        "mode": im.mode,
    }


# v7.4 fallback signatures: cairosvg's default PNG when given an SVG with
# `ex` units it can't resolve. Sizes cluster around 75×72, 57×102, 75×75.
# Real formulas are always >100px wide.
BLACK_BOX_SIZES = {(75, 72), (75, 75), (57, 102), (57, 75), (162, 99)}


def detect_black_boxes(images: list[dict]) -> list[dict]:
    """Return images matching the black-box smoking-gun signature.

    Detection only uses cairosvg-fallback-size matching (75×72, 57×102,
    etc.) — those are the unique dimensions cairosvg produces when given
    an SVG with `ex` units it can't resolve. Pure-black pixel counting
    is unreliable because `pdfimages -png` strips alpha channels.
    """
    suspects = []
    for img in images:
        if "size" not in img:
            continue
        w, h = img["size"]
        if (w, h) in BLACK_BOX_SIZES and img["bytes"] < 1500:
            suspects.append({**img, "reason": "cairosvg-fallback-size"})
    return suspects


# ----------------------------------------------------------------------
# PDF structural checks (cheap, run first)
# ----------------------------------------------------------------------

def check_pdf_metadata(pdf_path: Path, source_path: Path | None = None) -> list[str]:
    """Verify the PDF exists, is newer than the HTML sibling, and has pages > 0."""
    issues = []
    if not pdf_path.exists():
        return [f"❌ PDF does not exist: {pdf_path}"]
    if source_path is not None and source_path.exists():
        try:
            if pdf_path.stat().st_mtime < source_path.stat().st_mtime:
                issues.append(
                    f"❌ PDF mtime older than {source_path.name} "
                    f"(render may have failed or reused an old PDF)"
                )
        except OSError as exc:
            issues.append(f"❌ stat failed while checking freshness: {exc}")
    try:
        info = subprocess.run(
            ["pdfinfo", str(pdf_path)], capture_output=True, text=True,
        ).stdout
    except FileNotFoundError as exc:
        return [f"❌ pdfinfo not available: {exc}"]
    if "Pages:" not in info:
        issues.append("❌ pdfinfo returned no Pages field (corrupt PDF?)")
    else:
        pages = int(re.search(r"Pages:\s+(\d+)", info).group(1))
        if pages == 0:
            issues.append("❌ PDF has 0 pages (render produced nothing)")
    return issues


def check_pdf_text_leaks(pdf_path: Path) -> list[str]:
    """Check for YAML frontmatter leak + CSS footer leak."""
    issues = []
    try:
        p1 = subprocess.run(
            ["pdftotext", "-f", "1", "-l", "1", str(pdf_path), "-"],
            capture_output=True, text=True,
        ).stdout
    except FileNotFoundError as exc:
        return [f"❌ pdftotext not available: {exc}"]
    for keyword in ("title:", "subtitle:", "author:", "date:"):
        if re.search(rf"^\s*{keyword}\s+\S", p1, re.MULTILINE):
            issues.append(
                f"❌ YAML frontmatter leak: '{keyword}' found on page 1 "
                f"(python-markdown doesn't parse YAML — must strip in render.py)"
            )
            break

    tail = "\n".join(p1.strip().splitlines()[-3:])
    if "RethinkFun" in tail or re.search(r"\d+\s*/\s*\d+", tail):
        issues.append(
            f"❌ CSS footer leak on page 1: tail contains '{tail[:80]}' "
            f"(remove @bottom-left/@bottom-right from @page)"
        )

    if re.search(r"\$\$[^\$]", p1):
        issues.append("❌ raw $$...$$ on page 1 (block math not converted)")

    return issues


# ----------------------------------------------------------------------
# HTML-side checks (data-mjx-error attribute etc.)
# ----------------------------------------------------------------------

HTML_ERROR_PATTERNS = [
    (r'data-mjx-error="[^"]+"', "MathJax v3 silent error (data-mjx-error attr)"),
    (r'<merror[^>]*>', "MathJax <merror> tag (formula failed to render)"),
    (r'class="mathjax-error"', "mathjax-error CSS class (visible fallback block)"),
    (r'class="math-(?:block|inline)-fallback"', "cairosvg fallback span"),
    (r'\x00MATH\d{4}\x00', "Unresolved math placeholder (extraction failed)"),
]


def check_html(html_path: Path) -> list[str]:
    """Check the .html sibling for MathJax errors and placeholder leaks."""
    if not html_path.exists():
        return []
    issues = []
    html = html_path.read_text(encoding="utf-8")
    body = re.sub(r"<style>.*?</style>", "", html, flags=re.DOTALL)

    for pat, desc in HTML_ERROR_PATTERNS:
        count = len(re.findall(pat, body))
        if count:
            issues.append(f"❌ HTML: {count} × {desc}")

    body_no_pre = re.sub(r"<pre>.*?</pre>", "", body, flags=re.DOTALL)
    raw = re.findall(r"(?<!\\)\$[^$\n]+?\$(?!\$)", body_no_pre)
    if raw:
        issues.append(f"❌ HTML: {len(raw)} raw $...$ not converted")

    return issues


# ----------------------------------------------------------------------
# Image-content checks (the deep one — catches black boxes)
# ----------------------------------------------------------------------

def check_pdf_images(pdf_path: Path, work_dir: Path) -> tuple[list[str], dict]:
    """Extract images and analyze for black-box regression."""
    try:
        images = extract_pdf_images(pdf_path, work_dir)
    except (subprocess.CalledProcessError, FileNotFoundError) as exc:
        return [f"❌ pdfimages failed: {exc}"], {}
    if not images:
        return ["⚠️  PDF contains 0 embedded images (formulas/mermaid likely missing)"], {}

    analyzed = [analyze_image(p) for p in images]
    suspects = detect_black_boxes(analyzed)

    issues = []
    stats = {
        "total_images": len(analyzed),
        "black_boxes": len(suspects),
        "smallest_real_formula": None,
    }

    real = [
        img for img in analyzed
        if img["size"][0] >= 100 and 5 <= img["ink_pct"] <= 95
    ]
    if real:
        stats["smallest_real_formula"] = min(real, key=lambda x: x["size"][0])["size"]

    if len(suspects) >= 3:
        unique_sizes = sorted({s["size"] for s in suspects})
        issues.append(
            f"❌ {len(suspects)} black-box images detected "
            f"(sizes: {unique_sizes}). This is the v7.4→v7.5 regression: "
            f"cairosvg failed and WeasyPrint rendered ex-unit SVGs as "
            f"75×72 solid squares. Check mjx_to_img in render.py."
        )
    elif suspects:
        issues.append(
            f"⚠️  {len(suspects)} suspicious small images "
            f"(sizes: {[s['size'] for s in suspects]})"
        )

    return issues, stats


# ----------------------------------------------------------------------
# v7.7: Page-level rendering audit (row-height + overflow)
# ----------------------------------------------------------------------

# A4 at 96dpi = 793 CSS px wide with default 1.8cm margins.
A4_CONTENT_WIDTH_PX = 793


def _audit_page_image(png_path: Path) -> dict:
    """Analyze one rendered page PNG: row heights + ink density.

    Used by check_row_height_audit() to detect "inline formula too tall"
    (where every inline math row balloons to 2× text-row height).
    """
    try:
        from PIL import Image
        import numpy as np
    except ImportError:
        return {"path": png_path, "error": "PIL or numpy not installed"}

    im = Image.open(png_path).convert("L")
    arr = np.array(im)
    h, w = arr.shape

    row_ink = (arr < 128).sum(axis=1)

    segments = []
    in_seg = False
    start = 0
    for y, has_ink in enumerate(row_ink > 5):
        if has_ink and not in_seg:
            in_seg = True
            start = y
        elif not has_ink and in_seg:
            in_seg = False
            segments.append((start, y, y - start))
    if in_seg:
        segments.append((start, h, h - start))

    # Empirically tuned for 10.5pt body @ 100dpi render:
    #   text rows    : 8-18 px (avg ~14)
    #   inline math  : 14-28 px (avg ~17 if pinned, 22-32 if SCALE too high)
    #   display math : 29-100 px
    text = [s for s in segments if 8 <= s[2] <= 18]
    inline = [s for s in segments if 19 <= s[2] <= 32]
    display = [s for s in segments if 33 <= s[2] <= 100]

    return {
        "path": png_path,
        "size": (w, h),
        "text_rows": len(text),
        "text_avg_h": sum(s[2] for s in text) / max(1, len(text)),
        "inline_rows": len(inline),
        "inline_avg_h": sum(s[2] for s in inline) / max(1, len(inline)) if inline else 0,
        "display_rows": len(display),
        "display_avg_h": sum(s[2] for s in display) / max(1, len(display)) if display else 0,
    }


def check_row_height_audit(pdf_path: Path, work_dir: Path,
                           pages_to_audit: int = 5) -> list[str]:
    """v7.7: Detect "inline formula too tall" by sampling rendered pages.

    Renders first N pages as PNG, runs row_ink analysis. If avg inline
    row height > 1.7× avg text row height, formulas are ballooning rows
    (SCALE too high, or display size not pinned in HTML attributes).
    """
    issues = []
    audit_dir = work_dir / "audit_pages"
    audit_dir.mkdir(parents=True, exist_ok=True)

    info = subprocess.run(
        ["pdfinfo", str(pdf_path)], capture_output=True, text=True
    ).stdout
    m = re.search(r"Pages:\s+(\d+)", info)
    total_pages = int(m.group(1)) if m else 0
    n = min(pages_to_audit, total_pages)
    if n == 0:
        return issues

    try:
        for p in range(1, n + 1):
            subprocess.run(
                ["pdftoppm", "-r", "100", "-f", str(p), "-l", str(p),
                 str(pdf_path), str(audit_dir / f"p{p}"), "-png"],
                check=False, capture_output=True,
            )
    except FileNotFoundError as exc:
        return [f"❌ pdftoppm not available: {exc}"]

    audits = []
    for p in range(1, n + 1):
        pg_path = audit_dir / f"p{p}-{p:02d}.png"
        if pg_path.exists():
            audits.append(_audit_page_image(pg_path))

    if not audits:
        return issues

    text_avgs = [a["text_avg_h"] for a in audits if a["text_rows"] >= 3]
    inline_avgs = [a["inline_avg_h"] for a in audits if a["inline_rows"] >= 1]
    if not text_avgs or not inline_avgs:
        return issues

    avg_text = sum(text_avgs) / len(text_avgs)
    avg_inline = sum(inline_avgs) / len(inline_avgs)
    ratio = avg_inline / avg_text if avg_text else 0

    print(f"  [row-height] text_avg={avg_text:.1f}px  inline_avg={avg_inline:.1f}px  ratio={ratio:.2f}")

    # LaTeX convention: inline math is 1.0-1.2em; body ~1em + line-height.
    # Ratio > 1.7 → formulas visually "too big" (the v7.5/v7.6 bug).
    if ratio > 1.7:
        issues.append(
            f"❌ Inline formula row-height too tall: avg={avg_inline:.1f}px "
            f"is {ratio:.1f}× text row height ({avg_text:.1f}px). "
            f"SCALE too high or display size not pinned. "
            f"See references/font-size-debugging.md."
        )

    return issues


def check_display_formula_overflow(pdf_path: Path, html_path: Path | None = None) -> list[str]:
    """Detect display formulas that can overflow if max-width scaling regresses."""
    issues = []
    if html_path is not None and html_path.exists():
        html = html_path.read_text(encoding="utf-8")
        overflow = []
        pattern = re.compile(
            r'<div class="math-block">\s*<img[^>]*alt="formula"[^>]*width="(\d+)"[^>]*height="(\d+)"[^>]*style="([^"]*)"',
            re.DOTALL,
        )
        for idx, m in enumerate(pattern.finditer(html), 1):
            w_img = int(m.group(1))
            h_img = int(m.group(2))
            style = m.group(3).replace(" ", "")
            if w_img > A4_CONTENT_WIDTH_PX and h_img > 15 and "max-width:100%;" not in style:
                overflow.append((idx, w_img, h_img))
        if overflow:
            issues.append(
                f"❌ {len(overflow)} display formula(s) can overflow if CSS max-width regresses "
                f"({A4_CONTENT_WIDTH_PX}px): {overflow[:5]}. "
                f"Keep max-width:100% on .math-block img in report.css."
            )
        return issues

    try:
        out = subprocess.run(
            ["pdfimages", "-list", str(pdf_path)], capture_output=True, text=True
        ).stdout
    except FileNotFoundError as exc:
        return [f"❌ pdfimages not available: {exc}"]

    overflow = []
    for line in out.split("\n")[2:]:
        parts = line.split()
        if len(parts) < 5 or parts[2] != "image":
            continue
        try:
            page = int(parts[0])
            w_img = int(parts[3])
            h_img = int(parts[4])
        except (ValueError, IndexError):
            continue
        if w_img > A4_CONTENT_WIDTH_PX and h_img > 15:
            overflow.append((page, w_img, h_img))

    if overflow:
        issues.append(
            f"❌ {len(overflow)} display formula(s) exceed A4 content width "
            f"({A4_CONTENT_WIDTH_PX}px): {overflow[:5]}. "
            f"Keep max-width:100% on .math-block img in report.css."
        )

    return issues


# ----------------------------------------------------------------------
# Entry point
# ----------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("pdf", type=Path, help="PDF to verify")
    ap.add_argument("--html", type=Path, default=None,
                    help="Optional .html sibling to also check (default: auto-detect)")
    ap.add_argument("--work-dir", type=Path, default=Path("/tmp/verify_pdf_work"),
                    help="Where to extract images (default: /tmp/verify_pdf_work)")
    ap.add_argument("--no-extract", action="store_true",
                    help="Skip the slow image extraction (fast structural check only)")
    ap.add_argument("--visual-audit", type=int, default=5, metavar="N",
                    help="Audit first N pages for row-height + overflow "
                         "(default: 5, set 0 to skip)")
    args = ap.parse_args()

    pdf_path = args.pdf.resolve()
    html_path = args.html or pdf_path.with_suffix(".html")

    print(f"[*] Verifying: {pdf_path}")
    print(f"[*] HTML sibling: {html_path}")
    print()

    all_issues = []
    all_issues.extend(check_pdf_metadata(pdf_path, html_path))
    all_issues.extend(check_pdf_text_leaks(pdf_path))
    all_issues.extend(check_html(html_path))

    stats = {}
    if not args.no_extract:
        image_issues, stats = check_pdf_images(pdf_path, args.work_dir)
        all_issues.extend(image_issues)

    if args.visual_audit > 0:
        print(f"[*] Visual audit (row-height + overflow, first {args.visual_audit} pages)...")
        all_issues.extend(check_row_height_audit(pdf_path, args.work_dir,
                                                 pages_to_audit=args.visual_audit))
        all_issues.extend(check_display_formula_overflow(pdf_path, html_path))

    print("=" * 60)
    if all_issues:
        print(f"❌ FAILED — {len(all_issues)} issue(s):")
        for issue in all_issues:
            print(f"  {issue}")
    else:
        print("✅ PASSED — safe to ship")
    print("=" * 60)
    if stats:
        print(f"  total images:   {stats.get('total_images', 0)}")
        print(f"  black boxes:    {stats.get('black_boxes', 0)}")
        print(f"  smallest real:  {stats.get('smallest_real_formula')}")
    print()

    sys.exit(1 if any("❌" in i for i in all_issues) else 0)


if __name__ == "__main__":
    main()
