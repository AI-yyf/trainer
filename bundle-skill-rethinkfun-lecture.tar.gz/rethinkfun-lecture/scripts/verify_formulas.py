#!/usr/bin/env python3
"""
verify_formulas.py — 公式 retina + char-visual 硬验证（v7.19 强制）

自动跑通 formula 渲染验证三件事：
  1. 每个 <img> 内的 base64 PNG 真实像素尺寸（PNG header 16-24 字节解码）
  2. retina ratio = PNG_h / img_height（期望 ≥ 2.0）
  3. char visual per line = 0.7 × img_height / h_ex（期望 ≈ 14.0px = 1em body）

退出码：
  0  = 全部通过（safe to ship）
  1  = 有公式不达标（看 issues 输出）

用法：
  python3 scripts/verify_formulas.py path/to/report.html
  python3 scripts/verify_formulas.py path/to/report.html --strict   # 任何非 2.0 retina 算 fail
  python3 scripts/verify_formulas.py path/to/report.html --json    # JSON 输出（CI 友好）
"""
import argparse
import base64
import json
import re
import struct
import sys
from pathlib import Path


# v7.19 policy: display formulas use h_ex × DISPLAY_EX_TO_PX for img height,
# where DISPLAY_EX_TO_PX = 20.0. So h_ex = img_height / 20.
DISPLAY_EX_TO_PX = 20.0
EXPECTED_CHAR_PER_LINE = 14.0  # 1em body of 14px font
RETINA_MIN = 2.0
CHAR_TOLERANCE = 0.5  # ±0.5px tolerance for char visual


def png_dimensions(b64_prefix: str) -> tuple[int, int]:
    """Decode PNG width/height from first ~24 bytes of base64 PNG."""
    png = base64.b64decode(b64_prefix[:100])
    w = struct.unpack('>I', png[16:20])[0]
    h = struct.unpack('>I', png[20:24])[0]
    return w, h


def parse_html(html: str) -> tuple[list, list]:
    """Return (display_formulas, inline_formulas) as lists of dicts."""
    display_pat = (
        r'<div class="math-block">\s*'
        r'<img src="data:image/png;base64,([^"]+)" alt="formula" '
        r'width="(\d+)" height="(\d+)"'
    )
    inline_pat = (
        r'<img src="data:image/png;base64,([^"]+)" alt="formula" '
        r'width="(\d+)" height="(\d+)" style="vertical-align'
    )

    display = []
    for m in re.finditer(display_pat, html):
        b64 = m.group(1)
        w, h = int(m.group(2)), int(m.group(3))
        png_w, png_h = png_dimensions(b64)
        h_ex = h / DISPLAY_EX_TO_PX
        char_per_line = (0.7 * h / h_ex) if h_ex > 0 else 0
        retina = png_h / h if h > 0 else 0
        display.append({
            'img_w': w, 'img_h': h,
            'png_w': png_w, 'png_h': png_h,
            'h_ex': round(h_ex, 3),
            'retina': round(retina, 2),
            'char_per_line': round(char_per_line, 2),
        })

    inline = []
    for m in re.finditer(inline_pat, html):
        b64 = m.group(1)
        w, h = int(m.group(2)), int(m.group(3))
        png_w, png_h = png_dimensions(b64)
        retina = png_h / h if h > 0 else 0
        char_visual = round(0.7 * h, 2)
        inline.append({
            'img_w': w, 'img_h': h,
            'png_w': png_w, 'png_h': png_h,
            'retina': round(retina, 2),
            'char_visual': char_visual,
        })

    return display, inline


def verify(html_path: Path, strict: bool = False) -> tuple[int, list, list, list]:
    """Returns (exit_code, display, inline, issues)."""
    if not html_path.exists():
        return 1, [], [], [f"❌ file not found: {html_path}"]

    html = html_path.read_text(encoding='utf-8')
    display, inline = parse_html(html)
    issues = []

    if not display and not inline:
        return 1, display, inline, ["❌ no MathJax output found in HTML (no <img alt='formula'>)"]

    # ---- Display checks ----
    for i, d in enumerate(display, 1):
        if d['retina'] < RETINA_MIN:
            issues.append(
                f"❌ display #{i}: img_h={d['img_h']}px, PNG_h={d['png_h']}px, "
                f"retina={d['retina']} (need ≥ {RETINA_MIN})"
            )
        if abs(d['char_per_line'] - EXPECTED_CHAR_PER_LINE) > CHAR_TOLERANCE:
            issues.append(
                f"❌ display #{i}: char_per_line={d['char_per_line']}px "
                f"(expect {EXPECTED_CHAR_PER_LINE}±{CHAR_TOLERANCE})"
            )
        elif strict and d['retina'] != 2.0:
            issues.append(
                f"⚠️  display #{i}: retina={d['retina']} (strict mode: expect exactly 2.0)"
            )

    # ---- Inline checks ----
    for i, im in enumerate(inline, 1):
        if im['retina'] < RETINA_MIN:
            issues.append(
                f"❌ inline #{i}: img_h={im['img_h']}px, PNG_h={im['png_h']}px, "
                f"retina={im['retina']} (need ≥ {RETINA_MIN})"
            )
        elif strict and im['retina'] != 2.0:
            issues.append(
                f"⚠️  inline #{i}: retina={im['retina']} (strict mode: expect exactly 2.0)"
            )

    exit_code = 1 if issues else 0
    return exit_code, display, inline, issues


def format_report(display, inline, issues, html_path) -> str:
    out = []
    out.append(f"📄 HTML:        {html_path}")
    out.append(f"📐 Display:     {len(display)} formulas (DISPLAY_EX_TO_PX={DISPLAY_EX_TO_PX}, h_ex=img_h/20)")
    out.append(f"📐 Inline:      {len(inline)} formulas (display_h=20px = 1em body)")
    out.append("")

    if display:
        out.append("=== DISPLAY (per-line char visual = 0.7 × img_h / h_ex) ===")
        out.append(f"{'#':<4} {'img WxH':<12} {'PNG WxH':<13} {'retina':<7} {'h_ex':<6} {'char/line':<10}")
        for i, d in enumerate(display, 1):
            out.append(
                f"{i:<4} {d['img_w']}x{d['img_h']:<8} {d['png_w']}x{d['png_h']:<10} "
                f"{d['retina']:<7} {d['h_ex']:<6.2f} {d['char_per_line']}px"
            )
        out.append("")

    if inline:
        all_2x = all(im['retina'] == 2.0 for im in inline)
        all_14px = all(im['char_visual'] == 14.0 for im in inline)
        out.append("=== INLINE (char visual = 0.7 × 20 = 14.0px = 1em body) ===")
        out.append(f"Total: {len(inline)}  |  2× retina: {sum(1 for im in inline if im['retina']==2.0)}  |  "
                   f"1× retina: {sum(1 for im in inline if im['retina']<2.0)}")
        out.append(f"All char_visual=14.0px: {'✅' if all_14px else '❌'}")
        out.append(f"All retina=2.0:         {'✅' if all_2x else '❌'}")

    out.append("")
    if issues:
        out.append(f"❌ {len(issues)} issue(s) found:")
        for i in issues:
            out.append(f"  {i}")
    else:
        out.append("✅ ALL FORMULAS PASS retina=2.0 + char=14px check")
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("html", type=Path, help="Path to render.py output HTML")
    ap.add_argument("--strict", action="store_true",
                    help="Strict: any non-2.0 retina is a warning (default: only <2.0 fails)")
    ap.add_argument("--json", action="store_true", help="JSON output (CI-friendly)")
    args = ap.parse_args()

    exit_code, display, inline, issues = verify(args.html, strict=args.strict)

    if args.json:
        print(json.dumps({
            'html': str(args.html),
            'display': display,
            'inline': inline,
            'issues': issues,
            'pass': exit_code == 0,
        }, indent=2, ensure_ascii=False))
    else:
        print(format_report(display, inline, issues, args.html))

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
