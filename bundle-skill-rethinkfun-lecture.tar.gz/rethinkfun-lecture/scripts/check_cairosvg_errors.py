#!/usr/bin/env python3
"""
check_cairosvg_errors.py — v7.8 smoking-gun detector for silent cairosvg failures

Background: When MathJax aligned/eqnarray environment SVGs lack width/height
attributes (MathJax puts size in style="min-width: Xex"), cairosvg throws
"The SVG size is undefined" and mjx_to_img falls back to a red error span.
verify_render() misses this because the fallback span has no mjx-container
class. ONLY pdftotext on the final PDF catches it.

Usage:
    python3 check_cairosvg_errors.py report.pdf
    # exit 0 = no errors, safe to ship
    # exit 1 = N errors found, DO NOT ship

The script also extracts surrounding context for the first 5 errors so the
operator can locate the failing LaTeX formulas in the source markdown.
"""
import subprocess
import sys
import re
from pathlib import Path


def count_cairosvg_errors(pdf_path: Path) -> int:
    """Count red [公式渲染失败: cairosvg 错误] spans in PDF text layer."""
    r = subprocess.run(
        ['pdftotext', '-layout', str(pdf_path), '-'],
        capture_output=True, text=True
    )
    if r.returncode != 0:
        print(f'ERROR: pdftotext failed: {r.stderr[:200]}', file=sys.stderr)
        return -1
    return r.stdout.count('[公式渲染失败')


def find_error_contexts(pdf_path: Path, max_show: int = 5) -> list[str]:
    """Extract surrounding text for the first N error spans."""
    r = subprocess.run(
        ['pdftotext', '-layout', str(pdf_path), '-'],
        capture_output=True, text=True
    )
    if r.returncode != 0:
        return []
    text = r.stdout
    contexts = []
    for m in re.finditer(r'\[公式渲染失败: cairosvg 错误\]', text):
        start = max(0, m.start() - 150)
        end = min(len(text), m.end() + 30)
        ctx = text[start:end].replace('\n', ' / ').strip()
        contexts.append(ctx[-200:])
        if len(contexts) >= max_show:
            break
    return contexts


def main():
    if len(sys.argv) != 2:
        print('Usage: check_cairosvg_errors.py report.pdf', file=sys.stderr)
        sys.exit(2)

    pdf_path = Path(sys.argv[1])
    if not pdf_path.exists():
        print(f'ERROR: {pdf_path} not found', file=sys.stderr)
        sys.exit(2)

    print(f'[*] Checking {pdf_path} for silent cairosvg failures...')
    err_count = count_cairosvg_errors(pdf_path)

    if err_count < 0:
        sys.exit(2)  # pdftotext itself failed

    if err_count == 0:
        print('[OK] 0 cairosvg errors — safe to ship')
        sys.exit(0)

    print(f'\n[FAIL] {err_count} cairosvg errors detected — DO NOT SHIP\n')
    print('Most common cause (v7.8): MathJax aligned/eqnarray environment SVG')
    print('has no width/height attribute (size in style="min-width: Xex").')
    print('Fix: render.py mjx_to_img() needs to parse min-width from style.')
    print()
    print('First 5 error contexts (search your markdown for these formulas):')
    for i, ctx in enumerate(find_error_contexts(pdf_path, max_show=5), 1):
        print(f'  [{i}] ...{ctx}...')
    print()
    print('See references/mathjax-aligned-svg-pitfall.md for the fix.')
    sys.exit(1)


if __name__ == '__main__':
    main()
