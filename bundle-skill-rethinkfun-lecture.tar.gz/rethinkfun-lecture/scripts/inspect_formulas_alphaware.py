#!/usr/bin/env python3
"""Inspect all display formula PNGs from rendered HTML — alpha-aware ground truth.

Detects 3 traps that fool naive detectors:
1. RGBA transparent → RGB black (alpha=0 becomes (0,0,0))
2. Long horizontal strokes (\\sqrt / \\frac / \\mathcal{N}) flagged as "black blocks"
3. SMask channels (handled separately by inspect_pdf_images.py)

Usage:
    python3 scripts/inspect_formulas_alphaware.py /path/to/report.html

Exit codes:
    0 — all display formulas in normal range (5-65% dark, >= 30 unique colors)
    1 — at least one formula abnormal (formula not rendered / cairosvg failed)

Companion to verify_pdf.py and visual_audit.py. Run after every render before
declaring 'ship'. See references/render-verification-blind-spots.md for full
methodology and false-positive history (v7.21 mis-detection case).
"""

import re
import base64
import sys
from io import BytesIO
from PIL import Image


def alpha_aware_dark_pct(png_bytes: bytes) -> tuple[float, int, int, int]:
    """Return (dark_pct, unique_colors, width, height) with alpha-aware analysis.

    Args:
        png_bytes: Raw PNG bytes (RGBA mode typical for cairosvg output)

    Returns:
        dark_pct: percentage of dark pixels (RGB < 50) after white-bg compositing
        unique_colors: number of distinct RGB values
        width, height: image dimensions
    """
    im = Image.open(BytesIO(png_bytes))
    if im.mode in ('RGBA', 'P'):
        rgba = im.convert('RGBA')
        bg = Image.new('RGBA', rgba.size, (255, 255, 255, 255))
        composite = Image.alpha_composite(bg, rgba)
        rgb = composite.convert('RGB')
    else:
        rgb = im.convert('RGB')
    w, h = rgb.size
    px = list(rgb.getdata())
    dark = sum(1 for r, g, b in px if r < 50 and g < 50 and b < 50)
    dark_pct = 100 * dark / len(px) if px else 0
    unique = len(set(px))
    return dark_pct, unique, w, h


def inspect_html_formulas(html_path: str) -> tuple[list, list]:
    """Inspect all display formula PNGs embedded in rendered HTML.

    Args:
        html_path: Path to the rendered HTML (e.g., report.html sibling of PDF)

    Returns:
        results: list of (idx, w, h, dark_pct, unique) tuples
        issues: list of issue strings (empty if all formulas normal)
    """
    with open(html_path, encoding='utf-8') as f:
        html = f.read()

    # Match display formula <img> tags
    pattern = r'<div class="math-block">\s*<img\s+src="data:image/png;base64,([^"]+)"[^>]*>'
    matches = re.findall(pattern, html)

    results = []
    issues = []
    for i, b64 in enumerate(matches, 1):
        png = base64.b64decode(b64)
        dark_pct, unique, w, h = alpha_aware_dark_pct(png)
        results.append((i, w, h, dark_pct, unique))

        # Ground truth thresholds for display formulas:
        # < 5%  → formula not rendered (transparent PNG / empty fallback)
        # > 80% → cairosvg returned black PNG (cairosvg parse error)
        # unique < 30 → too few colors (likely empty or single-color)
        if dark_pct < 5:
            issues.append(f'F{i}: dark={dark_pct:.1f}% (< 5% — formula 没渲染 / 透明 PNG)')
        elif dark_pct > 80:
            issues.append(f'F{i}: dark={dark_pct:.1f}% (> 80% — cairosvg 全黑失败)')
        elif unique < 30:
            issues.append(f'F{i}: unique={unique} (< 30 — 颜色太少，可能是空 fallback)')

    return results, issues


def main():
    if len(sys.argv) != 2:
        print('Usage: python3 inspect_formulas_alphaware.py <report.html>', file=sys.stderr)
        sys.exit(2)

    html_path = sys.argv[1]
    try:
        results, issues = inspect_html_formulas(html_path)
    except FileNotFoundError:
        print(f'❌ File not found: {html_path}', file=sys.stderr)
        sys.exit(2)

    print(f'=== {len(results)} display formulas (alpha-aware) ===')
    for idx, w, h, dark, uniq in results:
        flag = ' ⚠️' if any(f'F{idx}:' in i for i in issues) else ''
        print(f'  F{idx}: {w}x{h}, dark={dark:.1f}%, unique={uniq}{flag}')

    if issues:
        print(f'\n❌ {len(issues)} issues:')
        for issue in issues:
            print(f'  {issue}')
        print('\n→ DO NOT SHIP. Investigate failing formulas before re-rendering.')
        sys.exit(1)
    else:
        print(
            f'\n✅ All display formulas in normal range '
            f'(5-65% dark, >= 30 unique colors).'
        )
        sys.exit(0)


if __name__ == '__main__':
    main()