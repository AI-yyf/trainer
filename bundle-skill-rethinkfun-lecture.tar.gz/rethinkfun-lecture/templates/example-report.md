# <主题>

> **TL;DR**：一句话说明这个主题在解决什么问题、核心机制、最反直觉的结论。

---

## 直觉理解

[3-6 段连续 prose。问题驱动 → 旧办法为什么不够 → 最小直觉图景 → 术语落地。**比喻最多 1 个锚点**，整段不超过 2-3 句。不要堆"像 X 又像 Y 又像 Z"。]

---

## 公式推导

**当前状态**：[已知什么。]

**当前缺口**：[还缺什么。]

**引入对象**：[为了消缺口，先引入哪个数学对象。这个对象第一次出现，必须说明它来自哪个缺口、代表什么角色。]

[公式。必须先有目标和约束，再有公式。]

**校验**：[为什么这个公式只能长这样？删掉某个变量会损失什么？]

[下一轮：当前状态 → 新缺口 → 新对象 → 新公式 → 校验]

**收束**：[一段把整条公式链收回。]

---

## 代码讲解

**当前代码状态**：[理论闭环完成，现在落到代码。]

**当前缺口**：[代码要维护什么状态？输入什么状态？输出什么状态？]

### 训练代码

```python
def train_step(x_0):
    """对应 L_simple 的 Monte Carlo 估计"""
    t = torch.randint(0, T, (x_0.shape[0],))    # 均匀抽样时刻
    eps = torch.randn_like(x_0)                   # 抽一份高斯噪声
    x_t = sqrt(alpha_bar[t]) * x_0 + sqrt(1-alpha_bar[t]) * eps
    eps_pred = eps_model(x_t, t)                  # 网络预测 ε
    return F.mse_loss(eps_pred, eps)              # L_simple = ||ε - ε_θ||²
```

[每个变量回指到理论对象。shape / dtype / device / requires_grad 说明。]

### 采样代码

```python
@torch.no_grad()
def sample(batch_size):
    x = torch.randn(batch_size, *image_shape)
    for t in reversed(range(T)):
        eps_pred = eps_model(x, t)
        x = p_sample(x, t, eps_pred)
    return x
```

[每个函数回指到理论对象。]

**状态回收**：[代码怎么把理论闭环。]

---

## 参考来源

- Author1 et al., Year, *Title* — [arXiv:XXXX.XXXXX](https://arxiv.org/abs/XXXX.XXXXX)
- Author2 et al., Year, *Title* — [arXiv:XXXX.XXXXX](https://arxiv.org/abs/XXXX.XXXXX)
- Author3 et al., Year, *Title* — [arXiv:XXXX.XXXXX](https://arxiv.org/abs/XXXX.XXXXX)