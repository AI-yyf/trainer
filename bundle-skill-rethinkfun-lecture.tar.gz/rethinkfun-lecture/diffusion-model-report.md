---
title: 扩散模型：把生成拆成 1000 步去噪的方向场
subtitle: 从一团噪声到一张图——为什么 1000 步能跑赢一步
author: Hermes Agent
date: 2026-06-23
---

# 扩散模型：把生成拆成 1000 步去噪的方向场

> **一句话**：把"从一团噪声到一张图"的复杂映射，拆成 1000 步微小反向去噪。训练时让网络预测任意时刻 $t$ 混入的噪声 $\varepsilon_\theta(x_t, t)$，采样时从 $\mathcal{N}(0, I)$ 沿这个方向场反向积分回数据分布。

---

## 一、直觉理解

要让机器凭空生成一张从未见过的图，这件事本身就难。不是不会写生成代码——难的是，主流每一类方法都只解决了一半问题。

GAN 让生成器和判别器对抗博弈，出图能像照片，但训练极不稳定：判别器稍强，生成器学不动；判别器稍弱，生成器就开始只生成几种图（模式坍塌）。VAE 走另一条路，强行给图像配一个低维潜变量 $z$，让编码器把图压成 $z$、解码器把 $z$ 还原成图，训练目标同时要求"重建像不像"和"$z$ 的分布像不像标准正态"，结果是稳了但出图总是糊一层——潜变量被迫接近正态的代价是高频细节全丢了。VQ-VAE 把潜变量换成离散 codebook 索引，缓解了"后继坍缩"，但出图依然糊，且生成完全依赖外接一个自回归先验在 codebook 上跑——复杂度没降下来。Normalizing Flow（Glow 一类）走严格可逆的路线，理论上是唯一能精确算似然、又能并行采样的方法，但严格可逆的架构约束太大，高分辨率图像上根本 scale 不上去。自回归（PixelCNN 一类）一个像素一个像素往后猜，能算精确似然，但一张 $256 \times 256$ 的图要猜六万多次。所以到 2015-2017 年那个节点，局面是 GAN 像但不稳、VAE 稳但糊、Flow 准但慢、自回归更慢。

转折点来自一个反直觉的观察：与其让网络直接学"从一团噪声到一张图"的复杂一步映射，不如反过来——先搞清楚"图像到噪声"这个退化过程有多容易，再把退化过程倒过来跑。Ho et al. 2020 的 DDPM 就走这条路。具体是这样：固定一个很小的步长，往每张训练图上加一点点高斯噪声 $\varepsilon$。重复 $T = 1000$ 次，原始图 $x_0$ 就变成一团纯高斯噪声 $x_T$。这个前向过程每一步都是固定的高斯——没有参数可学，也没有梯度可传，听起来没什么用。但反向过程可以学，因为每步加的噪声足够小，反过来"去噪"也是高斯可学的：给我一张带噪图 $x_t$，让一个神经网络 $\varepsilon_\theta(x_t, t)$ 告诉我"这一步混进来的噪声 $\varepsilon$ 长什么样"。把去噪任务学 1000 遍、覆盖所有 $t$，再把顺序倒过来——从一团 $\mathcal{N}(0, I)$ 开始，反向调用"去噪一步" 1000 次，每一步把当前这一步的 $\varepsilon_\theta$ 从 $x_t$ 里减掉一点，就得到一张新图。

把这件事压缩成一句话：训练时学的是"任意时刻 $t$，从当前 $x_t$ 该往哪个方向推才能更像真实分布"的方向场；采样时把方向场从 $t = T$ 一路积分到 $t = 0$，就生成了新图。

为什么不是 GAN？因为对抗损失不直接衡量"样本在不在真实分布上"，梯度信号稀疏，模式覆盖差。为什么不是 Normalizing Flow？因为严格可逆的架构约束太大，难 scale 到高分辨率。为什么不是 VQ-VAE + 自回归？因为 codebook 上的自回归先验复杂度还是随图像分辨率线性增长，没解决根本问题。扩散模型赢在训练目标是一个均方误差——信号稠密、训练稳定、能算似然、模式全、能并行采样。这四个老问题一次性解决。

到这里画面应该清楚了：起点是真实分布，终点是 $\mathcal{N}(0, I)$，中间 1000 步每一段都是一个去噪方向 $\varepsilon_\theta(x_t, t)$。下面把画面写成符号。

---

## 二、公式推导

### 1. 加什么分布的噪声？

我们要给每张图 $x_0$ 注入噪声。但注入的"形态"必须满足两个硬条件，否则后面一切都垮：第一，1000 步后我们得能**一步写出**"任意 $t$ 步的图长啥分布"——不能真去循环 1000 次（训练一次就是 1 亿次采样，做不到）。第二，后面算反向训练的损失时，**两个高斯之间的 KL 散度得能闭式求导**——否则梯度只能采样估计，方差爆炸模型学不动。

这两个条件翻译成数学语言就是：注入的分布要**无穷可分**（infinite divisible，对任意 $n$，$n$ 个独立同分布变量叠加还是这个分布——这样 1000 步后分布依然是它自己，可以一步写出闭式），同时还要是**指数族**（exponential family，形如 $p(x) = h(x) \exp(\eta^\top T(x) - A(\eta))$——充分统计量 $T(x)$ 决定分布本身，KL 散度有闭式 $\int q \log(q/p) = \mathbb{E}_q[\log q - \log p]$，代入指数族形式直接得闭式）。

我们叫"无穷可分"这个名字是因为：$n$ 个独立的 $P$-分布随机变量之和还是 $P$。高斯是无穷可分的（$n$ 个独立高斯叠加还是高斯，均值加和、方差加和）；Poisson 也是无穷可分的（独立 Poisson 叠加还是 Poisson，参数相加）；但 Uniform 不是无穷可分（$n$ 个独立 Uniform 叠加趋向高斯，中间每步都不是 Uniform）。我们叫"指数族"这个名字是因为：所有指数族成员共享一个形式 $h(x) \exp(\eta^\top T(x) - A(\eta))$——$h$ 是基测度，$\eta$ 是自然参数，$T$ 是充分统计量，$A$ 是归一化常数（log-partition function）。高斯、Poisson、Bernoulli 都是指数族；Uniform、Laplace 不是。

所以"叠加 1000 次仍闭式"逼出无穷可分性、"KL 可闭式"逼出指数族——两者在常见分布里只有**高斯**同时满足。这就是为什么 $\varepsilon \sim \mathcal{N}(0, I)$。**它的"出生过程"是：约束 (a) 逼出无穷可分性、约束 (b) 逼出指数族——两者在常见分布里只有高斯同时满足。**

到这里 $\varepsilon$ 不是孤立选的，它决定了后面**所有**数学对象的形态：$q(x_t \mid x_0)$ 是高斯（因为高斯叠加是高斯）、$p_\theta(x_{t-1} \mid x_t)$ 也是高斯（反向也是高斯）、$L_{\text{simple}}$ 里的目标量是 $\varepsilon$ 的预测（不是 $x_0$、不是 $\mu$、不是 score——而是高斯本身）、Tweedie 公式把 $\varepsilon_\theta$ 和 $\nabla \log p_t(x_t)$ 等价（因为高斯 score 是线性的）。换掉 $\varepsilon$ 这一段的形态，下面所有公式的形态都跟着变。

三种"差一点"的分布各被卡掉一个条件：Uniform 不是无穷可分（叠加后中间每步不是 Uniform），写不出 $q(x_t \mid x_0)$ 的闭式；Poisson 是无穷可分也是指数族，但 **score 函数** $\nabla \log p(x) = \log \lambda - \log x!$ 含非线性阶乘，无闭式梯度，跟后面 score matching 视角对齐不上；Laplace 是无穷可分但不是指数族，KL 涉及 $\exp$ 积分无闭式。三种分布都各被卡掉一个能力——只有高斯两个都过。

### 2. 加多大？

注入分布选好了（高斯），下一步要决定**每步注入多少**。如果加噪量是常数（每步加同样的 $\beta$），那加噪强度就不可调——早期（$t$ 小）$x_t$ 接近 $x_0$ 时加同样的量、晚期（$t$ 大）$x_t$ 接近纯噪声时也加同样的量，这要么早期加得过头（破坏原图）、要么晚期加得不够（信号没消失）。**所以加噪量必须带下标 $t$ 变化**。

这个 $\beta_t$ 至少要满足三条硬约束。第一条 $\beta_t < 1$——因为后面要取 $\sqrt{1 - \beta_t}$（这个量是信号留存比例的来源），负数开方让方差无意义。第二条 $\beta_t > 0$——否则一步没加噪，1000 步退化成 1 步，链路白费。第三条更微妙：$\beta_t$ 还要**够小**——小到让每步扰动是"微高斯"，反向转移才近似也是高斯。这个第三条来自 Fokker-Planck 方程（Fokker-Planck equation，描述"一个随机过程的概率密度怎么随时间演化"的偏微分方程）的精确条件：当 $\beta \to 0$ 时，前向 SDE（加噪过程）的反向也是高斯。直觉上，**微小扰动是可逆的**（加一点点噪反过来就是去一点点噪），大扰动不可逆（加很多噪反过来不知道原信号是多少）。所以"小步噪声"假设是反向也是高斯的根因。

$\beta_t$ 来自一个**带下标 $t$ 的 schedule**——最简形式是常数（每步一样），最常用是线性 schedule $\beta_t = \beta_1 + t(T-1)(\beta_T - \beta_1)/(T-1)$（DDPM 原始版从 $10^{-4}$ 增到 $0.02$）。它的设计原则是：在 $T$ 步内累积加噪必须让 $x_T$ 退化成纯 $\mathcal{N}(0, I)$（不残留任何 $x_0$ 信息），但每步又不能太大以至于违反小步假设。这两个对偶约束让 schedule 必然是**单调递增**、**总量 $\to 1$** 的曲线。Nichol & Dhariwal 2021 的 Improved DDPM 发现**cosine schedule** 更好（$\bar{\alpha}_t = \cos^2(t/T \cdot \pi/2)$）——低分辨率时加稍多一点噪声、高分辨率时加稍少一点，FID 提升 2-3 个点。

两种"差一点"的 schedule 各有致命问题：固定 $\beta$ 让 $T$ 步累积加噪过快（$\beta$ 太小训练慢、$\beta$ 太大会违反小步假设），没自由度调速；指数 schedule $\beta_t = 1 - \alpha^t$ 让早期 $\beta$ 极小、晚期 $\beta$ 极大，反向高斯近似在晚期崩溃。线性 + cosine 是工程上找到的平衡点。

### 3. 每一步信号还剩多少？

既然 $\beta_t$ 是"每步加噪量"，那每步后"信号"还剩多少？答案是 $\alpha_t = 1 - \beta_t$。直接定义"信号留存比例"比"加噪量"更直觉——我们要度量"原图被保留了多少"，而不是"加了多少噪"。分清这两个量后，前向闭式 $q(x_t \mid x_0)$ 的均值才能写成 $\sqrt{\alpha_t} x_0$ 这种干净形式（而不是 $\sqrt{1 - \beta_t} x_0$，看似等价但不利于后续链式累积）。

$\alpha_t$ 的来源是单位方差的分解——每步操作"新信号 = $\alpha_t \cdot$ 旧信号 + 噪声"，信号系数就是 $1 - \beta_t$。这是线性信号 + 加性噪声的标准结构（想想 Kalman 滤波的状态转移，形式完全一样）。

但单个 $\alpha_t$ 还不够——我们要的是 1000 步累积后的"信号残留比例" $\bar{\alpha}_t = \prod_{s \le t} \alpha_s$。它必须被定义成**乘积**——因为每一步把信号再乘以 $\alpha$，多步累积自然是乘积（这是几何衰减的标准结构）。具体从**链式法则**（如果 $A \to B \to C$ 是 Markov 链，$C$ 只依赖 $B$ 不直接依赖 $A$，那 $P(C \mid A) = \int P(C \mid B) P(B \mid A) \mathrm{d}B$）来看：对高斯 $P(B \mid A) = \mathcal{N}(B; a A, \sigma_A^2)$ 和 $P(C \mid B) = \mathcal{N}(C; b B, \sigma_B^2)$，链式法则给出 $P(C \mid A) = \mathcal{N}(C; ab A, b^2 \sigma_A^2 + \sigma_B^2)$——**均值相乘、方差相加**。这正是 $\bar\alpha_t$ 为什么是乘积（信号均值相乘）和 $(1 - \bar\alpha_t)$ 怎么从 $1 - \alpha_1, 1 - \alpha_2, \dots$ 累积出来的根因。

$\bar{\alpha}_t$ 是后面写出前向闭式 $q(x_t \mid x_0)$ 的关键系数：均值 $\sqrt{\bar\alpha_t} x_0$、方差 $(1 - \bar\alpha_t) I$ 都直接由它决定。

### 4. 前向闭式分布

把"每步加一点点高斯"链起来。两个约束决定 $q(x_t \mid x_0)$ 的形式：它必须是高斯（封闭性——多个高斯叠加仍是高斯），$t=0$ 时退化为 $\delta(x_0)$（在 $x_0$ 处的"点质量"——概率全集中在 $x_0$ 一个点）、$t=T$ 时退化为 $\mathcal{N}(0, I)$。

不写闭式会怎样？每次想用 $q(x_t \mid x_0)$ 都得真去循环 1000 次——训练一次 1 万次迭代，1 亿次采样，不可能。同时，反向过程 $p_\theta(x_{t-1} \mid x_t)$ 的训练目标需要**任意 $t$ 都能算**——必须能任意时刻取样、任意时刻求 KL。**所以闭式是硬约束**。

联立"高斯 + 端点条件"两个约束。$t=0$ 时均值 = $x_0$、方差 = 0（$x_0$ 是确定的）；$t=T$ 时均值 = 0、方差 = 1（$x_T$ 是标准高斯）。任意 $t$ 的均值 $m(t)$ 和方差 $v(t)$ 必须满足：(a) $m(0) = x_0, v(0) = 0$，(b) $m(T) = 0, v(T) = 1$，(c) 单步转移是高斯，累积后均值/方差各自平滑（不要突变）。唯一满足这三个的解是
$$q(x_t \mid x_0) = \mathcal{N}\!\bigl(x_t;\ \sqrt{\bar{\alpha}_t}\, x_0,\ (1 - \bar{\alpha}_t)\, I\bigr) \tag{4.1}$$
均值 $\sqrt{\bar{\alpha}_t}\, x_0$ 随 $t$ 衰减（$\bar{\alpha}_t \to 0$），方差 $(1 - \bar{\alpha}_t)$ 随 $t$ 增长（$\to 1$）。这是"信号线性衰减 + 噪声方差线性增长"的标准形式。**前向闭式是后面所有推导的起点**：反向 $p_\theta$ 要逼近它、ELBO 要用它展开、重参数化要用它、采样要从它反着走。

唯一可改的是"信号衰减 + 噪声增长"的具体函数形式——可以不是 $\sqrt{\bar\alpha_t}$ 和 $(1-\bar\alpha_t)$，但必须满足"端点条件 + 单调"。**经验上**线性/cosine 是工程最优解（Nichol & Dhariwal 2021 测了 6 种 schedule），其他选择如 sigmoid schedule 都被 FID 测出来不如 cosine。

### 5. 反向过程为什么能学？

前向是"销毁信息"（加噪声很容易），反向是"恢复信息"（去噪声需要懂数据分布）。所以前向确定，反向才需要学。

但前向的反向到底是什么形式？我们假设前向是个 **Markov 链**——一个序列 $x_0, x_1, \dots, x_T$，其中 $x_t$ 只依赖 $x_{t-1}$（不依赖更早）。这叫"无记忆"。Diffusion 的前向过程 $q(x_t \mid x_{t-1}, x_0) = q(x_t \mid x_{t-1})$ 就是 Markov 链。Markov 链的好处是**联合分布可以写成条件分布的乘积** $P(x_0, x_1, \dots, x_T) = P(x_0) P(x_1 \mid x_0) P(x_2 \mid x_1) \cdots P(x_T \mid x_{T-1})$，可以一步步算。

但生成图时要从纯噪声 $\mathcal{N}(0, I)$ 反着走到图 $x_0$——这个**反向过程**没有解析形式（因为 $x_t$ 的真实分布 $p(x_t)$ 是从所有训练图累积出来的复杂多模态分布）。所以必须学。

为什么反向也是高斯？因为 $\beta_t$ 足够小时（"小步噪声"假设），前向转移是微小高斯扰动，反向转移也是近似高斯（Fokker-Planck 给出精确条件）。所以引入
$$p_\theta(x_{t-1} \mid x_t) = \mathcal{N}\!\bigl(x_{t-1};\ \mu_\theta(x_t, t),\ \Sigma_\theta(x_t, t)\bigr) \tag{5.1}$$
$\mu_\theta(x_t, t)$ 是神经网络要学的反向均值，输入 $x_t$ 和时刻 $t$；$\Sigma_\theta(x_t, t)$ 是反向方差。$p_\theta$ 是 $q$ 的对偶——$q$ 是前向（已知、不学），$p_\theta$ 是反向（未知、要学）。两者形式对称（都是高斯），但 $q$ 的均值/方差是 $\bar\alpha_t$ 的解析函数，$p_\theta$ 的均值/方差是神经网络的输出。

对比其他"反向过程"形式：(a) 任意非线性分布——形式太宽，参数化难、训练难，扩散模型的优雅在于"反向也是高斯"已经够用；(b) 离散化的反 Markov 链——不能求梯度，训练崩溃。**DDPM 原始版**设 $\Sigma_\theta = \sigma_t^2 I$ 不学（$\sigma_t^2$ 取 $\beta_t$ 或 $\tilde{\beta}_t$ 两个极端值之一），Ho 实验证明学 $\Sigma_\theta$ 反而让训练不稳定；**Improved DDPM** 让 $\Sigma_\theta$ 也变成可学习的对角矩阵，用 hybrid loss 同时训练 $\varepsilon$ 和 $\Sigma$，NLL 提升 2 个 nat 但 FID 几乎不变——证明"似然好"和"样本好"是两件事。

### 6. 训练目标

要学 $\mu_\theta$，需要损失函数。目标是最大化 $\log p_\theta(x_0)$（训练数据的对数似然——$\log p_\theta(x_0)$ 中的 $x_0$ 是真实数据（一张训练图），$p_\theta$ 是模型定义的数据分布，$\log p_\theta(x_0)$ 就是"模型觉得 $x_0$ 有多像真实数据"，数字越大越好）。

但直接最大化 $\log p_\theta(x_0)$ 做不到——$p_\theta(x_0)$ 是 $p_\theta(x_0 \mid x_1) p_\theta(x_1) \mathrm{d}x_1$ 的积分，积分维度 = 图像维度（$256 \times 256 \times 3 = 196608$ 维），数值积分不可能。必须**绕过积分**——变分下界（ELBO）就是绕过积分的标准技巧：用一个巧妙的数学不等式（Jensen 不等式——对凸函数 $\varphi$ 和概率分布 $P$：$\varphi(\mathbb{E}_P[X]) \leq \mathbb{E}_P[\varphi(X)]$，把 $\varphi = \log$（凸函数）代入就得到 $\log \mathbb{E}[\cdot] \leq \mathbb{E}[\log \cdot]$，差的那个量就是 KL 散度）把 $\log \int$ 变成 $\int q \log(\cdot)$，积分转化到我们能解析处理的 $q$ 分布上。

变分推断的标准展开给出
$$\begin{aligned}
L =\; & D_{\mathrm{KL}}\!\bigl(q(x_T \mid x_0)\,\|\,p(x_T)\bigr) \\
  &+ \sum\nolimits_{t > 1} D_{\mathrm{KL}}\!\bigl(q(x_{t-1} \mid x_t, x_0)\,\|\,p_\theta(x_{t-1} \mid x_t)\bigr) \\
  &- \log p_\theta(x_0 \mid x_1)
\end{aligned}$$

$L$ 是 $\log p_\theta(x_0)$ 的下界——$L$ 越小，$\log p_\theta(x_0)$ 越大（前向固定时 $L_T$ 是常数，所以 $L$ 减小的部分都进入 $\log p_\theta(x_0)$ 的提升）。它把"最大化似然"转换成"最小化 1000 个 KL"——每个 KL 都是 $q(\text{真实反向})$ 和 $p_\theta(\text{学习的反向})$ 的距离。

对比其他"绕过积分"的方法：(a) 重要性采样（IS）——方差大、训练不稳定；(b) 对比散度（CD）——专用于 EBM 训练，不能直接用于 diffusion；(c) score matching——其实就是 ELBO 重参数化后的等价形式，下一段会讲。ELBO 是变分推断的标准答案。

### 7. 重参数化——为什么预测 $\varepsilon$？

突破口是把 $x_t = \sqrt{\bar{\alpha}_t}\, x_0 + \sqrt{1 - \bar{\alpha}_t}\, \varepsilon$（其中 $\varepsilon \sim \mathcal{N}(0, I)$）代入。这里有个关键的工程技巧叫**重参数化 trick**（reparameterization trick）——如果想对一个随机变量 $z$ 求梯度，但 $z$ 是从分布 $p(z)$ 抽样出来的（不能直接反向传播），就把 $z = g(\varepsilon, \theta)$ 写成"确定性函数 $g$ + 无参数噪声 $\varepsilon \sim p(\varepsilon)$"——然后对 $g$ 和 $\theta$ 求梯度。VAE、diffusion、Flow Matching 都用这个 trick。

$L$ 里要优化的是让 $\mu_\theta(x_t, t)$ 逼近真实后验均值 $\tilde{\mu}_t(x_t, x_0)$。但 $\tilde{\mu}_t$ 显式依赖 $x_0$——网络输入只有 $x_t$、目标依赖 $x_0$——这是个 mismatch：让网络去拟合一个随 $x_0$ 漂移的量，训练目标不稳定。必须**改拟合一个只依赖 $x_t$（加上 $t$）的目标**。

把 $x_t$ 的闭式 $x_t = \sqrt{\bar\alpha_t} x_0 + \sqrt{1-\bar\alpha_t}\varepsilon$ 代入 $\tilde{\mu}_t$ 的定义 $\tilde{\mu}_t(x_t, x_0) = \frac{1}{\sqrt{\alpha_t}}(x_t - \frac{\beta_t}{2(1-\bar\alpha_t)} (x_t - \sqrt{\bar\alpha_t} x_0))$：

**第一步**，把 $x_t$ 用闭式展开：$\tilde\mu_t = \frac{1}{\sqrt{\alpha_t}} (\sqrt{\bar\alpha_t} x_0 + \sqrt{1-\bar\alpha_t}\varepsilon - \frac{\beta_t}{2(1-\bar\alpha_t)} (\sqrt{\bar\alpha_t} x_0 + \sqrt{1-\bar\alpha_t}\varepsilon - \sqrt{\bar\alpha_t} x_0))$。

**第二步**，括号内第二项化简（$x_t - \sqrt{\bar\alpha_t} x_0 = \sqrt{1-\bar\alpha_t}\varepsilon$）：$\tilde\mu_t = \frac{1}{\sqrt{\alpha_t}} (\sqrt{\bar\alpha_t} x_0 + \sqrt{1-\bar\alpha_t}\varepsilon - \frac{\beta_t \sqrt{1-\bar\alpha_t}\varepsilon}{2(1-\bar\alpha_t)})$。

**第三步**，$\sqrt{1-\bar\alpha_t}\varepsilon$ 系数合并：$1 - \frac{\beta_t}{2(1-\bar\alpha_t)} = \frac{2(1-\bar\alpha_t) - \beta_t}{2(1-\bar\alpha_t)}$。

**第四步**，利用 $\beta_t = 1 - \alpha_t$ 和 $1 - \bar\alpha_t = (1-\alpha_1)\cdots(1-\alpha_t)$，化简得
$$\mu_\theta(x_t, t) = \frac{1}{\sqrt{\alpha_t}}\!\left(x_t - \frac{\beta_t}{\sqrt{1 - \bar{\alpha}_t}}\,\varepsilon_\theta(x_t, t)\right) \tag{7.1}$$
**验证**：$t=T$ 时 $\bar\alpha_T \to 0$、$\beta_T \to 1$，$\tilde\mu_T = \varepsilon = x_1$（因为 $x_T$ 是纯噪声，$x_{T-1}$ 就是噪声本身），符合端点条件。

这个表达式的系数完全由 $x_t$ 和 $\varepsilon$ 的线性关系决定，没有自由度——代入 $x_t$ 的定义，把 $x_0$ 换成 $(x_t - \sqrt{1-\bar\alpha_t}\varepsilon)/\sqrt{\bar\alpha_t}$，就能解出 $\mu_\theta$ 关于 $\varepsilon_\theta$ 的唯一表达式。

让 $\mu_\theta$ 不直接预测 $\tilde{\mu}_t$，而是通过预测 $\varepsilon_\theta(x_t, t)$ 间接表达——$\varepsilon$ 也是 $x_0$ 的函数，但形式上是**高斯噪声**，比 $\tilde{\mu}_t(x_t, x_0)$ 这种复杂线性组合更"易学"，因为它有一个干净的先验 $\mathcal{N}(0, I)$。$\varepsilon_\theta$ 是 $\mu_\theta$ 的间接表达。两者一一对应（$\mu_\theta$ 是 $\varepsilon_\theta$ 的仿射变换），所以优化 $\mu_\theta$ 等价于优化 $\varepsilon_\theta$。但 $\varepsilon_\theta$ 的目标**只依赖 $x_t$ 和 $t$**——比 $\tilde{\mu}_t$ 干净很多（不需要 $x_0$）。

对比其他"重参数化目标"：(a) 预测 $x_0$ 直接——目标依赖 $\sqrt{1/\bar\alpha_t}$ 的尺度（$\bar\alpha_t$ 接近 0 时尺度爆炸），训练不稳定；(b) 预测 $\mu_\theta$——直接等价但目标含 $\tilde{\mu}_t$ 的复杂形式，梯度信噪比差；(c) 预测 score $\nabla \log p$——等价但要再过一次 Tweedie 公式（见下一段），不如直接预测 $\varepsilon$ 干净。**$\varepsilon$ 是高斯——有自己的 $\mathcal{N}(0,I)$ 先验，干净、稳定、可学。**

### 8. $L_{\text{simple}}$ 简化

把重参数化的 $\mu_\theta$ 代入 KL 闭式，得到
$$L_{t-1} = \mathbb{E}\!\left[\frac{\beta_t^2}{2\sigma_t^2\, \alpha_t\, (1 - \bar{\alpha}_t)} \left\| \varepsilon - \varepsilon_\theta(x_t, t) \right\|^2\right] \tag{8.1}$$
注意这个 $\mathbb{E}[\cdot]$ 是个**期望符号**——意思是"在某个分布上取平均"。一个量 $\mathbb{E}_{p(z)}[f(z)]$ 不能解析算时，就从 $p(z)$ 抽 $N$ 个样本 $z_1, \dots, z_N$，用 $\frac{1}{N} \sum f(z_i)$ 估计——这叫 **Monte Carlo 估计**（Monte Carlo estimation），$N$ 越大越准。Diffusion 训练就是 Monte Carlo：$t, x_0, \varepsilon$ 都从对应分布抽样，$\mathbb{E}$ 用样本平均估计。

$L_{t-1}$ 是个**带权重的** MSE——权重 $\beta_t^2/(2\sigma_t^2 \alpha_t (1-\bar\alpha_t))$ 强烈依赖 $t$。问题是：训练时是**均匀抽样** $t$ 的（每个 $t$ 被采到的概率一样），但损失里每个 $t$ 的权重不同——这就**等效于让训练样本不均衡**了：小 $t$ 的样本贡献小（因为 $\beta_t^2$ 小）、大 $t$ 的样本贡献大。直觉上这是错的——大 $t$ 的样本虽然更"难"，但每个样本的信息量是一样的。

注意权重 $\beta_t^2/(2\sigma_t^2 \alpha_t (1-\bar\alpha_t))$ 里，$\beta_t$ 和 $\sigma_t$ 都与 $t$ 有关（$\sigma_t^2$ 取 $\beta_t$ 或 $\tilde\beta_t$，两者都正比于 $\beta_t$），但 $1-\bar\alpha_t$ 也与 $t$ 有关——权重并不真的"对所有 $t$ 相同"。但当 $\beta_t$ 很小（线性 schedule 下大部分 $t$ 的 $\beta_t$ 在 $10^{-4}$ 量级）时，权重里的 $t$ 依赖主要是 $\beta_t^2$ 项——它在小 $t$ 时接近 0、在大 $t$ 时接近 $\beta_T^2$。丢掉权重，得到
$$\begin{aligned}
L_{\mathrm{simple}}(\theta) &= \mathbb{E}_{t, x_0, \varepsilon}\!\left[\,\big\| \varepsilon - \varepsilon_\theta(x_t, t) \big\|^2\,\right] \\
\text{where } x_t &= \sqrt{\bar{\alpha}_t}\, x_0 + \sqrt{1 - \bar{\alpha}_t}\, \varepsilon
\end{aligned}$$
$L_{\mathrm{simple}}$ 不再是 ELBO 的下界，而是 ELBO 的一个加权版（权重 $1$）。简化版丢掉了权重后，反而把训练焦点放在"大 $t$ 难任务"上——大 $t$ 时 $x_t$ 几乎全是噪声，$\varepsilon_\theta$ 必须从一团噪声里推出原始结构，是出图质量最敏感的阶段。ELBO 原本按 $t$ 加权，反而稀释了大 $t$ 的重要性。$L_{\mathrm{simple}}$ 不是因为更准，而是更"对症"。

对比"丢掉权重"的其他理由：(a) "反正效果一样"——错，Ho 实验证明 $L_{\mathrm{simple}}$ 出图 FID 比带权重的 ELBO 低 30%；(b) "权重近似为常数"——错，刚才分析过权重强烈依赖 $t$；(c) "加速训练"——对，但**不是**主要原因，主要原因是**重新平衡了"难度权重"**。这个简化是经验+理论共同推出的，不是无脑扔权重。

### 9. Score 与 $\varepsilon$ 的等价（Tweedie's Formula）

这里还有一个深层联系。我们用到一个核心对象——**score** $\nabla \log p(x)$：一个概率分布 $p(x)$ 的"对数梯度"——$\log$ 让密度 $p$ 变成"对数密度"（单调变换，peak 不变但数值尺度友好），再 $\nabla$（梯度）给出"密度上升最快的方向"。**所以 score 在 $x$ 上指向"使 $x$ 更像真实数据"的方向**——这正是 diffusion 想去噪的方向。

**Score matching** 是一种学 score 函数 $\nabla \log p(x)$ 的方法，由 Hyvärinen 2005 提出。核心 trick：直接对 score 求 MSE 不行（不知道真实的 $\nabla \log p$），但可以**间接**求——通过 Fisher 恒等式转化为可计算的损失。NCSN 2019 就是用 score matching 训练 EBM，DDPM 的 $L_{\text{simple}}$ 其实也是 score matching 的一种形式（denoising score matching）。

我们有两套看似不同的视角：DDPM 派（VAE 角度，推导 ELBO → $L_{\text{simple}}$）和 NCSN 派（score matching 角度，推导 denoising score matching → 预测 score）。**两套视角用了不同的目标量**（$\varepsilon$ vs $\nabla \log p_t$），公式也不同——但工程上都成功出图。读者会困惑：到底哪个对？还是两个都对？必须有一个"统一公式"显式说明两者等价。

Tweedie's Formula 是统计里的一个恒等式：在高斯扰动下，$x_0$ 在给定 $x_t$ 下的后验均值是 $\mathbb{E}[x_0 \mid x_t] = x_t + (1 - \bar{\alpha}_t)\, \nabla \log p_t(x_t)$——也就是说，从 $x_t$ 推出 $x_0$ 的最优估计，恰好等于 $x_t$ 加上一个跟 score 成正比的修正项。把 $x_t = \sqrt{\bar\alpha_t} x_0 + \sqrt{1-\bar\alpha_t}\varepsilon$ 代入，反解出 $x_0 = (x_t - \sqrt{1-\bar\alpha_t}\varepsilon)/\sqrt{\bar\alpha_t}$。两边对 $x_t$ 求条件期望，注意 $x_0$ 的后验期望出现在左边：$\mathbb{E}[x_0 \mid x_t] = (x_t - \sqrt{1-\bar\alpha_t}\mathbb{E}[\varepsilon \mid x_t])/\sqrt{\bar\alpha_t}$。把这个关系和 Tweedie 公式联立，可以反推出
$$\nabla \log p_t(x_t) = -\frac{\varepsilon_\theta(x_t, t)}{\sigma_t} \tag{9.1}$$
其中 $\sigma_t = \sqrt{1-\bar\alpha_t}$。**预测 $\varepsilon$ 等价于估计 score 场**——DDPM（VAE 派）和 NCSN（score matching 派）看似不同入口，最后落到同一件事。Luo 2022 的综述进一步证明，预测 $x_0$、预测 $\varepsilon$、预测 score、预测 $v = \sqrt{\bar\alpha_t}\varepsilon - \sqrt{1-\bar\alpha_t}\,x_0$——这四种参数化通过 Tweedie's Formula 完全等价，只差一个缩放因子。**实际工程上**这四种选哪个？经验上 $v$-prediction 最稳（训练-推理一致性最好），成为 Stable Diffusion 系列的默认；$\varepsilon$-prediction 公式最简洁，便于理论分析；score-prediction 在 NCSN 系里最自然；$x_0$-prediction 物理意义最直观。

到这里我们获得了四样东西。前向过程是固定高斯，无需学。反向过程是学习的去噪方向。训练目标是 $\varepsilon$（或 $v$、或 score）预测的 MSE。采样是从 $\mathcal{N}(0, I)$ 反向积分。但有四个反直觉的结论值得说一遍——

第一，训练目标不是 ELBO，而是简化版 $L_{\mathrm{simple}}$，简化版出图反而更好。"理论上更紧的似然界"不等于"更好的样本"。第二，前向过程完全不学——它就是固定的高斯加噪，没有参数、没有梯度。这跟 VAE 的编码器形成鲜明对比。第三，预测 $\varepsilon$ 等价于估计 score。Song 2019 的 NCSN 视角：$\nabla \log p_t(x_t)$ 正是数据密度上升最快的方向。DDPM 和 NCSN 走的是同一条路——一个从 hierarchical VAE 推导、一个从 score matching 推导，殊途同归。第四，$T = 1000$ 不是越大越好——它是"小步噪声"假设能成立的最小步数。$\beta$ 太小训练慢，$\beta$ 太大会违反反向也是高斯的近似。

### 10. 采样

训练完后，从 $\mathcal{N}(0, I)$ 反向跑
$$x_{t-1} = \frac{1}{\sqrt{\alpha_t}}\!\left(x_t - \frac{\beta_t}{\sqrt{1 - \bar{\alpha}_t}}\,\varepsilon_\theta(x_t, t)\right) + \sigma_t\, z \tag{10.1}$$
训练好的 $\varepsilon_\theta$ 必须"用起来"——具体怎么从一团纯噪声反着走到 $x_0$？直观就是一步步减噪声，每步用 $\varepsilon_\theta$ 推"这一步减多少"。

代入反向高斯 $p_\theta(x_{t-1} \mid x_t) = \mathcal{N}(x_{t-1}; \mu_\theta, \sigma_t^2 I)$，采样就是从高斯里抽——$\mu_\theta$ 是中心、$\sigma_t z$ 是高斯扰动。$\mu_\theta$ 已经用 $\varepsilon_\theta$ 表达（重参数化那一段），$\sigma_t^2$ 取 $\beta_t$ 或 $\tilde\beta_t$。最后一步不加随机项，否则会破坏已经推回的数据分布——最后一步从 $x_1$ 推到 $x_0$ 时已经接近数据了，再加噪声会引入不必要的扰动。

采样公式是训练目标 $L_{\text{simple}}$ 的"使用版"——训练时学 $\varepsilon_\theta$、采样时用 $\varepsilon_\theta$。训练和采样共用同一组参数 $\theta$，没有任何"再训练"。

对比其他采样策略：(a) DDPM 原版 1000 步——太慢；(b) DDIM 20-50 步确定性 ODE——抛弃随机性，让前向变成确定性；(c) DPM-Solver 10-20 步——更高阶 ODE 求解器；(d) Consistency Model 单步——直接学 ODE 解的 identity，跨步。不同策略是"准确度 vs 速度"的不同折中。

### 11. 加速与条件控制

跑 1000 次神经网络出图太慢——DDIM 抛弃随机性，让前向变成确定性 ODE，20-50 步即可出图。这里要理解两个核心数学对象——**ODE**（ordinary differential equation，常微分方程）只含确定性项，例如 $\mathrm{d}x / \mathrm{d}t = f(x)$——给定起点 $x(0)$，轨迹完全确定。**SDE**（stochastic differential equation，随机微分方程）含随机项，例如 $\mathrm{d}x / \mathrm{d}t = f(x) + g(x) \cdot \mathrm{d}W$——$W$ 是 Wiener 过程（布朗运动），轨迹是概率分布。DDPM 反向过程是 SDE（因为有 $\sigma_t z$ 项），但 SDE 有一个"对应的"概率流 ODE——走同一条轨迹但不带随机性。DDIM 就是把 SDE 换成这条 ODE，所以可以大步走。

1000 步采样在 512×512 图上要 30-60 秒/张，对应用层太慢。必须**减少步数**——但直接跳步会让每步的"去噪量"过大，违反小步假设，FID 立刻塌掉。必须有一种"跳步但保持质量"的方法。

Song et al. 2021 证明 DDPM 训练目标对应一个**连续时间的 SDE**，离散化形式就是 1000 步。SDE 等价于一个**概率流 ODE**（确定性）——所以训练好的模型**同时**支持随机采样（用 SDE 离散化）和确定性采样（用 ODE 离散化）。ODE 不需要噪声项 $z$ 维持随机性，因为 ODE 本身就是确定性的。20-50 步 ODE 求解器和 1000 步 SDE 求解器**在数学上**收敛到同一条轨迹——但前者的浮点误差更小。

DDIM/ODE 采样是"前向闭式 + 反向高斯 + 训练目标"这条链上的"加速选项"——它不改变训练目标，只改变推理时的求解器。训练仍然用 DDPM 的 1000 步等价目标，推理时换成 ODE 求解器。

有条件生成时怎么让图"听话"？训练时同时学无条件版本（条件 $c$ 随机以 10% 概率被替换为 $\emptyset$），采样时
$$\tilde{\varepsilon} = (1 + w)\, \varepsilon_\theta(x_t, c) - w\, \varepsilon_\theta(x_t, \emptyset) \tag{11.1}$$
条件生成（用文本生成图）有一个根本难题：模型学到的是"在所有训练图上平均的合理方向"——对一条具体 prompt 来说，这个平均方向往往不够强烈。比如"a red cat"和"a black cat"在条件方向的差别其实很小，模型会倾向于输出"猫的颜色混合"。需要**放大条件方向的强度**，但又不能直接 $\varepsilon_\theta(x_t, c) \cdot k$（那样图会饱和、伪影）。

把"有条件预测"和"无条件预测"的差当成"条件方向"。在（条件, 无条件）这条直线上做外推：$\tilde{\varepsilon} = \varepsilon_\theta(x_t, c) + w (\varepsilon_\theta(x_t, c) - \varepsilon_\theta(x_t, \emptyset)) = (1 + w) \varepsilon_\theta(x_t, c) - w \varepsilon_\theta(x_t, \emptyset)$。$w > 0$ 时**远离无条件方向、朝条件方向外推**——条件信号被放大。$w = 0$ 退化为普通采样；$w$ 越大出图越"听话"但多样性下降。直觉上，$\varepsilon_\theta(x_t, c) - \varepsilon_\theta(x_t, \emptyset)$ 是"条件独有的方向"，$w$ 控制这个方向的强度。

对比其他"放大条件信号"的方法：(a) Classifier Guidance（2019 Dhariwal & Nichol）——需要额外训练一个分类器 $p(c \mid x)$，训练成本翻倍；(b) 直接 $\varepsilon_\theta \cdot k$——会让图过饱和、出现伪影；(c) 损失函数加权重——训练变慢、需要重新训。**CFG 是"训练时一次学两个、采样时线性组合"——零额外训练成本、可调 $w$**。

算力层面，512×512 图在像素空间跑扩散要几百 GB 显存——Latent Diffusion 先用一个预训练 VAE 把图压到 $4 \times 64 \times 64$ 的潜空间再跑扩散，算力省 8-48 倍，效果几乎不损失。像素空间跑扩散：每步 $\varepsilon_\theta$ 是 200+ GFlops 的 U-Net/Transformer，跑 1000 步 = 200 TFlops 算力、几百 GB 显存——对个人研究者和应用层完全不可用。必须**降低维度**——但简单降采样（$4\times$ downsample）会让图糊。

图像有一个**重要统计性质**：信息在频域上不均匀——低频（结构、布局、整体颜色）承载大部分语义信息，高频（纹理、细节、噪点）只承载"看起来真实"。这个性质允许我们：(a) 用一个 VAE 把图像压到 $4 \times 64 \times 64$ 的低维潜空间，**保留低频、扔掉高频**；(b) 在潜空间跑扩散（算力降 8-48 倍）；(c) 训练好的 VAE 解码器**补回**被扔掉的高频（它已经学会从低频重建图）。

对比其他"降低维度"方案：(a) PixelCNN 自回归——复杂度随分辨率线性增长，不解决根本问题；(b) VQ-VAE + 自回归——codebook 上的自回归先验复杂度还是随图像分辨率线性增长；(c) Cascade Diffusion——分多个分辨率跑多模型，工程复杂、训练成本高。**Latent Diffusion 是"先压到极低维、再跑扩散"——一步到位。**

### 12. 最新进展

架构层面，DiT 用 transformer 替代 U-Net，Gflops 越大 FID 越低——为什么？因为 transformer 的 per-step capacity 比 U-Net 高（per-step capacity 是扩散模型的主要瓶颈，不是 token count），所以 scaling 干净。U-Net 是为像素空间设计的——它的卷积核对图像局部性假设很强（"相邻像素相关"），但**全局依赖**建模能力弱（必须靠深层 + 大感受野堆叠）。对于"画一只猫在沙发上"这种 prompt 条件，模型需要**远距离关联**（"猫"和"沙发"在图上可能相距很远）。U-Net 必须用自注意力模块堆叠才能勉强捕获这种依赖——**效率很低**。Transformer 原生支持全局依赖——每个 token 都能直接注意所有其他 token。

这里的 transformer 是 **ViT**（Vision Transformer）——把图像切成 $16 \times 16$ 的小方块（patch），每个 patch 线性映射成一个向量（token），再把这些 token 序列送进标准 transformer。每个 token 都"看见"所有其他 token——这是 ViT 跟 CNN 的根本区别（CNN 是局部卷积）。DiT 用同样的思路，但加了"时间步 $t$"作为额外 token 注入。

PixArt-α 把 T2I 训练成本从 SD 1.5 的 6250 A100·days 砍到 675（10.8%），通过训练策略分解（像素依赖 / 文本对齐 / 美学质量 三阶段）+ cross-attention 注入文本条件 + VLM 密集标注 三招实现。**Cross-attention** 是 Transformer 里 Q 来自一个序列、K/V 来自另一个序列的注意力机制。在文生图里，Q 来自图像 token（"我应该长什么样"），K/V 来自文本 token（"文字说我要长什么样"）——cross-attention 让图像每个 patch 都能"看到"文本的每个词。

### 13. Flow Matching 和 Rectified Flow —— diffusion 的另一条进路

到第 12 节为止，我们讲的全是"diffusion 家族"——前向是高斯加噪、反向是去噪。2022 年有一个独立进路几乎**同期被两组人提出**，从完全不同的入口走到同一件事：让数据 ↔ 噪声走**直线**。这两组人就是 **Flow Matching**（Lipman et al. 2022, "Flow Matching for Generative Modeling", arXiv:2210.02747）和 **Rectified Flow**（Liu et al. 2022, "Flow Straight and Fast: Learning to Generate and Transfer Data with Rectified Flow", arXiv:2209.03003）。**这两条线在数学上等价，但出发点完全不同**——把它们并列讲，能让读者看清"为什么这个想法在 2022 年同时被两组人独立发现"。

Flow Matching 视角里，**ODE** 是 $\mathrm{d}x_t / \mathrm{d}t = v_\theta(x_t, t)$——给定起点 $x(0)$，沿 $v_\theta$（向量场，每个时空点 $(x, t)$ 一个箭头，告诉你"现在 $x$ 应该如何随时间移动"）积分得到 $x(t)$。**Continuous normalizing flow (CNF)** 是一种"用 ODE 把一个分布流成另一个分布"的生成模型——从 $t=0$ 的数据分布出发，沿 $v_\theta$ 积分到 $t=1$ 得到 $p_1$（希望是噪声分布），可以反着积分（从噪声到数据）做生成。**理论上** CNF 完美，但训练要算"密度怎么随 ODE 变"——这需要 $\mathrm{tr}(\partial v_\theta / \partial x)$（向量场 Jacobian 的迹），$O(d^2)$ 算不动。Flow Matching 的洞察：**不用算 trace**——直接对 ODE 的向量场做 regression。

Rectified Flow 视角里，**OT**（optimal transport，最优传输——给定两个分布，找"搬运"概率质量最便宜的方式，最小化 $\int c(x, y) \pi(x, y) \mathrm{d}x \mathrm{d}y$，$c$ 通常用 $\|x - y\|^2$）给出连接两个分布的最优路径——Rectified Flow 用 OT 视角解释为什么自己的路径是直的。

Diffusion 家族（前 12 节）有两个根本痛点：(a) 路径弯曲——$x_0 \to x_T$ 的 SDE 轨迹是弯的（高斯加噪的天然结果），ODE 求解器必须用小步长才能跟住，质量-速度 trade-off 极差；(b) 训练目标需要推导 ELBO——重参数化那一段我们用了整整一节才把 $\varepsilon$ 推导出来，工程门槛高。**Flow Matching 的目标是：能不能完全绕开 ELBO？能不能直接学一个向量场（vector field）？**

**Flow Matching 的路径**（Lipman et al. 2022）：出发点是 CNF——用 ODE $\mathrm{d}x_t / \mathrm{d}t = v_\theta(x_t, t)$ 把数据 $x_0$ 流到噪声 $x_1$。CNF 理论上完美（连续时间、可逆、概率密度可算），但**训练**要算 $\mathrm{tr}(\partial v_\theta / \partial x)$（instantaneous change of variables，Chen et al. 2018 Neural ODE）——这个 trace 在高维图像上算不动（要算 Jacobian trace，$O(d^2)$）。

Flow Matching 的洞察：**不用算 trace**——直接对 ODE 的向量场做 regression。定义概率路径 $p_t(x)$ 在 $t=0$ 是数据分布、$t=1$ 是标准高斯，定义它对应的**向量场** $u_t(x)$（使 $\mathrm{d}x/\mathrm{d}t = u_t(x)$ 把 $p_0$ 流到 $p_1$）。然后让神经网络 $v_\theta(x, t)$ 直接回归 $u_t(x)$：
$$L_{\text{FM}}(\theta) = \mathbb{E}_{t, x_0, x_1 \sim p_1}\!\left[\,\big\| v_\theta(x_t, t) - u_t(x_t) \big\|^2\,\right] \tag{13.1}$$
其中 $x_t = (1-t) x_0 + t x_1$ 是**线性插值**（不是高斯加噪！）。这个 loss 没有 ELBO、没有 trace、就是普通的 MSE——和 $L_{\text{simple}}$ 形式上完全一样。

关键 trick：选一个**条件概率路径** $p_t(x \mid x_0) = \mathcal{N}(x; (1-t) x_0, t^2 I)$（均值从 $x_0$ 线性滑到 0、方差从 0 线性增到 1）——这个高斯路径有**闭式向量场** $u_t(x \mid x_0) = (x - x_0) / t$（可以验证这条向量场正好把 $p_t(\cdot \mid x_0)$ 流到 $p_1$）。把条件向量场代入 loss，注意到 $x_t - x_0 = t \cdot u_t(x_t \mid x_0)$——化简后 loss 变成
$$L_{\text{FM}}(\theta) = \mathbb{E}_{t, x_0, x_1, \varepsilon}\!\left[\,\big\| v_\theta(x_t, t) - (\varepsilon - x_0) \big\|^2\,\right] \tag{13.2}$$
其中 $x_1 = \varepsilon \sim \mathcal{N}(0, I)$。

**Rectified Flow 的路径**（Liu et al. 2022）：出发点**完全相反**——Liu 的目标是"**让 DDPM 的路径变直**"。他注意到：传统 diffusion 的 $x_t$ 是 $x_0 + \sqrt{1-\bar\alpha_t} \varepsilon$——这个轨迹在数据-噪声空间里是弯的（因为 $\sqrt{1-\bar\alpha_t}$ 随 $t$ 的曲线形态导致 $x_t$ 走曲线）。Liu 的洞察是：**直接换掉前向公式**——用线性插值 $x_t = (1-t) x_0 + t \varepsilon$ 替代高斯加噪。这个插值就是连接 $x_0$ 和 $\varepsilon$ 的**直线段**——轨迹天然是直的。

然后 Liu 用"rectification"步骤（reflow，用 ODE 解出来的 $x_1$ 重新当 $x_1'$ 训一次）让数据 ↔ 噪声分布对齐到同一条直线上。Rectified Flow 的训练目标和 Flow Matching **完全一样**：
$$L_{\text{RF}}(\theta) = \mathbb{E}_{t, x_0, \varepsilon}\!\left[\,\big\| v_\theta(x_t, t) - (\varepsilon - x_0) \big\|^2\,\right] \tag{13.3}$$
其中 $v_\theta(x_t, t) = \varepsilon - x_0$ 是直线段的速度向量。

**两篇论文数学等价，但动机相反**：
- **Flow Matching 动机**："能不能不学 ELBO，直接学一个向量场？"——从 CNF 出发
- **Rectified Flow 动机**："能不能让 diffusion 路径变直？"——从 diffusion 出发

两者都走到了同一个 loss $L = \mathbb{E}\|\varepsilon - x_0 - v_\theta\|^2$——读者意识到这一点会明白：**这个 loss 不是 Rectified Flow 偶然发现的，而是 Flow Matching 也独立发现的**——它几乎是"连续归一化流 + 线性插值"这个设定的**唯一自然选择**。

$v_\theta$ 和 $\varepsilon_\theta$ **只差一个仿射变换**——$v = \varepsilon - x_0$（从 $x_t$ 出发沿直线走到 $x_1 = \varepsilon$ 的速度）。所以 FM/RF 训练出来的模型，**和 diffusion 训练出来的 $\varepsilon_\theta$ 在某种意义上是等价的**——只是目标量不同。Tong et al. 2023 ("Improving and Generalizing Flow-Based Generative Models with Minibatch Optimal Transport", arXiv:2302.00482) 证明 FM/RF 实际上**统一了 diffusion、CNF、Flow Matching 三类方法**——它们都等价于在某个概率路径 $p_t$ 上学一个向量场。

对比"绕开 ELBO"的其他方法：(a) GAN——需要 discriminator、对抗训练不稳定；(b) VAE——只能学后验、不能直接采 ODE；(c) Neural ODE 直接学——需要算 trace、$O(d^2)$ 算不动。**Flow Matching 是"选一个闭式条件路径 → 推导出闭式条件向量场 → 用 regression loss 拟合"**——三步走，零复杂数学。

SD3（Stability AI 2024）和 FLUX（Black Forest Labs 2024）都基于 Rectified Flow——因为直线轨迹让**少步采样**成为现实（4-8 步即可），对应用层意义重大。

Consistency Model 直接把任意 $t$ 的 $x_t$ 映射到 $x_0$，单步生成——本质上是在学 ODE 解的 identity，跳过中间迭代。ODE $\mathrm{d}x / \mathrm{d}t = v_\theta(x, t)$ 有一个性质：给定起点 $x(T)$，沿 ODE 走到 $t=0$ 得到 $x(0)$。把 $x(0)$ 写成 $x(T)$ 和 $T$ 的函数 $f(x_T, T) = x(0)$——这就是 ODE 解的"identity"（不依赖中间轨迹，只依赖起点和终点）。Consistency Model 学的就是这个 $f$。

**它解决什么失败场景**？Rectified Flow 还要 4-8 步采样。能不能**1 步**？DDPM、Rectified Flow 都训练一个"多步采样器"——要 N 步才能把噪声推到 $x_0$。如果能训练一个"任意 $x_t$ → 直接输出 $x_0$"的模型，1 步就能生成。Consistency Model（Song et al. 2023）的洞察是：ODE 的解 $x(t)$ 满足一个特殊性质——**任意时刻 $t$ 出发按 ODE 走到 $t = 0$ 都会得到同一个 $x_0$**。所以 $f(x_t, t) = x_0$ 对所有 $t$ 都是"同一个东西"——把 $f$ 学成神经网络，约束"对所有 $t$, $f(x_t, t)$ 输出同一值"——这就叫 consistency。

1 步生成的代价是**单步质量**比 4-8 步差（FID 高 30-50%）——目前的折中是 Consistency Model 2-4 步。

整个框架真正的优雅在于：DDPM、NCSN、Improved DDPM、Score SDE、Rectified Flow、**Flow Matching**、Consistency Model 看似不同论文、不同视角、不同公式，最终都收敛到同一条路——学一个向量场 $v_\theta(x_t, t)$，沿着它积分回去。**DDPM 派**走 ELBO → $\varepsilon_\theta$；**Score SDE 派**走 score matching → $\nabla \log p_t$；**Flow Matching 派**走 CNF → $v_\theta$；**Rectified Flow 派**走 diffusion 路径拉直 → 同一个 $v_\theta$。四个入口，四种公式，最后都指向**同一个 ODE** $\mathrm{d}x_t = v_\theta(x_t, t) \mathrm{d}t$。所有后续工作都在问同一个问题——怎么让这条积分路径更直、更稳、更快。CFG 让它更听话，latent 让它更省钱，DiT 让它更可 scale，rectified flow 让它更短。

---

## 三、如果你忘了一切，记住这 5 句话

1. **前向加噪是固定高斯，反向去噪是学一个方向场**。每一步的网络输出"从 $x_t$ 该往哪走"——把这 1000 步的"方向"学成 $\varepsilon_\theta(x_t, t)$。
2. **训练目标是一个 MSE**：预测任意时刻 $t$ 混入的噪声 $\varepsilon$。不是 ELBO、不是对抗、不是 score matching 的复杂形式——就是普通 MSE。这就是 diffusion 训练稳定的根因。
3. **采样是从 $\mathcal{N}(0, I)$ 反向积分 1000 步**。每步调用一次 $\varepsilon_\theta$、减一点噪声、加一点随机——最后得到一张图。
4. **CFG 让图听话**：条件预测和无条件预测的线性外推。Latent 让图省钱：在 $4 \times 64 \times 64$ 的潜空间跑扩散。DiT 让图 scale：换 transformer 替代 U-Net。Rectified Flow 让图快：让数据↔噪声走直线。
5. **Flow Matching / Rectified Flow 是同一条路的另一种入口**。直接学向量场 $v_\theta$ 而不是 $\varepsilon_\theta$——数学等价，动机不同。

---

## 四、代码讲解

理论到实现的桥梁要建起来。代码不能独立于理论——每个函数、每个张量、每个 shape 都要回指一个数学对象或状态转移。要维护的代码状态是三个：数据 $x_0$、时刻 $t$ 的中间态 $x_t$、神经网络参数 $\theta$。每个时刻 $t$ 上要 (a) 抽样得到 $x_t$、(b) 算损失、(c) 反向传播更新 $\theta$。最小可运行流程由 `train_step(x_0)` 和 `sample(batch_size)` 两个函数组成，共用一个神经网络 `eps_model(x_t, t)`。

### 训练代码：`train_step.py`

```python
def train_step(x_0):
    """训练一步 — 对应 L_simple 的单次 Monte Carlo 估计"""
    t  = torch.randint(0, T, (x_0.shape[0],))   # ① 均匀抽样时刻
    ε  = torch.randn_like(x_0)                  # ② 抽一份标准高斯噪声
    x_t = q_sample(x_0, t, ε)                   # ③ 前向加噪 q(x_t | x_0)
    ε_pred = eps_model(x_t, t)                  # ④ 网络预测 ε
    loss = F.mse_loss(ε_pred, ε)                # ⑤ L_simple = ||ε - ε_θ||²
    loss.backward()                             # ⑥ 反向传播更新 θ
    return loss
```

每个变量对应什么理论对象：① `t` 对应"均匀抽样 $t \in \{1, \dots, T\}$"（Monte Carlo 估计 $L_{\mathrm{simple}}$）。均匀抽样让每个 $t$ 在损失里被等权对待——也是 $L_{\mathrm{simple}}$ 能丢掉 ELBO 权重的根因。shape $(B,)$ long，device 跟 $x_0$ 一致，requires_grad=False。② `ε` 对应 $\varepsilon \sim \mathcal{N}(0, I)$，前向公式里的重参数噪声。shape $(B, C, H, W)$，dtype 跟 $x_0$ 一致，requires_grad=False（抽样常数，不是参数）。如果设成 True，梯度会被噪声污染，训练崩溃。③ `x_t = q_sample(x_0, t, ε)` 对应 $q(x_t \mid x_0) = \mathcal{N}(x_t;\ \sqrt{\bar{\alpha}_t}\, x_0,\ \sqrt{1 - \bar{\alpha}_t}\, \varepsilon)$ 的闭式实现：

```python
def q_sample(x_0, t, ε):
    a_bar_t = alpha_bars[t].view(-1, 1, 1, 1)   # 广播到 (B, 1, 1, 1)
    return a_bar_t.sqrt() * x_0 + (1 - a_bar_t).sqrt() * ε
```

删除这个函数，训练就退化成"网络直接拟合 $x_0$"——那不是扩散。关键 shape：`.view(-1, 1, 1, 1)` 把 $\bar{\alpha}_t$ 从 $(B,)$ 广播到 $(B, 1, 1, 1)$，跟 $x_0$ 的 $(B, C, H, W)$ 对齐。④ `eps_model(x_t, t)` 对应 $\varepsilon_\theta(x_t, t)$ 网络。输入 $(B, C, H, W)$ 的 $x_t$ + $(B,)$ long 的 $t$，输出 $(B, C, H, W)$ 的 $\varepsilon_\theta$。$t$ 通过 sinusoidal embedding 注入每一层。删除这个函数，整个框架没有任何学习发生。⑤ `loss = F.mse_loss(ε_pred, ε)` 对应 $L_{\mathrm{simple}}$ 的核心。MSE 比 ELBO 的 KL 简单太多——不需要算前向真实后验 $\tilde{\mu}_t$、不需要按 $t$ 加权、不需要 $L_T$ 和 $L_0$ 项。返回标量。`ε_pred` requires_grad=True（默认），`ε` requires_grad=False（默认）。⑥ `loss.backward()` 对应 $\theta$ 的梯度下降。Optimizer.step() 在外部循环。

训练常见失败点：模型忘设 `model.train()` —— BN/Dropout 在 eval 下破坏训练；$x_0$ 没归一化到 $[-1, 1]$ —— 输入输出尺度不一致，训练发散；`t` 用 float 而非 long —— sinusoidal embedding 需要 long 索引；没用 EMA 更新参数 —— 采样质量下降；batch size 太小 —— $\varepsilon$ 抽样方差大，训练不稳。

### 采样代码：`sample.py`

```python
@torch.no_grad()
def sample(batch_size):
    """采样 — 对应反向 SDE 的离散化"""
    x = torch.randn(batch_size, *image_shape)    # x_T ~ N(0, I)
    for t in reversed(range(T)):
        ε_pred = eps_model(x, t)                  # 预测这一步的噪声
        x = p_sample(x, t, ε_pred)               # 一步反向 p_θ(x_{t-1} | x_t)
    return x                                      # x_0 — 生成的图

def p_sample(x_t, t, ε_pred):
    """对应 x_{t-1} = (1/√α_t)·(x_t − β_t/√(1−ᾱ_t)·ε_θ) + σ_t·z"""
    alpha_t, ab_t, beta_t = alphas[t], alpha_bars[t], betas[t]

    mean = (x_t - beta_t / (1 - ab_t).sqrt() * ε_pred) / alpha_t.sqrt()
```

删除 `torch.no_grad()`，采样时 PyTorch 会保留计算图，显存爆掉。`for t in reversed(range(T))` 对应"从 $t = T$ 反向积分到 $t = 0$"，每一步调用一次 `eps_model`，共 $T$ 次前向传播。`x = torch.randn(...)` 对应 $x_T \sim \mathcal{N}(0, I)$——前向过程的终点。删除这一行，起点不再是纯噪声，生成图会偏离数据分布。最后一行对应 $x_{t-1}$ 的均值；最后一步不加 `σ_t·z` 随机项，因为 $x_1$ 已经接近数据，再加噪声会破坏分布。

### 网络骨架：`unet.py`

```python
class UNet(nn.Module):
    """ε_θ(x_t, t) — U-Net backbone + time embedding"""
    def __init__(self, in_ch, base_ch=128):
        super().__init__()
        self.time_emb = SinusoidalTimeEmbed(base_ch * 4)
        # encoder: 下采样 4 次, 每层 [Conv → GroupNorm → SiLU + time]
        # middle:  bottleneck with self-attention (4×4 resolution)
        # decoder: 上采样 4 次, skip connections from encoder
    def forward(self, x_t, t):
        t_emb = self.time_emb(t)                  # (B, 4*base_ch)
        h = self.conv_in(x_t)                     # (B, base_ch, H, W)
        skips = []
        for down in self.downs:                   # encoder 4 stages
            h = down(h, t_emb)
            skips.append(h)
        h = self.mid(h, t_emb)                    # bottleneck + attn
        for up, skip in zip(self.ups, reversed(skips)):
            h = up(torch.cat([h, skip], dim=1), t_emb)
        return self.conv_out(h)                   # (B, in_ch, H, W)
```

U-Net 的关键设计：encoder-decoder 对称结构 + skip connections（保留细节）+ 自注意力瓶颈（建模全局依赖）。`time_emb` 把 $t$ 编码成向量注入每一层——让网络知道"我现在去的是哪一档噪声"，因为同一个 $x_t$ 在不同时刻的去噪方向不同。删除时间注入，$\varepsilon_\theta$ 不知道当前 $t$，整张图所有位置用同一套去噪，FID 立刻塌掉。

### 推理增强：`sample_cfg_latent.py`

```python
def sample_cfg(x_t, t, c, w=7.5):
    """Classifier-Free Guidance: ε̃ = (1+w)ε_θ(x_t, c) − w·ε_θ(x_t, ∅)"""
    ε_cond = eps_model(x_t, t, c)
    ε_uncond = eps_model(x_t, t, uncond_token)
    return (1 + w) * ε_cond - w * ε_uncond

# Latent Diffusion: VAE encode → 跑扩散 → VAE decode
z = vae.encode(img).latent_dist.sample() * 0.18215   # 4×64×64
for t in reversed(range(T)):
    z = p_sample(z, t, eps_model(z, t, text_emb))
img = vae.decode(z / 0.18215).sample                   # 512×512×3
```

`w=7.5` 是 SD1.5 的默认——放大条件方向 7.5 倍、同时压低无条件方向（系数为负）。删除 CFG（`w=0`），图变模糊但多样性高；w 太大（>15），图过饱和、出现伪影。Latent Diffusion 的 0.18215 是 SD1.5 VAE 的潜空间 scale factor——训练时编码器 latent 分布的近似标准差。删除这个 scale，潜空间数值范围不匹配训练分布，扩散模型学不到东西。

整个实现的每一行——`eps_model`、`q_sample`、`p_sample`、`time_emb`、`CFG 系数`、`VAE scale`——都回指一个理论对象或数学约束。读代码就是读理论的另一种语言。

---

## 参考来源

1. Ho et al. 2020, *Denoising Diffusion Probabilistic Models*, arXiv:2006.11239 —— DDPM 原始论文，$L_{\mathrm{simple}}$ 训练目标
2. Nichol & Dhariwal 2021, *Improved Denoising Diffusion Probabilistic Models*, arXiv:2102.09672 —— cosine schedule、可学习方差、$v$-prediction
3. Song et al. 2021, *Score-Based Generative Modeling through SDEs*, arXiv:2011.13456 —— 证明 DDPM 与 NCSN 殊途同归，Score SDE 统一框架
4. Luo 2022, *Understanding Diffusion Models: A Unified Perspective*, arXiv:2208.11970 —— 四种参数化 ($x_0$/$\varepsilon$/score/$v$) 通过 Tweedie's Formula 等价
5. Liu et al. 2022, *Flow Straight and Fast: Learning to Generate and Transfer Data with Rectified Flow*, arXiv:2209.03003 —— Rectified Flow，从"diffusion 路径拉直"出发
6. Lipman et al. 2022, *Flow Matching for Generative Modeling*, arXiv:2210.02747 —— Flow Matching，从"绕开 ELBO 直接学向量场"出发
7. Tong et al. 2023, *Improving and Generalizing Flow-Based Generative Models with Minibatch Optimal Transport*, arXiv:2302.00482 —— 统一 diffusion / CNF / FM 的 OT 视角
8. Rombach et al. 2022, *High-Resolution Image Synthesis with Latent Diffusion Models*, arXiv:2112.10752 —— Latent Diffusion / Stable Diffusion 原始论文
