---
name: rethinkfun-lecture
description: "Create Chinese technical reports,讲稿,学习笔记, or Markdown-to-PDF lecture notes for technical topics. Use when the user asks for '你好好讲 X', '讲明白 X', '整理一份 X 报告', or any task that needs a three-layer report (intuition, derivation, code) with Concept Gradualism, state-flow narration, and a rendered PDF."
---

# RethinkFun-Style 中文技术报告 (Markdown + PDF)

## 适用场景

- 用于技术讲解、讲稿、学习笔记、技术报告、教学型 Markdown/PDF 输出。
- 用于用户要求"讲明白""深度讲解""整理报告""中文教程""论文/模型/算法讲稿"的任务。
- 不用于 1-2 句话速查，也不用于显式要求 bullet list 的短答案。

## 核心目标

把主题写成一条连续的理解链，而不是概念清单。

- 先讲状态，再讲缺口，再引入对象。
- 每个对象都要"被需要出来"，不要"先定义再解释"。
- 每个公式都要晚出现，并且能回答"为什么只能长这样"。
- 每个变量第一次出现时，都要交代来源、含义、作用、缺失后果。
- 每 2-3 个新对象，做一次认知回收：已知、未知、目标、障碍。
- 整篇保持连续散文，不要写成提纲、百科或汇报体。

## 必守规则

- 先排除旧方案的失败，再给出新对象。
- 辅助概念第一次出现时，必须在主论述之前就地解释 1-3 句。
- 主对象的非平凡推导必须展开 3-5 步，不能写"代入即得"。
- 代码不是附录，代码是理论对象的实现状态。
- 如果主题没有代码，就不要硬塞代码段。
- 禁用空话和口号，尤其是"显然""其实很简单""大家都知道"。
- 避免机械三段式、条目式自检段、事后补丁式说明。

## 写作流程

### Stage A: 搜索与取材

先把主题放进它的学科谱系里，再开始写。

- 先做宽搜，再做窄搜，必要时做验证。
- 优先读原始论文、官方文档、作者原文、课程讲义。
- 取材时至少提炼出：
  - 主题解决什么问题
  - 朴素办法为什么不够
  - 核心机制是什么
  - 最小直觉图景是什么
  - 关键公式/变量/结构各自对应什么
  - 误区、边界、失败场景
  - 和相邻方法的差异
  - 一个最能说明问题的例子

写稿前先列出概念档案表，至少包含：

| # | 类型 | 对象名 | Why needed | Where it comes from | How it connects | 位置 | 首次出现节点 |
|---|---|---|---|---|---|---|---|

- `类型` 只能填 `主` 或 `辅`。
- `主` 对象要填 Why / Where / How。
- `辅` 概念只填 Why needed，并标记首次出现是"前置"。
- 概念表里出现的每个对象，正文都要有对应位置。

读这些 reference：

- [intuition-lecture-prompt.md](references/intuition-lecture-prompt.md)
- [theory-rebuilder-prompt.md](references/theory-rebuilder-prompt.md)
- 需要渲染细节时读 `references/retina-render-pipeline.md`、`references/font-size-debugging.md`、`references/mathjax-aligned-svg-pitfall.md`

### Stage B: 写稿

#### B.1 直觉理解

- 先讲问题和失败画面。
- 再讲旧办法为什么不够。
- 再给统一直觉图景。
- 再把主对象逐个拉出来。
- 每段结尾自然引出下一个缺口。

#### B.2 公式推导 / 核心论证

- 每个公式前都要先回答三件事：
  - 为什么现在需要它
  - 它从哪个对象派生
  - 它和前面对象是什么关系
- 每个非平凡公式都要展开 3-5 步。
- 如果公式超长，优先手动换行，不要依赖 CSS 硬缩放。
- 对齐环境和 `\tag{}` 的边界问题，按 `references/mathjax-aligned-svg-pitfall.md` 处理。

#### B.3 代码讲解

- 先说这段代码维护什么状态，再说语法。
- 每个函数、张量、变量都要回指到理论对象。
- 说明输入、输出、shape、dtype、设备、梯度流。
- 说明失败点和调试点。

## 自检

写完后至少检查这些点：

- 开头是不是先讲状态和缺口，而不是定义
- 新对象是不是都被需要出来的
- 每个公式是不是晚出现且有铺垫
- 推导是不是在消除缺口，而不是另开战场
- 是否有至少 1 个对比对象、1 个边界条件、1 个最小例子
- 是否有至少 1 次状态回收
- 代码是否后置并逐项对应理论
- 是否没有废话、营销句和机械标签

## 渲染契约

当前公式渲染要遵守这条契约：

- `EX_TO_PX = 7.0`
- `DISPLAY_EX_TO_PX = 20.0`
- `RETINA = 2`
- inline 公式固定 20px display，高分辨率 PNG 由 2x retina 保证锐利
- display 公式按行高计算，再用 2x retina rasterize
- cairosvg 失败、SVG 解析失败、MathJax timeout 都要显式暴露，不能静默吞掉
- `templates/report.css` 必须硬约束 `.math-block img` 尺寸（max-height + !important 强制尊重 img attrs），防止 CSS 拉伸

**`verify_pdf.py` PASSED ≠ ship ready**（v7.20 polish 反面教材：attribute 全过但 3 个 P0 视觉问题）。渲染管线有以下已知盲点，verify_pdf 抓不到：

1. CSS `max-width:100%; height:auto` 覆盖 `<img width=X height=Y>`，把 22px 公式拉伸到 123px 笔画变粗
2. cairosvg 偶发返回接近全黑的 PNG（SVG 解析成功、PNG 头合法、文件大小正常，但内容黑）
3. inline 公式被裁剪 / 错位
4. 段落中文变方块
5. **`pdfimages -png` 抽出的 PNG 是 RGB 模式（不是 RGBA），丢失透明度**——公式 PNG 原本是黑字符 + 透明背景（由 smask 控制），抽出后没 alpha 通道，背景被填成黑色，看起来 100% 纯黑但其实是正常公式。**因此不能在 `pdfimages` 抽出的 PNG 上做 `pure_black_pct` 检测**（会全误报为黑块）。alpha-aware 检查只对**原始 HTML base64 的 RGBA PNG**有效（先 `Image.alpha_composite(白底, rgba)` 再分析）。详见 [render-verification-blind-spots.md](references/render-verification-blind-spots.md) 的"陷阱 #4：`pdfimages -png` 丢失 alpha 通道"小节。

**完整 ship gate（7 步，缺一不可）**：

1. `scripts/render.py` 生成 PDF + HTML
2. `scripts/verify_pdf.py` — attribute 硬指标（row-height ratio / image count / black-box / smallest real）
3. **`scripts/inspect_formulas_alphaware.py`** — **alpha-aware dark% 检查每个 display 公式 PNG**（防 RGBA transparent / 长水平笔画被误判为黑块；详见 [render-verification-blind-spots.md](references/render-verification-blind-spots.md) 的"Black-block detection — alpha-aware methodology"小节）
4. `scripts/check_cairosvg_errors.py` — cairosvg 错误
5. `scripts/visual_audit.py` — **像素级审计（黑块 / 拉伸 / 方块）**
6. 抽 4-6 张 300 DPI PNG **肉眼** 过一遍
7. 任何 1 项不过 = **不许 ship**

详细失败案例 + 像素审计脚本见 [render-verification-blind-spots.md](references/render-verification-blind-spots.md)（覆盖 `\tag{}` 误用、v7.20 attribute-vs-visual、v7.22 codex 假验收、SMask vs 真图 pairs、alpha-aware 检测 4 陷阱、完整 ship gate 流程、历史版本时间线）。

## 参考文件

- [retina-render-pipeline.md](references/retina-render-pipeline.md)
- [font-size-debugging.md](references/font-size-debugging.md)
- [mathjax-aligned-svg-pitfall.md](references/mathjax-aligned-svg-pitfall.md)
- [weasyprint-svg-incompatibility.md](references/weasyprint-svg-incompatibility.md)
- [pdf-render-pipeline-iterations.md](references/pdf-render-pipeline-iterations.md)
- [reference-pdf-v9.md](references/reference-pdf-v9.md)

## 不要做的事

- 不要把历史版本的 KaTeX 路径、旧 PNG 比例、旧 footer 逻辑带回当前实现。
- 不要修改 `references/intuition-lecture-prompt.md` 和 `references/theory-rebuilder-prompt.md` 的原文。
- 不要修改测试输入 `diffusion-model-report.md`。
- **不要把 `verify_pdf.py` PASSED 当成 ship 信号**——它只查 attribute / 结构 / 已知正则，不查实际像素。要 ship 必须跑 `scripts/visual_audit.py` + 肉眼抽页。
- **不要 delegate 给 codex 修"视觉问题"时只给 attribute 报告**——必须给真实页面 PNG（300 DPI 抽页）+ 坐标级 audit 报告，否则 codex 只能改 attribute，过不了真视觉。详见 [codex-polish-workflow.md](references/codex-polish-workflow.md) 的"视觉证据"小节。
- **不要相信 codex 的 verify 输出**——codex 曾经 commit 代码 + 写"✅ PASSED"但根本没渲染 deliverable。永远自己 `ls -la <expected-output>` + 跑渲染 + 看图。详见 [render-verification-blind-spots.md](references/render-verification-blind-spots.md) 的"v7.22 polish 失败复盘"小节。
- **不要用 `Counter(px) == (0,0,0)` 判断 PDF 图损坏**——`pdfimages -all` 抽出的 SMask alpha 通道永远 100% 黑（黑=透明），这是 PDF 透明机制，不是 bug。详见同 reference 的"SMask vs real image pairs"小节。
- **不要把 `\\sqrt` 顶端 / `\\frac` 分数线 / `\\mathcal{N}` 大字符当成黑块 bug 报告**——这些是 200-400px 长水平笔画的正常公式渲染，`max_run > 200` 不是异常。详见同 reference 的"陷阱 #2：长水平笔画不是黑块"小节 + `scripts/inspect_formulas_alphaware.py`（alpha-aware 才是 ground truth）。
- **不要相信 codex 的 PROBLEMS.md**——codex 用 max_run 等粗检测写 PROBLEMS.md 会把正常公式当 bug，导致"修复"反方向弄坏渲染（v7.22 polish 真实案例）。给 codex 派 audit 活时 prompt 必须写死"用 alpha-aware dark%，不要用 max_run"。
- **不要在 `pdfimages -png` 抽出的 PNG 上做 pure-black pixel 检测**——它们是 RGB 模式（无 alpha），公式的透明背景被填成黑色，pure_black_pct 看起来 100% 但其实是正常公式。要做 alpha-aware 检查必须用**原始 HTML base64 的 RGBA PNG**（先 `Image.alpha_composite(白底, rgba)`）。详见 [render-verification-blind-spots.md](references/render-verification-blind-spots.md) 的"陷阱 #4：`pdfimages -png` 丢失 alpha 通道"小节。